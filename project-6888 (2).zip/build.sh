#!/bin/bash
npm run build