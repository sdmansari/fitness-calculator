import { useState } from "react";
import Layout from "@/components/Layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);

      // Reset form
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });

      // Show success message
      toast({
        title: "Message Sent!",
        description: "Thank you for contacting us. We'll get back to you soon."
      });
    }, 1500);
  };

  return (
    <Layout>
      <div className="container mx-auto py-12 px-4" data-id="xym45l83k" data-path="src/pages/ContactPage.tsx">
        <div className="max-w-4xl mx-auto" data-id="8mmdxc3ve" data-path="src/pages/ContactPage.tsx">
          <div className="text-center mb-12" data-id="2hx9tfjof" data-path="src/pages/ContactPage.tsx">
            <h1 className="text-4xl font-bold mb-4" data-id="h8ee4fpm4" data-path="src/pages/ContactPage.tsx">Contact Us</h1>
            <p className="text-xl text-gray-600" data-id="osls480tm" data-path="src/pages/ContactPage.tsx">
              Have questions or feedback? We'd love to hear from you!
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12" data-id="5olpunlrf" data-path="src/pages/ContactPage.tsx">
            <div data-id="t1ygz1oe0" data-path="src/pages/ContactPage.tsx">
              <Card>
                <CardContent className="pt-6">
                  <form onSubmit={handleSubmit} className="space-y-6" data-id="8604q4yel" data-path="src/pages/ContactPage.tsx">
                    <div className="space-y-2" data-id="dth339dne" data-path="src/pages/ContactPage.tsx">
                      <Label htmlFor="name" className="text-base">Your Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Enter your name"
                        required />

                    </div>
                    
                    <div className="space-y-2" data-id="wiqvv2mg8" data-path="src/pages/ContactPage.tsx">
                      <Label htmlFor="email" className="text-base">Email Address</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Enter your email"
                        required />

                    </div>
                    
                    <div className="space-y-2" data-id="cx8aex2si" data-path="src/pages/ContactPage.tsx">
                      <Label htmlFor="subject" className="text-base">Subject</Label>
                      <Input
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        placeholder="What is this regarding?"
                        required />

                    </div>
                    
                    <div className="space-y-2" data-id="460wtlett" data-path="src/pages/ContactPage.tsx">
                      <Label htmlFor="message" className="text-base">Message</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Type your message here..."
                        rows={6}
                        required />

                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                      disabled={isSubmitting}>

                      {isSubmitting ? "Sending..." : "Send Message"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-8" data-id="zmd00cofx" data-path="src/pages/ContactPage.tsx">
              <div data-id="6rf76htb8" data-path="src/pages/ContactPage.tsx">
                <h2 className="text-2xl font-bold mb-4" data-id="4d1h45u6r" data-path="src/pages/ContactPage.tsx">Get in Touch</h2>
                <p className="text-gray-700 mb-6" data-id="082r8ps0s" data-path="src/pages/ContactPage.tsx">
                  Whether you have a question about our calculators, found a bug, or want to suggest a new feature,
                  we're here to help. Fill out the form or reach out to us directly using the contact information below.
                </p>
                
                <div className="space-y-4" data-id="23bz4mvu6" data-path="src/pages/ContactPage.tsx">
                  <div className="flex items-center" data-id="pnvp08s9d" data-path="src/pages/ContactPage.tsx">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-4" data-id="6wxu6uhj5" data-path="src/pages/ContactPage.tsx">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="bqgyi4rvk" data-path="src/pages/ContactPage.tsx">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" data-id="2gkwdcbra" data-path="src/pages/ContactPage.tsx" />
                      </svg>
                    </div>
                    <div data-id="52t7i0ciq" data-path="src/pages/ContactPage.tsx">
                      <h3 className="text-lg font-medium" data-id="zp5zir36p" data-path="src/pages/ContactPage.tsx">Email</h3>
                      <a href="mailto:info@fitcalchub.com" className="text-blue-600 hover:underline" data-id="11q9q32tx" data-path="src/pages/ContactPage.tsx">info@fitcalchub.com</a>
                    </div>
                  </div>
                  
                  <div className="flex items-center" data-id="073tdtcle" data-path="src/pages/ContactPage.tsx">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-4" data-id="qs9x1wnd2" data-path="src/pages/ContactPage.tsx">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="q1c64zjhf" data-path="src/pages/ContactPage.tsx">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" data-id="suw34v177" data-path="src/pages/ContactPage.tsx" />
                      </svg>
                    </div>
                    <div data-id="7yokwucq1" data-path="src/pages/ContactPage.tsx">
                      <h3 className="text-lg font-medium" data-id="0ed7ldj4x" data-path="src/pages/ContactPage.tsx">Follow Us</h3>
                      <div className="flex space-x-3 mt-1" data-id="03cwjzgof" data-path="src/pages/ContactPage.tsx">
                        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800" data-id="k5lcqam5d" data-path="src/pages/ContactPage.tsx">
                          <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" data-id="mqmbmwrjg" data-path="src/pages/ContactPage.tsx">
                            <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" data-id="8nsss5lpz" data-path="src/pages/ContactPage.tsx" />
                          </svg>
                        </a>
                        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-600" data-id="27q594ial" data-path="src/pages/ContactPage.tsx">
                          <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" data-id="7wxowng12" data-path="src/pages/ContactPage.tsx">
                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723 9.99 9.99 0 01-3.127 1.195 4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.937 4.937 0 004.604 3.417 9.868 9.868 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.054 0 13.999-7.496 13.999-13.986 0-.209 0-.42-.015-.63a9.936 9.936 0 002.46-2.548l-.047-.02z" data-id="z2ov9t1ex" data-path="src/pages/ContactPage.tsx" />
                          </svg>
                        </a>
                        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:text-purple-800" data-id="rqmnj0inh" data-path="src/pages/ContactPage.tsx">
                          <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" data-id="q70qqtlyo" data-path="src/pages/ContactPage.tsx">
                            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" data-id="r2xi8eqr1" data-path="src/pages/ContactPage.tsx" />
                          </svg>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg" data-id="8wskkfik0" data-path="src/pages/ContactPage.tsx">
                <h3 className="text-lg font-semibold mb-4" data-id="wlel7v8c6" data-path="src/pages/ContactPage.tsx">Frequently Asked Questions</h3>
                <div className="space-y-4" data-id="7daiyxuz5" data-path="src/pages/ContactPage.tsx">
                  <div data-id="b7ov0aa3u" data-path="src/pages/ContactPage.tsx">
                    <h4 className="font-medium" data-id="imlz909nq" data-path="src/pages/ContactPage.tsx">How accurate are your calculators?</h4>
                    <p className="text-gray-600 text-sm" data-id="0had86aj2" data-path="src/pages/ContactPage.tsx">Our calculators use scientifically validated formulas, but individual results may vary based on unique factors.</p>
                  </div>
                  <div data-id="8nxqb9fhf" data-path="src/pages/ContactPage.tsx">
                    <h4 className="font-medium" data-id="3wvxkfk3z" data-path="src/pages/ContactPage.tsx">Do you store my health data?</h4>
                    <p className="text-gray-600 text-sm" data-id="wg8lec06m" data-path="src/pages/ContactPage.tsx">No, all calculations are performed client-side in your browser. We don't store any of your personal health information.</p>
                  </div>
                  <div data-id="bmfidavb7" data-path="src/pages/ContactPage.tsx">
                    <h4 className="font-medium" data-id="q76ch8bdz" data-path="src/pages/ContactPage.tsx">Can I suggest a new calculator?</h4>
                    <p className="text-gray-600 text-sm" data-id="0e1ewkb6m" data-path="src/pages/ContactPage.tsx">Absolutely! We welcome suggestions. Please use the contact form to send us your ideas.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>);

};

export default ContactPage;