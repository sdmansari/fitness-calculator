import Layout from "@/components/Layout/Layout";
import { Separator } from "@/components/ui/separator";

const DisclaimerPage = () => {
  return (
    <Layout>
      <div className="container mx-auto py-12 px-4" data-id="ptkagp2lh" data-path="src/pages/DisclaimerPage.tsx">
        <div className="max-w-4xl mx-auto" data-id="g2l19vdns" data-path="src/pages/DisclaimerPage.tsx">
          <div className="text-center mb-12" data-id="j2k70mmcr" data-path="src/pages/DisclaimerPage.tsx">
            <h1 className="text-4xl font-bold mb-4" data-id="2auka5ioc" data-path="src/pages/DisclaimerPage.tsx">Disclaimer</h1>
            <p className="text-gray-600" data-id="rhutd6x4h" data-path="src/pages/DisclaimerPage.tsx">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-blue max-w-none" data-id="4klcdor3d" data-path="src/pages/DisclaimerPage.tsx">
            <p className="text-lg mb-6" data-id="eqbeos8a9" data-path="src/pages/DisclaimerPage.tsx">
              Please read this disclaimer carefully before using the Fitness Calculator Hub website.
            </p>

            <Separator className="my-8" />

            <section className="mb-8" data-id="3tx3nz7zk" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="9enpv5u33" data-path="src/pages/DisclaimerPage.tsx">Not Medical Advice</h2>
              <p className="mb-4" data-id="40use5icg" data-path="src/pages/DisclaimerPage.tsx">
                The information provided on Fitness Calculator Hub is for general informational and educational purposes only. The calculators, content, and other resources available on this website are not intended to be a substitute for professional medical advice, diagnosis, or treatment.
              </p>
              <p className="mb-4" data-id="wfdtqqr2f" data-path="src/pages/DisclaimerPage.tsx">
                Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition or before starting any diet, exercise, or supplementation program. Never disregard professional medical advice or delay in seeking it because of something you have read on this website.
              </p>
            </section>

            <section className="mb-8" data-id="1xv74az4c" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="ciqrlqpuj" data-path="src/pages/DisclaimerPage.tsx">Calculator Accuracy</h2>
              <p className="mb-4" data-id="22smstvud" data-path="src/pages/DisclaimerPage.tsx">
                While we strive to provide accurate calculators based on established formulas, these tools provide estimates only. The results from our calculators should be used as a reference point and not as absolute values.
              </p>
              <p className="mb-4" data-id="7xmhlcfx0" data-path="src/pages/DisclaimerPage.tsx">
                Many factors can affect the accuracy of the calculations, including but not limited to individual body composition, genetics, medical conditions, and environmental factors that cannot be accounted for in standardized formulas.
              </p>
              <p data-id="jvw76u4te" data-path="src/pages/DisclaimerPage.tsx">
                Users should be aware that different calculation methods may yield different results, and the most accurate assessment of health metrics often requires professional evaluation using specialized equipment.
              </p>
            </section>

            <section className="mb-8" data-id="9rni0balv" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="kzgv5um5p" data-path="src/pages/DisclaimerPage.tsx">No Professional Relationship</h2>
              <p data-id="dwk30oyq3" data-path="src/pages/DisclaimerPage.tsx">
                Use of Fitness Calculator Hub does not create a doctor-patient relationship, a dietitian-client relationship, or any other professional-client relationship with any member of the Fitness Calculator Hub team or its affiliates.
              </p>
            </section>

            <section className="mb-8" data-id="53mv6uc2t" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="we9fa7q6c" data-path="src/pages/DisclaimerPage.tsx">No Guarantee</h2>
              <p className="mb-4" data-id="fjdadp0pz" data-path="src/pages/DisclaimerPage.tsx">
                We make no guarantees about the results you may get from using the calculators or following the information provided on this website.
              </p>
              <p data-id="3r76jf4rr" data-path="src/pages/DisclaimerPage.tsx">
                Health and fitness outcomes depend on many factors, including but not limited to consistency, individual physiology, proper execution of exercise, quality of nutrition, and overall health status, which vary greatly from person to person.
              </p>
            </section>

            <section className="mb-8" data-id="fva6nw32x" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="chhenuhkk" data-path="src/pages/DisclaimerPage.tsx">Risk Acknowledgment</h2>
              <p className="mb-4" data-id="cjgdsjyxr" data-path="src/pages/DisclaimerPage.tsx">
                Exercise, diet changes, and other fitness activities carry inherent risks. By using the information on this website, you acknowledge these risks and agree to consult with appropriate health professionals before making significant changes to your lifestyle.
              </p>
              <p data-id="1ww2pjq7n" data-path="src/pages/DisclaimerPage.tsx">
                Certain health conditions may make some exercise programs or dietary changes unsafe. It is your responsibility to discuss your health needs with a healthcare professional before engaging in new fitness or nutrition programs.
              </p>
            </section>

            <section className="mb-8" data-id="whjwiboso" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="asdsu9opg" data-path="src/pages/DisclaimerPage.tsx">External Links</h2>
              <p className="mb-4" data-id="k4si2s3nk" data-path="src/pages/DisclaimerPage.tsx">
                Our website may contain links to external sites that are not operated by us. We have no control over, and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.
              </p>
              <p data-id="zpzmeyieo" data-path="src/pages/DisclaimerPage.tsx">
                We strongly advise you to review the Terms and Privacy Policy of every site you visit.
              </p>
            </section>

            <section className="mb-8" data-id="coiuy3zls" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="4iqs6v364" data-path="src/pages/DisclaimerPage.tsx">Use at Your Own Risk</h2>
              <p className="mb-4" data-id="3mrv182kj" data-path="src/pages/DisclaimerPage.tsx">
                Your use of Fitness Calculator Hub is entirely at your own risk. The information and calculators are provided "as is" without warranty of any kind, either expressed or implied, including but not limited to the implied warranties of merchantability, fitness for a particular purpose, or non-infringement.
              </p>
              <p data-id="83jjcu4k4" data-path="src/pages/DisclaimerPage.tsx">
                Fitness Calculator Hub shall not be liable for any damages, including direct, indirect, incidental, special, consequential, or punitive damages, resulting from the use of, or the inability to use, the website or its contents.
              </p>
            </section>

            <section data-id="r54anq4xz" data-path="src/pages/DisclaimerPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="u13kwq3a9" data-path="src/pages/DisclaimerPage.tsx">Changes to This Disclaimer</h2>
              <p className="mb-4" data-id="84jzo6m05" data-path="src/pages/DisclaimerPage.tsx">
                We may update this Disclaimer from time to time. We will notify you of any changes by posting the new Disclaimer on this page.
              </p>
              <p data-id="uflrim4im" data-path="src/pages/DisclaimerPage.tsx">
                You are advised to review this Disclaimer periodically for any changes. Changes to this Disclaimer are effective when they are posted on this page.
              </p>
            </section>
          </div>
        </div>
      </div>
    </Layout>);

};

export default DisclaimerPage;