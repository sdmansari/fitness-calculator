import { useSearchParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Layout from "@/components/Layout/Layout";
import CalculatorCard from "@/components/CalculatorCard";
import MetaTags from "@/components/SEO/MetaTags";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// Calculator data
const calculators = [
{
  id: "bmi",
  title: "BMI Calculator",
  description: "Calculate your Body Mass Index (BMI) to determine if your weight is healthy for your height.",
  path: "/calculators/bmi",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="gou935l9f" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" data-id="bjtqtswik" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "bmr",
  title: "BMR Calculator",
  description: "Calculate your Basal Metabolic Rate (BMR) to know how many calories your body needs at rest.",
  path: "/calculators/bmr",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="79hpujtit" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" data-id="rfdce7l89" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "tdee",
  title: "TDEE Calculator",
  description: "Calculate your Total Daily Energy Expenditure (TDEE) based on your activity level.",
  path: "/calculators/tdee",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="4rdo9vn7f" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" data-id="hbo3jzxu4" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "ideal-weight",
  title: "Ideal Weight Calculator",
  description: "Estimate your ideal body weight based on height, gender, and body frame.",
  path: "/calculators/ideal-weight",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="lgah8c8qa" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" data-id="yazk89ggx" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "body-fat",
  title: "Body Fat Calculator",
  description: "Estimate your body fat percentage using various measurement methods.",
  path: "/calculators/body-fat",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="zn6ikuss9" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" data-id="hcal8nrsq" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "lean-body-mass",
  title: "Lean Body Mass Calculator",
  description: "Calculate your lean body mass (LBM) which is your total weight minus your body fat weight.",
  path: "/calculators/lean-body-mass",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="ih1bi9e4r" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" data-id="f3s0kkann" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "calcium-needs",
  title: "Calcium Needs Calculator",
  description: "Determine your daily calcium requirements based on age, gender, and other factors.",
  path: "/calculators/calcium-needs",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="w6s5u24oe" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" data-id="ieqtd328v" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "protein-intake",
  title: "Protein Intake Calculator",
  description: "Determine your optimal daily protein intake based on your weight, goals, and activity level.",
  path: "/calculators/protein-intake",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="bf3nd0q2t" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" data-id="kr9h59cdb" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "macro",
  title: "Macro Calculator",
  description: "Calculate your optimal macronutrient distribution (carbs, protein, fat) based on your goals.",
  path: "/calculators/macro",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="2r9ov8yyr" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" data-id="2a95jnra4" data-path="src/pages/HomePage.tsx" />
      </svg>

},
{
  id: "food-calorie",
  title: "Food Calorie Calculator",
  description: "Calculate the total calories and nutritional content of your meals and food items.",
  path: "/calculators/food-calorie",
  icon:
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="xpuwikqk3" data-path="src/pages/HomePage.tsx">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" data-id="ionnqkwjm" data-path="src/pages/HomePage.tsx" />
      </svg>

}];


const HomePage = () => {
  // Define the structured data for the HomePage
  const homePageStructuredData = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    'name': 'Health and Fitness Calculators - Free Online Tools',
    'description': 'Access free health and fitness calculators including BMI, BMR, TDEE, body fat, and more. Research-based tools to help you achieve your health goals.',
    'url': 'https://fitcalchub.com',
    'publisher': {
      '@type': 'Organization',
      'name': 'Fitness Calculator Hub',
      'logo': {
        '@type': 'ImageObject',
        'url': 'https://fitcalchub.com/public/medical-favicon.svg'
      }
    },
    'potentialAction': {
      '@type': 'SearchAction',
      'target': 'https://fitcalchub.com/?search={search_term_string}',
      'query-input': 'required name=search_term_string'
    }
  };
  const [searchParams] = useSearchParams();
  const [filteredCalculators, setFilteredCalculators] = useState(calculators);
  const searchQuery = searchParams.get("search") || "";
  const [searchInput, setSearchInput] = useState(searchQuery);
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      navigate(`/?search=${encodeURIComponent(searchInput.trim())}`);
    }
  };

  useEffect(() => {
    if (searchQuery) {
      const filtered = calculators.filter((calc) =>
      calc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      calc.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredCalculators(filtered);
    } else {
      setFilteredCalculators(calculators);
    }
  }, [searchQuery]);

  return (
    <>
      <MetaTags
        title="Free Health & Fitness Calculators 2023 | BMI, BMR, TDEE, Body Fat"
        description="Calculate your BMI, BMR, TDEE, body fat percentage, and more with our free health and fitness calculators. Accurate, science-based tools to help you reach your fitness goals."
        keywords="bmi calculator, bmr calculator, tdee calculator, free health calculator, body fat calculator, fitness calculator, nutrition calculator, ideal weight calculator, macro calculator, food calorie calculator"
        canonicalUrl="https://fitcalchub.com"
        publishedDate="2023-01-01"
        modifiedDate="2023-08-15"
        structuredData={homePageStructuredData} />

      <Layout>
      {/* Hero Section */}
      <section className="relative text-white py-24" data-id="883racyvy" data-path="src/pages/HomePage.tsx">
        {/* SEO optimized image with proper alt text and loading attribute */}
        <img
            src="/images/fitness-hero.jpg"
            alt="Fitness and health calculators to track your progress"
            className="absolute inset-0 w-full h-full object-cover"
            loading="eager"
            fetchpriority="high"
            aria-hidden="true"
            onError={(e) => {
              // Fallback to gradient background if image fails to load
              e.currentTarget.style.display = 'none';
              e.currentTarget.parentElement?.classList.add('bg-gradient-to-r', 'from-blue-600', 'to-teal-500');
            }} data-id="pxux94l95" data-path="src/pages/HomePage.tsx" />

        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-teal-900/80 mix-blend-multiply" data-id="z68l6v4ya" data-path="src/pages/HomePage.tsx"></div>
        
        <div className="container mx-auto px-4 text-center relative z-10" data-id="1d4pvipx1" data-path="src/pages/HomePage.tsx">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 drop-shadow-md" data-id="eltcbbyoi" data-path="src/pages/HomePage.tsx">
            Health & Fitness Calculators
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto drop-shadow-md" data-id="aqygnicjn" data-path="src/pages/HomePage.tsx">
            Accurate tools to help you track your fitness progress and achieve your health goals
          </p>
          <form onSubmit={handleSearch} className="max-w-xl mx-auto flex flex-col sm:flex-row gap-2 items-center" data-id="evefnuvkf" data-path="src/pages/HomePage.tsx">
            <Input
                type="text"
                placeholder="Search calculators..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="border-0 focus:ring-2 focus:ring-white bg-white/90 flex-grow h-12 text-lg placeholder:text-gray-500 text-gray-800" />

            <Button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto h-12 px-6 text-lg">
              Search
            </Button>
          </form>
        </div>
      </section>

      {/* Ad banner */}
      <div className="bg-gray-100 py-3 text-center" data-id="harbdm3fb" data-path="src/pages/HomePage.tsx">
        <div className="container mx-auto" data-id="n3sgzthsv" data-path="src/pages/HomePage.tsx">
          <div className="bg-white p-2 rounded shadow-sm" data-id="r2dbossgx" data-path="src/pages/HomePage.tsx">
            <p className="text-gray-500 text-sm" data-id="kpigbw1bc" data-path="src/pages/HomePage.tsx">Advertisement</p>
            <div className="h-16 flex items-center justify-center border border-gray-200 rounded" data-id="s2fnap30w" data-path="src/pages/HomePage.tsx">
              <span className="text-gray-400" data-id="ijld7i3os" data-path="src/pages/HomePage.tsx">Ad Space</span>
            </div>
          </div>
        </div>
      </div>

      {/* Calculators Section */}
      <section className="py-12 px-4" data-id="j064mgcwd" data-path="src/pages/HomePage.tsx">
        <div className="container mx-auto" data-id="dpqisdliv" data-path="src/pages/HomePage.tsx">
          <h2 className="text-3xl font-bold mb-10 text-center" data-id="80q3m1ipe" data-path="src/pages/HomePage.tsx">
            {searchQuery ? `Search Results for "${searchQuery}"` : "Our Fitness Calculators"}
          </h2>

          {filteredCalculators.length === 0 ?
            <div className="text-center py-8" data-id="ou6jfk0ym" data-path="src/pages/HomePage.tsx">
              <p className="text-xl text-gray-600" data-id="q2taq8sbk" data-path="src/pages/HomePage.tsx">No calculators found matching your search.</p>
            </div> :

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-id="v2pe0co3d" data-path="src/pages/HomePage.tsx">
              {filteredCalculators.map((calculator) =>
              <CalculatorCard
                key={calculator.id}
                title={calculator.title}
                description={calculator.description}
                icon={calculator.icon}
                path={calculator.path} />

              )}
            </div>
            }
        </div>
      </section>

      {/* Side Ad */}
      <div className="fixed right-0 top-1/3 transform -translate-y-1/2 hidden lg:block z-10" data-id="z96gx4vm6" data-path="src/pages/HomePage.tsx">
        <div className="bg-white p-2 rounded shadow-sm" data-id="crpwoklya" data-path="src/pages/HomePage.tsx">
          <p className="text-gray-500 text-xs" data-id="xrbcq23la" data-path="src/pages/HomePage.tsx">Ad</p>
          <div className="w-32 h-[300px] flex items-center justify-center border border-gray-200 rounded" data-id="nukfe7xib" data-path="src/pages/HomePage.tsx">
            <span className="text-gray-400 text-sm rotate-90" data-id="3hd5au0em" data-path="src/pages/HomePage.tsx">Advertisement</span>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <section className="bg-gray-50 py-12 px-4" data-id="0pj2ux0uc" data-path="src/pages/HomePage.tsx">
        <div className="container mx-auto" data-id="d2a49v9bj" data-path="src/pages/HomePage.tsx">
          <h2 className="text-3xl font-bold mb-10 text-center" data-id="yq79sj610" data-path="src/pages/HomePage.tsx">Why Use Our Calculators?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8" data-id="f6ph3831o" data-path="src/pages/HomePage.tsx">
            <div className="text-center p-6" data-id="vq0h0dfmx" data-path="src/pages/HomePage.tsx">
              <div className="bg-blue-100 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" data-id="m2fygqhzc" data-path="src/pages/HomePage.tsx">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="khl5k9p0u" data-path="src/pages/HomePage.tsx">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" data-id="r9ilo5dn7" data-path="src/pages/HomePage.tsx" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2" data-id="ob03taujh" data-path="src/pages/HomePage.tsx">Accurate Results</h3>
              <p className="text-gray-600" data-id="9d5iv3rju" data-path="src/pages/HomePage.tsx">Our calculators use scientifically validated formulas to provide you with accurate results.</p>
            </div>
            <div className="text-center p-6" data-id="olqqd5uhd" data-path="src/pages/HomePage.tsx">
              <div className="bg-green-100 text-green-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" data-id="t7pmcevu5" data-path="src/pages/HomePage.tsx">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="jqv8hazmn" data-path="src/pages/HomePage.tsx">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" data-id="71qis6uk6" data-path="src/pages/HomePage.tsx" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2" data-id="8241rrlo4" data-path="src/pages/HomePage.tsx">Fast & Simple</h3>
              <p className="text-gray-600" data-id="lvse1nrfn" data-path="src/pages/HomePage.tsx">Get quick results with our easy-to-use interface designed for simplicity and speed.</p>
            </div>
            <div className="text-center p-6" data-id="86jf20qaf" data-path="src/pages/HomePage.tsx">
              <div className="bg-purple-100 text-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" data-id="h66ne15hb" data-path="src/pages/HomePage.tsx">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="ex2xi031y" data-path="src/pages/HomePage.tsx">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" data-id="ztx8wk44s" data-path="src/pages/HomePage.tsx" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2" data-id="xh1o59vmm" data-path="src/pages/HomePage.tsx">Personalized</h3>
              <p className="text-gray-600" data-id="pd3jfhq41" data-path="src/pages/HomePage.tsx">Get personalized calculations based on your unique body measurements and goals.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Ad banner */}
      <div className="bg-gray-100 py-3 text-center" data-id="l9veuvvw2" data-path="src/pages/HomePage.tsx">
        <div className="container mx-auto" data-id="jr7lxnmfm" data-path="src/pages/HomePage.tsx">
          <div className="bg-white p-2 rounded shadow-sm" data-id="vqi0tkj4v" data-path="src/pages/HomePage.tsx">
            <p className="text-gray-500 text-sm" data-id="tnnxdv3ri" data-path="src/pages/HomePage.tsx">Advertisement</p>
            <div className="h-24 flex items-center justify-center border border-gray-200 rounded" data-id="yrjck7jen" data-path="src/pages/HomePage.tsx">
              <span className="text-gray-400" data-id="ap6npv3ub" data-path="src/pages/HomePage.tsx">Ad Space</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* SEO Optimized Content Section - Good for search engines */}
      <section className="py-12 px-4 bg-white" data-id="5fw49ihpd" data-path="src/pages/HomePage.tsx">
        <div className="container mx-auto" data-id="eqx0gi46f" data-path="src/pages/HomePage.tsx">
          <h2 className="text-3xl font-bold mb-6 text-center" data-id="hcwxwb8ot" data-path="src/pages/HomePage.tsx">Free Health & Fitness Calculators</h2>
          <div className="prose prose-lg max-w-4xl mx-auto" data-id="40ka4gyph" data-path="src/pages/HomePage.tsx">
            <p data-id="ivf9b55rh" data-path="src/pages/HomePage.tsx">
              Welcome to Fitness Calculator Hub, your trusted source for accurate and free online health and fitness calculators.
              Our suite of calculators includes the most comprehensive collection of tools to help you track your fitness progress,
              optimize your nutrition, and achieve your health goals.  
            </p>
            
            <h3 data-id="l4z3cjr74" data-path="src/pages/HomePage.tsx">Popular Health Calculators</h3>
            <p data-id="a5ynen1l4" data-path="src/pages/HomePage.tsx">
              Our most used calculators include the <Link to="/calculators/bmi" className="text-blue-600 hover:underline">BMI Calculator</Link> for measuring body mass index,
              <Link to="/calculators/bmr" className="text-blue-600 hover:underline">BMR Calculator</Link> for determining your basal metabolic rate,
              and the <Link to="/calculators/tdee" className="text-blue-600 hover:underline">TDEE Calculator</Link> for understanding your total daily energy expenditure.
              These tools are essential for anyone looking to manage their weight, improve fitness, or optimize nutrition.  
            </p>
            
            <h3 data-id="a6bkkvh4z" data-path="src/pages/HomePage.tsx">Body Composition Calculators</h3>
            <p data-id="0tycl813f" data-path="src/pages/HomePage.tsx">
              Understanding your body composition is crucial for fitness progress. Our
              <Link to="/calculators/body-fat" className="text-blue-600 hover:underline">Body Fat Calculator</Link>,
              <Link to="/calculators/lean-body-mass" className="text-blue-600 hover:underline">Lean Body Mass Calculator</Link>, and
              <Link to="/calculators/ideal-weight" className="text-blue-600 hover:underline">Ideal Weight Calculator</Link> help you
              gain insights into your body's makeup beyond what a standard scale can tell you.  
            </p>
            
            <h3 data-id="29jno62j9" data-path="src/pages/HomePage.tsx">Nutrition Calculators</h3>
            <p data-id="3o44bsxee" data-path="src/pages/HomePage.tsx">
              Proper nutrition is the foundation of good health. Our
              <Link to="/calculators/protein-intake" className="text-blue-600 hover:underline">Protein Intake Calculator</Link>,
              <Link to="/calculators/macro" className="text-blue-600 hover:underline">Macro Calculator</Link>, and
              <Link to="/calculators/food-calorie" className="text-blue-600 hover:underline">Food Calorie Calculator</Link>
              help you optimize your diet based on your specific needs and goals.  
            </p>
            
            <h3 data-id="55utwovi7" data-path="src/pages/HomePage.tsx">Why Choose Our Health Calculators?</h3>
            <ul data-id="3j4tgs5ix" data-path="src/pages/HomePage.tsx">
              <li data-id="f7ch4w1he" data-path="src/pages/HomePage.tsx"><strong data-id="p5l8hdg9u" data-path="src/pages/HomePage.tsx">Research-Based:</strong> All our calculators use scientifically validated formulas</li>
              <li data-id="okwssce79" data-path="src/pages/HomePage.tsx"><strong data-id="u8nj9w6f7" data-path="src/pages/HomePage.tsx">Regularly Updated:</strong> We keep our tools current with the latest health research</li>
              <li data-id="f9zgy1t7c" data-path="src/pages/HomePage.tsx"><strong data-id="vmgne6z4q" data-path="src/pages/HomePage.tsx">User-Friendly:</strong> Simple interfaces make calculating your health metrics easy</li>
              <li data-id="aaty7jir4" data-path="src/pages/HomePage.tsx"><strong data-id="fm1g3shos" data-path="src/pages/HomePage.tsx">Comprehensive:</strong> Get detailed explanations with your results</li>
              <li data-id="ve4txznhk" data-path="src/pages/HomePage.tsx"><strong data-id="ez7lcmmoa" data-path="src/pages/HomePage.tsx">Mobile-Friendly:</strong> Access our calculators on any device</li>
              <li data-id="3zwuoz4i4" data-path="src/pages/HomePage.tsx"><strong data-id="trlxbwb9i" data-path="src/pages/HomePage.tsx">100% Free:</strong> All calculators are available at no cost</li>
            </ul>
            
            <p data-id="97qxfpwuu" data-path="src/pages/HomePage.tsx">
              Start your health journey today by exploring our calculators above. Whether you're a fitness enthusiast,
              someone starting a weight loss journey, or a health professional looking for reliable tools for your clients,
              our calculators provide the insights you need for informed health decisions.  
            </p>
          </div>
        </div>
      </section>
    </Layout>
    </>);

};

export default HomePage;

/* Search Engine Keywords
* best fitness calculator
* bmi calculator women
* most accurate bmi calculator
* how to calculate ideal weight
* bmi calculator with age and gender
* comprehensive bmr calculator
* free tdee calculator online
* body fat calculator accurate
* protein intake calculator for muscle gain
* macro calculator for weight loss
* best fitness calculator app
* calorie calculator for women
* bmi chart for adults
* best macro calculator for muscle gain
* online body composition calculator
* daily calorie needs calculator
* lean body mass calculator women
* best way to calculate macros
* free health assessment calculator
* body measurement calculator for fitness
*/