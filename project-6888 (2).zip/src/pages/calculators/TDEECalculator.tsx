import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

const TDEECalculator = () => {
  const [unit, setUnit] = useState("metric");
  const [gender, setGender] = useState("male");
  const [age, setAge] = useState("");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [activityLevel, setActivityLevel] = useState("moderate");
  const [formula, setFormula] = useState("mifflin");
  const [bmr, setBmr] = useState<number | null>(null);
  const [tdee, setTdee] = useState<number | null>(null);
  const [error, setError] = useState("");

  const calculateTDEE = () => {
    setError("");

    try {
      const ageValue = parseFloat(age);

      if (isNaN(ageValue) || ageValue <= 0) {
        throw new Error("Please enter a valid age");
      }

      let heightInCm: number;
      let weightInKg: number;

      if (unit === "metric") {
        heightInCm = parseFloat(height);
        weightInKg = parseFloat(weight);

        if (isNaN(heightInCm) || isNaN(weightInKg) || heightInCm <= 0 || weightInKg <= 0) {
          throw new Error("Please enter valid height and weight values");
        }
      } else {
        const heightInInches = parseFloat(feet) * 12 + parseFloat(inches);
        const weightInLbs = parseFloat(weight);

        if (isNaN(heightInInches) || isNaN(weightInLbs) || heightInInches <= 0 || weightInLbs <= 0) {
          throw new Error("Please enter valid height and weight values");
        }

        heightInCm = heightInInches * 2.54;
        weightInKg = weightInLbs * 0.453592;
      }

      let calculatedBMR = 0;

      // Calculate BMR based on selected formula
      if (formula === "mifflin") {
        // Mifflin-St Jeor Equation
        if (gender === "male") {
          calculatedBMR = 10 * weightInKg + 6.25 * heightInCm - 5 * ageValue + 5;
        } else {
          calculatedBMR = 10 * weightInKg + 6.25 * heightInCm - 5 * ageValue - 161;
        }
      } else if (formula === "harris") {
        // Harris-Benedict Equation
        if (gender === "male") {
          calculatedBMR = 88.362 + 13.397 * weightInKg + 4.799 * heightInCm - 5.677 * ageValue;
        } else {
          calculatedBMR = 447.593 + 9.247 * weightInKg + 3.098 * heightInCm - 4.330 * ageValue;
        }
      } else if (formula === "katch") {
        // Katch-McArdle Formula (requires body fat percentage, simplified version here)
        calculatedBMR = 370 + 21.6 * (weightInKg * 0.73); // Assuming lean body mass is 73% of total weight as an approximation
      }

      // Calculate TDEE based on activity level
      let activityMultiplier = 1.2; // Sedentary

      switch (activityLevel) {
        case "sedentary":
          activityMultiplier = 1.2;
          break;
        case "light":
          activityMultiplier = 1.375;
          break;
        case "moderate":
          activityMultiplier = 1.55;
          break;
        case "active":
          activityMultiplier = 1.725;
          break;
        case "very":
          activityMultiplier = 1.9;
          break;
      }

      const calculatedTDEE = calculatedBMR * activityMultiplier;

      setBmr(calculatedBMR);
      setTdee(calculatedTDEE);
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setBmr(null);
      setTdee(null);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setHeight("");
    setWeight("");
    setFeet("");
    setInches("");
    setBmr(null);
    setTdee(null);
    setError("");
  };

  return (
    <CalculatorLayout
      title="TDEE Calculator"
      description="Calculate your Total Daily Energy Expenditure (TDEE) based on your activity level."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="qxd71z02z" data-path="src/pages/calculators/TDEECalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" data-id="7kipz5pka" data-path="src/pages/calculators/TDEECalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="6mqp3ro4u" data-path="src/pages/calculators/TDEECalculator.tsx">
        <div data-id="cpornz5qx" data-path="src/pages/calculators/TDEECalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
            value={unit}
            onValueChange={setUnit}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="o0l4ys94u" data-path="src/pages/calculators/TDEECalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (cm, kg)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="dm0izbkj1" data-path="src/pages/calculators/TDEECalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (ft, in, lbs)</Label>
            </div>
          </RadioGroup>
        </div>

        <div data-id="na8ukp20z" data-path="src/pages/calculators/TDEECalculator.tsx">
          <Label className="text-lg font-medium">Gender</Label>
          <RadioGroup
            value={gender}
            onValueChange={setGender}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="jg60ikjrv" data-path="src/pages/calculators/TDEECalculator.tsx">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">Male</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="ymevvz69a" data-path="src/pages/calculators/TDEECalculator.tsx">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">Female</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="ngoggnk43" data-path="src/pages/calculators/TDEECalculator.tsx">
          <div data-id="i2bsrk3g6" data-path="src/pages/calculators/TDEECalculator.tsx">
            <Label className="text-lg font-medium">Formula</Label>
            <Select value={formula} onValueChange={setFormula}>
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select formula" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mifflin">Mifflin-St Jeor (Recommended)</SelectItem>
                <SelectItem value="harris">Harris-Benedict</SelectItem>
                <SelectItem value="katch">Katch-McArdle</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div data-id="6salwrv31" data-path="src/pages/calculators/TDEECalculator.tsx">
            <Label className="text-lg font-medium">Activity Level</Label>
            <Select value={activityLevel} onValueChange={setActivityLevel}>
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select activity level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sedentary">Sedentary (Office job, little exercise)</SelectItem>
                <SelectItem value="light">Light Activity (1-2 days/week)</SelectItem>
                <SelectItem value="moderate">Moderate Activity (3-5 days/week)</SelectItem>
                <SelectItem value="active">Very Active (6-7 days/week)</SelectItem>
                <SelectItem value="very">Extremely Active (Physical job + training)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Separator />

        <div className="space-y-4" data-id="y18ben2mt" data-path="src/pages/calculators/TDEECalculator.tsx">
          <div className="space-y-2" data-id="3pj0jtvdm" data-path="src/pages/calculators/TDEECalculator.tsx">
            <Label htmlFor="age">Age (years)</Label>
            <Input
              id="age"
              type="number"
              placeholder="e.g., 30"
              value={age}
              onChange={(e) => setAge(e.target.value)} />

          </div>

          {unit === "metric" ?
          <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="7y1kvqnjp" data-path="src/pages/calculators/TDEECalculator.tsx">
                <div className="space-y-2" data-id="04e31n19h" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                  id="height"
                  type="number"
                  placeholder="e.g., 170"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="njcyc1ajj" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                  id="weight"
                  type="number"
                  placeholder="e.g., 70"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </> :

          <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="t9yaaa1ld" data-path="src/pages/calculators/TDEECalculator.tsx">
                <div className="space-y-2" data-id="63lf260x9" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <Label htmlFor="feet">Height (ft)</Label>
                  <Input
                  id="feet"
                  type="number"
                  placeholder="e.g., 5"
                  value={feet}
                  onChange={(e) => setFeet(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="puwtllmtf" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <Label htmlFor="inches">Height (in)</Label>
                  <Input
                  id="inches"
                  type="number"
                  placeholder="e.g., 10"
                  value={inches}
                  onChange={(e) => setInches(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="s09ivp7q8" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <Label htmlFor="weight">Weight (lbs)</Label>
                  <Input
                  id="weight"
                  type="number"
                  placeholder="e.g., 160"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </>
          }
        </div>

        <div className="flex gap-3" data-id="cv9pndpnj" data-path="src/pages/calculators/TDEECalculator.tsx">
          <Button
            onClick={calculateTDEE}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">

            Calculate TDEE
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>

            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="bhwyhklcy" data-path="src/pages/calculators/TDEECalculator.tsx">
            {error}
          </div>
        }

        {tdee !== null && bmr !== null && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="space-y-6" data-id="sfkixjrbl" data-path="src/pages/calculators/TDEECalculator.tsx">
                <div className="text-center" data-id="ycxijlk1h" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <p className="text-lg font-medium" data-id="ohs8ubowy" data-path="src/pages/calculators/TDEECalculator.tsx">Your Total Daily Energy Expenditure (TDEE) is</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="fig1jbgzx" data-path="src/pages/calculators/TDEECalculator.tsx">
                    {Math.round(tdee)} calories/day
                  </p>
                  <p className="text-lg mt-4" data-id="1u3ze9lq5" data-path="src/pages/calculators/TDEECalculator.tsx">
                    This is your estimated daily calorie need including physical activity.
                  </p>
                </div>
                
                <Separator />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center" data-id="gd47chfnc" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <div data-id="y19viz5xj" data-path="src/pages/calculators/TDEECalculator.tsx">
                    <h3 className="font-medium text-gray-600" data-id="fqbz08v3d" data-path="src/pages/calculators/TDEECalculator.tsx">BMR</h3>
                    <p className="text-2xl font-bold" data-id="urhs3znr8" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(bmr)} cal</p>
                  </div>
                  <div data-id="07xuci3ig" data-path="src/pages/calculators/TDEECalculator.tsx">
                    <h3 className="font-medium text-gray-600" data-id="4du3v82mf" data-path="src/pages/calculators/TDEECalculator.tsx">Maintenance</h3>
                    <p className="text-2xl font-bold" data-id="bz1fbl5p2" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee)} cal</p>
                  </div>
                  <div data-id="q2ixuz5kq" data-path="src/pages/calculators/TDEECalculator.tsx">
                    <h3 className="font-medium text-gray-600" data-id="13b21gacx" data-path="src/pages/calculators/TDEECalculator.tsx">Weekly</h3>
                    <p className="text-2xl font-bold" data-id="hgksk7yn1" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee * 7)} cal</p>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4" data-id="48qxr7rm0" data-path="src/pages/calculators/TDEECalculator.tsx">
                  <h3 className="font-medium text-lg" data-id="hspwdokz1" data-path="src/pages/calculators/TDEECalculator.tsx">Weight Goals</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="9wrepv99d" data-path="src/pages/calculators/TDEECalculator.tsx">
                    <Card>
                      <CardContent className="pt-4">
                        <h4 className="font-medium text-base mb-2" data-id="dyx1lmui7" data-path="src/pages/calculators/TDEECalculator.tsx">Lose Weight</h4>
                        <ul className="space-y-2" data-id="k63y3w42k" data-path="src/pages/calculators/TDEECalculator.tsx">
                          <li className="flex justify-between" data-id="2lmauezgr" data-path="src/pages/calculators/TDEECalculator.tsx">
                            <span data-id="lmko2fqg6" data-path="src/pages/calculators/TDEECalculator.tsx">Mild weight loss (0.25 kg/week):</span>
                            <span className="font-medium" data-id="f5b89tr3y" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee - 250)} cal</span>
                          </li>
                          <li className="flex justify-between" data-id="qx3aepieb" data-path="src/pages/calculators/TDEECalculator.tsx">
                            <span data-id="6eo263bdi" data-path="src/pages/calculators/TDEECalculator.tsx">Weight loss (0.5 kg/week):</span>
                            <span className="font-medium" data-id="zarvt5skk" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee - 500)} cal</span>
                          </li>
                          <li className="flex justify-between" data-id="6z8ots5xy" data-path="src/pages/calculators/TDEECalculator.tsx">
                            <span data-id="s7ggq30sb" data-path="src/pages/calculators/TDEECalculator.tsx">Extreme weight loss (1 kg/week):</span>
                            <span className="font-medium" data-id="7qqn7bp6e" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee - 1000)} cal</span>
                          </li>
                        </ul>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-4">
                        <h4 className="font-medium text-base mb-2" data-id="a3m3ukb0k" data-path="src/pages/calculators/TDEECalculator.tsx">Gain Weight</h4>
                        <ul className="space-y-2" data-id="ig23v3hab" data-path="src/pages/calculators/TDEECalculator.tsx">
                          <li className="flex justify-between" data-id="72s27lm2u" data-path="src/pages/calculators/TDEECalculator.tsx">
                            <span data-id="dq0la48gr" data-path="src/pages/calculators/TDEECalculator.tsx">Mild weight gain (0.25 kg/week):</span>
                            <span className="font-medium" data-id="m04nfuajs" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee + 250)} cal</span>
                          </li>
                          <li className="flex justify-between" data-id="1nkr9z5mq" data-path="src/pages/calculators/TDEECalculator.tsx">
                            <span data-id="q6ykdybtk" data-path="src/pages/calculators/TDEECalculator.tsx">Weight gain (0.5 kg/week):</span>
                            <span className="font-medium" data-id="g1o8yda37" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee + 500)} cal</span>
                          </li>
                          <li className="flex justify-between" data-id="zv0jygf6v" data-path="src/pages/calculators/TDEECalculator.tsx">
                            <span data-id="r0g1b7hq7" data-path="src/pages/calculators/TDEECalculator.tsx">Fast weight gain (1 kg/week):</span>
                            <span className="font-medium" data-id="2r63ld98s" data-path="src/pages/calculators/TDEECalculator.tsx">{Math.round(tdee + 1000)} cal</span>
                          </li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <Card className="mt-4 bg-blue-50">
                    <CardContent className="pt-4">
                      <h4 className="font-medium text-base mb-2" data-id="e1w8mb5a3" data-path="src/pages/calculators/TDEECalculator.tsx">Saran Medis</h4>
                      <div className="space-y-3" data-id="urqcxqc69" data-path="src/pages/calculators/TDEECalculator.tsx">
                        <p data-id="jxnx9shsn" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="sfi7lz0qt" data-path="src/pages/calculators/TDEECalculator.tsx">Berdasarkan hasil TDEE Anda ({Math.round(tdee)} kalori):</strong></p>
                        <ul className="list-disc pl-6 space-y-1" data-id="tu0kfni2n" data-path="src/pages/calculators/TDEECalculator.tsx">
                          <li data-id="o42g7z2jl" data-path="src/pages/calculators/TDEECalculator.tsx">Target berat badan harus dilakukan secara bertahap dan sehat. Defisit atau surplus kalori yang ekstrem tidak dianjurkan tanpa pengawasan medis.</li>
                          <li data-id="ffprbibw9" data-path="src/pages/calculators/TDEECalculator.tsx">Jangan mengurangi asupan kalori di bawah 1200 kalori per hari untuk wanita atau 1500 kalori per hari untuk pria tanpa pengawasan medis.</li>
                          <li data-id="pgvepinw5" data-path="src/pages/calculators/TDEECalculator.tsx">Kombinasikan manajemen kalori dengan aktivitas fisik teratur untuk hasil terbaik.</li>
                          <li data-id="ej92794fi" data-path="src/pages/calculators/TDEECalculator.tsx">Fokus pada kualitas nutrisi, bukan hanya jumlah kalori. Pastikan diet Anda mencakup protein yang cukup, karbohidrat kompleks, lemak sehat, dan banyak buah serta sayuran.</li>
                          <li data-id="l3vhzflo3" data-path="src/pages/calculators/TDEECalculator.tsx">Jika Anda memiliki kondisi medis seperti diabetes, penyakit jantung, atau gangguan metabolisme, konsultasikan terlebih dahulu dengan dokter sebelum mengubah asupan kalori Anda secara signifikan.</li>
                          <li data-id="9m04i5y7q" data-path="src/pages/calculators/TDEECalculator.tsx">{activityLevel === "sedentary" ? "Pertimbangkan untuk meningkatkan tingkat aktivitas fisik Anda untuk kesehatan optimal." : activityLevel === "very" ? "Pastikan Anda mengonsumsi cukup nutrisi untuk mendukung tingkat aktivitas tinggi Anda." : "Pertahankan tingkat aktivitas Anda dan sesuaikan asupan kalori sesuai tujuan berat badan Anda."}</li>
                        </ul>
                        <p className="text-sm italic mt-3" data-id="hyz5u8fqt" data-path="src/pages/calculators/TDEECalculator.tsx">Disclaimer: Informasi ini bersifat umum dan tidak menggantikan nasihat medis profesional. Selalu konsultasikan dengan dokter atau ahli gizi sebelum memulai program diet atau olahraga baru.</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="i0ghtduus" data-path="src/pages/calculators/TDEECalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="1471y6h6l" data-path="src/pages/calculators/TDEECalculator.tsx">Kalkulator TDEE Indonesia: Menghitung Kebutuhan Energi Harian Total</h3>
          <p className="mb-4" data-id="5uobvxron" data-path="src/pages/calculators/TDEECalculator.tsx">
            Total Daily Energy Expenditure (TDEE) atau Pengeluaran Energi Harian Total adalah jumlah total kalori yang Anda bakar setiap hari. TDEE calculator Indonesia ini menghitung BMR Anda ditambah kalori tambahan yang dibakar melalui aktivitas fisik dan pencernaan.    
          </p>
          <p className="mb-4" data-id="1bdwwa9co" data-path="src/pages/calculators/TDEECalculator.tsx">
            Di Indonesia, kalkulator TDEE menjadi alat yang semakin populer untuk manajemen berat badan dan kebugaran. Memahami TDEE Anda dapat membantu Anda mengembangkan strategi efektif untuk manajemen berat badan:
          </p>
          <ul className="list-disc pl-6 space-y-1 mb-4" data-id="o6by3ie8t" data-path="src/pages/calculators/TDEECalculator.tsx">
            <li data-id="wucjxj63a" data-path="src/pages/calculators/TDEECalculator.tsx">Untuk mempertahankan berat badan: Konsumsi kalori sama dengan TDEE Anda</li>
            <li data-id="1i4g65h5j" data-path="src/pages/calculators/TDEECalculator.tsx">Untuk menurunkan berat badan: Konsumsi kalori lebih sedikit dari TDEE Anda</li>
            <li data-id="qmi1cb5hc" data-path="src/pages/calculators/TDEECalculator.tsx">Untuk menambah berat badan: Konsumsi kalori lebih banyak dari TDEE Anda</li>
          </ul>
          <p className="mb-4" data-id="w08oj2dzl" data-path="src/pages/calculators/TDEECalculator.tsx">
            Kalkulator TDEE Indonesia ini disesuaikan dengan kebutuhan dan gaya hidup masyarakat Indonesia, mempertimbangkan faktor makanan lokal dan pola aktivitas yang umum di Indonesia.
          </p>
          <p data-id="0q9ogwwzf" data-path="src/pages/calculators/TDEECalculator.tsx">
            Ingat bahwa TDEE adalah perkiraan dan faktor individu seperti metabolisme, kondisi medis, dan efek termik makanan dapat mempengaruhi kebutuhan kalori aktual Anda.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="m0bwmyiel" data-path="src/pages/calculators/TDEECalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="fe98z9cwl" data-path="src/pages/calculators/TDEECalculator.tsx">Understanding Total Daily Energy Expenditure (TDEE)</h2>
          
          <p className="mb-4" data-id="ubfv0pl6x" data-path="src/pages/calculators/TDEECalculator.tsx">
            Total Daily Energy Expenditure (TDEE) represents the total number of calories your body burns in a 24-hour period. It combines your Basal Metabolic Rate (BMR) with additional energy used for physical activity, digestion, and other bodily functions.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="q8q3xjyze" data-path="src/pages/calculators/TDEECalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="4crammkrz" data-path="src/pages/calculators/TDEECalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="3yt4ai73t" data-path="src/pages/calculators/TDEECalculator.tsx">Components of TDEE</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="4lji7ci21" data-path="src/pages/calculators/TDEECalculator.tsx">
                <li data-id="addth6q0x" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="lcrtjam8h" data-path="src/pages/calculators/TDEECalculator.tsx">BMR (60-70%):</strong> Energy needed for basic functions at rest</li>
                <li data-id="jlnu5ij3r" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="pjrbkiiia" data-path="src/pages/calculators/TDEECalculator.tsx">TEF (10%):</strong> Thermic Effect of Food - energy used to digest food</li>
                <li data-id="1n4998grc" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="9cpzlcu90" data-path="src/pages/calculators/TDEECalculator.tsx">NEAT (15-30%):</strong> Non-Exercise Activity Thermogenesis - daily movement</li>
                <li data-id="v6el61bg8" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="jpke0aonc" data-path="src/pages/calculators/TDEECalculator.tsx">EAT (Variable):</strong> Exercise Activity Thermogenesis - deliberate exercise</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="v7r24nnua" data-path="src/pages/calculators/TDEECalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="he9uh3h2o" data-path="src/pages/calculators/TDEECalculator.tsx">Activity Level Explained</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="t624s7i7b" data-path="src/pages/calculators/TDEECalculator.tsx">
                <li data-id="p3r9upn08" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="wvk4ra6xt" data-path="src/pages/calculators/TDEECalculator.tsx">Sedentary:</strong> Little or no exercise, desk job</li>
                <li data-id="ensoj9s4c" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="mse60qa2y" data-path="src/pages/calculators/TDEECalculator.tsx">Lightly active:</strong> Light exercise 1-3 days/week</li>
                <li data-id="etfj9c73z" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="4o5js1cdo" data-path="src/pages/calculators/TDEECalculator.tsx">Moderately active:</strong> Moderate exercise 3-5 days/week</li>
                <li data-id="epcbdom0o" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="t37og3kmk" data-path="src/pages/calculators/TDEECalculator.tsx">Very active:</strong> Hard exercise 6-7 days/week</li>
                <li data-id="3wp50e2h9" data-path="src/pages/calculators/TDEECalculator.tsx"><strong data-id="hfjtn88e0" data-path="src/pages/calculators/TDEECalculator.tsx">Extremely active:</strong> Physically demanding job plus exercise</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="g2ikg3ske" data-path="src/pages/calculators/TDEECalculator.tsx">Using Your TDEE Results</h3>
          <p className="mb-4" data-id="sda86u96t" data-path="src/pages/calculators/TDEECalculator.tsx">
            Your TDEE provides valuable insight for nutrition planning and weight management:
          </p>
          
          <div className="space-y-4 mb-6" data-id="z7setbvz2" data-path="src/pages/calculators/TDEECalculator.tsx">
            <div className="border p-4 rounded-md" data-id="lx04n1q5q" data-path="src/pages/calculators/TDEECalculator.tsx">
              <h4 className="font-medium" data-id="m0pnxfmsh" data-path="src/pages/calculators/TDEECalculator.tsx">For Weight Maintenance</h4>
              <p data-id="bo0ztzyy1" data-path="src/pages/calculators/TDEECalculator.tsx">Consume approximately the same number of calories as your TDEE.</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="dkyuob4vr" data-path="src/pages/calculators/TDEECalculator.tsx">
              <h4 className="font-medium" data-id="ph4w3xli2" data-path="src/pages/calculators/TDEECalculator.tsx">For Weight Loss</h4>
              <p data-id="y5bzs5giu" data-path="src/pages/calculators/TDEECalculator.tsx">Create a calorie deficit by consuming 15-20% fewer calories than your TDEE (typically 500 calories/day for 1 pound per week).</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="3akjs4jzl" data-path="src/pages/calculators/TDEECalculator.tsx">
              <h4 className="font-medium" data-id="4uo7h97dm" data-path="src/pages/calculators/TDEECalculator.tsx">For Weight Gain & Muscle Building</h4>
              <p data-id="9mygn93ek" data-path="src/pages/calculators/TDEECalculator.tsx">Create a calorie surplus by consuming 10-20% more calories than your TDEE, while following a resistance training program.</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="9bpzyo4hq" data-path="src/pages/calculators/TDEECalculator.tsx">Adjusting and Optimizing Your TDEE</h3>
          <p className="mb-4" data-id="yu1uvdecz" data-path="src/pages/calculators/TDEECalculator.tsx">
            Remember that calculators provide estimates. For more accurate results:
          </p>
          
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="k359ou0bd" data-path="src/pages/calculators/TDEECalculator.tsx">
            <li data-id="hzma8xpd7" data-path="src/pages/calculators/TDEECalculator.tsx">Track your weight, measurements, and energy levels for 2-3 weeks</li>
            <li data-id="durxl9338" data-path="src/pages/calculators/TDEECalculator.tsx">If weight remains stable, your current intake equals your true TDEE</li>
            <li data-id="kzmh82bsg" data-path="src/pages/calculators/TDEECalculator.tsx">Adjust based on progress toward your goals</li>
            <li data-id="ua93a10w7" data-path="src/pages/calculators/TDEECalculator.tsx">Recalculate as your weight, activity level, or goals change</li>
          </ul>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="fel6alnbj" data-path="src/pages/calculators/TDEECalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="uj054fowt" data-path="src/pages/calculators/TDEECalculator.tsx">Learn More About TDEE</h3>
            <p className="mb-3" data-id="dbxpipi71" data-path="src/pages/calculators/TDEECalculator.tsx">
              For a comprehensive understanding of energy balance and how to optimize your TDEE for your specific goals, check out our detailed guide:
            </p>
            <Link
            to="/blog/tdee-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete TDEE Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="ecq030wxv" data-path="src/pages/calculators/TDEECalculator.tsx">
            Remember that while TDEE calculators provide useful estimates, individual variations exist due to factors like genetics, hormone levels, and metabolic adaptations. Monitor your results and adjust accordingly for the best outcomes.
          </p>
        </div>
    </CalculatorLayout>);

};

export default TDEECalculator;