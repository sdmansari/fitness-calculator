import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

const IdealWeightCalculator = () => {
  const [unit, setUnit] = useState("metric");
  const [height, setHeight] = useState("");
  const [gender, setGender] = useState("male");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [idealWeight, setIdealWeight] = useState<{hamwi: number;devine: number;robinson: number;miller: number;} | null>(null);
  const [error, setError] = useState("");

  const calculateIdealWeight = () => {
    setError("");

    try {
      let heightInCm: number;
      let heightInInches: number;

      if (unit === "metric") {
        heightInCm = parseFloat(height);
        heightInInches = heightInCm / 2.54;

        if (isNaN(heightInCm) || heightInCm <= 0) {
          throw new Error("Please enter a valid height value");
        }
      } else {
        const feetValue = parseFloat(feet);
        const inchesValue = parseFloat(inches);

        if (isNaN(feetValue) || isNaN(inchesValue) || feetValue <= 0) {
          throw new Error("Please enter valid height values");
        }

        heightInInches = feetValue * 12 + inchesValue;
        heightInCm = heightInInches * 2.54;
      }

      // Calculate ideal weight using different formulas
      let hamwi, devine, robinson, miller;

      if (gender === "male") {
        // For males
        hamwi = 48.0 + 2.7 * (heightInInches - 60);
        devine = 50.0 + 2.3 * (heightInInches - 60);
        robinson = 52.0 + 1.9 * (heightInInches - 60);
        miller = 56.2 + 1.41 * (heightInInches - 60);
      } else {
        // For females
        hamwi = 45.5 + 2.2 * (heightInInches - 60);
        devine = 45.5 + 2.3 * (heightInInches - 60);
        robinson = 49.0 + 1.7 * (heightInInches - 60);
        miller = 53.1 + 1.36 * (heightInInches - 60);
      }

      setIdealWeight({
        hamwi: Math.round(hamwi * 10) / 10,
        devine: Math.round(devine * 10) / 10,
        robinson: Math.round(robinson * 10) / 10,
        miller: Math.round(miller * 10) / 10
      });
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setIdealWeight(null);
    }
  };

  const resetCalculator = () => {
    setHeight("");
    setFeet("");
    setInches("");
    setIdealWeight(null);
    setError("");
  };

  return (
    <CalculatorLayout
      title="Ideal Weight Calculator"
      description="Calculate your ideal body weight based on height and gender using multiple scientific formulas."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="vopndqtay" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" data-id="rub8yl4co" data-path="src/pages/calculators/IdealWeightCalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="msrf8hpow" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
        <div data-id="7zc2a33p5" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
          <Label className="text-lg font-medium">Gender</Label>
          <RadioGroup
            value={gender}
            onValueChange={setGender}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="zaef97h7b" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">Male</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="whv51xvxf" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">Female</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div data-id="fcrzp5mcq" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
            value={unit}
            onValueChange={setUnit}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="1995ngqb1" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (cm)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="lx17r21am" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (ft, in)</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div className="space-y-4" data-id="7cksgyrhk" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
          {unit === "metric" ?
          <>
              <div className="space-y-2" data-id="1606xj9du" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                <Label htmlFor="height">Height (cm)</Label>
                <Input
                id="height"
                type="number"
                placeholder="e.g., 170"
                value={height}
                onChange={(e) => setHeight(e.target.value)} />
              </div>
            </> :
          <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="ads9nx9yc" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                <div className="space-y-2" data-id="awgdgzibt" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                  <Label htmlFor="feet">Height (ft)</Label>
                  <Input
                  id="feet"
                  type="number"
                  placeholder="e.g., 5"
                  value={feet}
                  onChange={(e) => setFeet(e.target.value)} />
                </div>
                <div className="space-y-2" data-id="mkyvvj80b" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                  <Label htmlFor="inches">Height (in)</Label>
                  <Input
                  id="inches"
                  type="number"
                  placeholder="e.g., 10"
                  value={inches}
                  onChange={(e) => setInches(e.target.value)} />
                </div>
              </div>
            </>
          }
        </div>

        <div className="flex gap-3" data-id="jkwq8ulic" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
          <Button
            onClick={calculateIdealWeight}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
            Calculate Ideal Weight
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>
            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="f36pub6zn" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            {error}
          </div>
        }

        {idealWeight !== null && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="space-y-4" data-id="o013u4f2n" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                <div data-id="ife4jv4ol" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                  <p className="text-lg font-medium" data-id="kd43rayp3" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Your Ideal Weight Range</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="p43k2misc" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                    {unit === "metric" ?
                  `${Math.min(...Object.values(idealWeight)).toFixed(1)} - ${Math.max(...Object.values(idealWeight)).toFixed(1)} kg` :
                  `${Math.min(...Object.values(idealWeight)).toFixed(1)} - ${Math.max(...Object.values(idealWeight)).toFixed(1)} lbs`}
                  </p>
                </div>
                
                <div className="mt-4 border-t pt-4" data-id="4w7uzezh3" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                  <p className="text-lg font-medium mb-3" data-id="1952awa6o" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Different Formula Results</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="6tpa65fj4" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                    <div className="bg-blue-50 p-3 rounded-lg" data-id="robiy36nh" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                      <p className="font-medium" data-id="lhjp00ns7" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Hamwi Formula</p>
                      <p className="text-xl font-bold text-blue-700" data-id="jo5r3tbim" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                        {unit === "metric" ?
                      `${(idealWeight.hamwi * 0.453592).toFixed(1)} kg` :
                      `${idealWeight.hamwi} lbs`}
                      </p>
                    </div>
                    <div className="bg-teal-50 p-3 rounded-lg" data-id="p42c0ukgj" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                      <p className="font-medium" data-id="fpqa0eol1" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Devine Formula</p>
                      <p className="text-xl font-bold text-teal-700" data-id="qpglvcon7" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                        {unit === "metric" ?
                      `${(idealWeight.devine * 0.453592).toFixed(1)} kg` :
                      `${idealWeight.devine} lbs`}
                      </p>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg" data-id="pt6jago8r" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                      <p className="font-medium" data-id="ah44aegwo" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Robinson Formula</p>
                      <p className="text-xl font-bold text-indigo-700" data-id="s9giou6w8" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                        {unit === "metric" ?
                      `${(idealWeight.robinson * 0.453592).toFixed(1)} kg` :
                      `${idealWeight.robinson} lbs`}
                      </p>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-lg" data-id="p8t7vgs58" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                      <p className="font-medium" data-id="g82ccmq6y" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Miller Formula</p>
                      <p className="text-xl font-bold text-purple-700" data-id="nsedpf7j9" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                        {unit === "metric" ?
                      `${(idealWeight.miller * 0.453592).toFixed(1)} kg` :
                      `${idealWeight.miller} lbs`}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 border-t pt-4" data-id="re6m5h5db" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="ovh84878u" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Interpretation</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="g4aftrivd" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                    <p className="mb-2" data-id="0kemzf24a" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Different formulas give slightly different results because they were developed using different methods and populations. The range provided gives you a general idea of your ideal weight based on your height and gender.</p>
                    <p className="mt-3 text-sm italic" data-id="kqcfc0579" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Disclaimer: These calculations provide estimates only and should not replace professional medical advice. Individual ideal weights may vary based on factors like body composition, muscle mass, and overall health.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="3sbarioep" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="4hy21e3rz" data-path="src/pages/calculators/IdealWeightCalculator.tsx">About Ideal Weight</h3>
          <p className="mb-4" data-id="yg25tinvy" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            Ideal body weight (IBW) was originally introduced by Devine in 1974 to calculate drug dosages. Since then, various formulas have been developed to provide estimates of what a person should weigh based primarily on height and gender.
          </p>
          <h3 className="text-lg font-semibold mb-2" data-id="hxo23vl4e" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Ideal Weight Formulas:</h3>
          <ul className="list-disc pl-6 space-y-1" data-id="zotmcrpfj" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            <li data-id="s0fdp8h4z" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="scd331hzl" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Hamwi Formula (1964):</strong> Men: 106 lbs for first 5 feet + 6 lbs for each inch over. Women: 100 lbs for first 5 feet + 5 lbs for each inch over.</li>
            <li data-id="acue93hpm" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="jcvk1v2um" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Devine Formula (1974):</strong> Men: 50 kg + 2.3 kg for each inch over 5 feet. Women: 45.5 kg + 2.3 kg for each inch over 5 feet.</li>
            <li data-id="t5y0jny8d" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="rmcbyl96j" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Robinson Formula (1983):</strong> Men: 52 kg + 1.9 kg for each inch over 5 feet. Women: 49 kg + 1.7 kg for each inch over 5 feet.</li>
            <li data-id="n8zhzde1s" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="2x0z0gk9a" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Miller Formula (1983):</strong> Men: 56.2 kg + 1.41 kg for each inch over 5 feet. Women: 53.1 kg + 1.36 kg for each inch over 5 feet.</li>
          </ul>
          <p className="mt-4 mb-4" data-id="yhlciwwfh" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            It's important to note that ideal weight calculations have limitations and don't account for individual differences in body composition, muscle mass, or other important health factors. These formulas provide general guidelines rather than strict targets.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="ce92n78ej" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="k7726ur19" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Understanding Ideal Weight</h2>
          
          <p className="mb-4" data-id="ss30w7h8q" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            The concept of "ideal weight" refers to weight ranges associated with optimal health outcomes. Unlike arbitrary beauty standards, ideal weight ranges are derived from research examining the relationship between weight and health outcomes.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="10gx5upav" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="zhocnqxfx" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="js5lo6nu2" data-path="src/pages/calculators/IdealWeightCalculator.tsx">About the Formulas</h3>
              <p className="mb-2" data-id="k52fngvkd" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Our calculator uses several established formulas:</p>
              <ul className="list-disc pl-5 space-y-1" data-id="ch15u1g03" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                <li data-id="izjs0ycpa" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="8tpcruid1" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Devine (1974):</strong> Originally for medication dosing</li>
                <li data-id="ito8f5ovc" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="ufzpx53ih" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Robinson (1983):</strong> Modified version of the Devine formula</li>
                <li data-id="pxlin8z7p" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="9fhwvpdxd" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Miller (1983):</strong> Takes into account frame size differences</li>
                <li data-id="iylcnwfsh" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="ut5mb4i9m" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Hamwi (1964):</strong> Simple clinical estimation method</li>
                <li data-id="299v9evku" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="33kggdxs1" data-path="src/pages/calculators/IdealWeightCalculator.tsx">BMI-based:</strong> Weight corresponding to BMI of 18.5-24.9</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="j2fd2jmtg" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="0np5yhpxe" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Limitations to Consider</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="h67eudic8" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
                <li data-id="7q23whttd" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Doesn't account for body composition (muscle vs. fat)</li>
                <li data-id="z4uilshk2" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Most formulas don't consider age-related changes</li>
                <li data-id="nq8aws4c5" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Doesn't address ethnic and racial differences</li>
                <li data-id="lggjb03ue" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Doesn't factor in overall fitness and metabolic health</li>
                <li data-id="qna8q22hp" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Doesn't account for individual bone density and muscle mass variations</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="s2z4qyp9n" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Formula Calculations</h3>
          <div className="space-y-4 mb-6" data-id="qrtr7fck2" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="eso8mxh69" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <h4 className="font-medium" data-id="q5i2i8hfn" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Devine Formula</h4>
              <p className="font-mono text-sm" data-id="l13e4bvh4" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Men: Ideal weight (kg) = 50 + 2.3 × (Height (in) - 60)</p>
              <p className="font-mono text-sm" data-id="v6lkiv2tv" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Women: Ideal weight (kg) = 45.5 + 2.3 × (Height (in) - 60)</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="fmw0mdx7x" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <h4 className="font-medium" data-id="imr0apnxn" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Robinson Formula</h4>
              <p className="font-mono text-sm" data-id="ntvaf8s5e" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Men: Ideal weight (kg) = 52 + 1.9 × (Height (in) - 60)</p>
              <p className="font-mono text-sm" data-id="aqft584k6" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Women: Ideal weight (kg) = 49 + 1.7 × (Height (in) - 60)</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="ckixtf8vl" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <h4 className="font-medium" data-id="akp9yfpek" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Miller Formula</h4>
              <p className="font-mono text-sm" data-id="c0u1jilgr" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Men: Ideal weight (kg) = 56.2 + 1.41 × (Height (in) - 60)</p>
              <p className="font-mono text-sm" data-id="rws2hf5wf" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Women: Ideal weight (kg) = 53.1 + 1.36 × (Height (in) - 60)</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="qr36lxbmw" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <h4 className="font-medium" data-id="i0b18pnpl" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Hamwi Formula</h4>
              <p className="font-mono text-sm" data-id="lbcwloh1u" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Men: Ideal weight (kg) = 48 + 2.7 × (Height (in) - 60)</p>
              <p className="font-mono text-sm" data-id="11j5h3e7f" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Women: Ideal weight (kg) = 45.5 + 2.2 × (Height (in) - 60)</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="6ieckqlcp" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              <h4 className="font-medium" data-id="d14yue1vq" data-path="src/pages/calculators/IdealWeightCalculator.tsx">BMI-Based Range</h4>
              <p className="font-mono text-sm" data-id="rxr9vvem2" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Healthy BMI range: 18.5 to 24.9 kg/m²</p>
              <p className="font-mono text-sm" data-id="1k7oa55zk" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Weight range (kg) = (18.5 to 24.9) × Height (m)²</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="r27h1cwh2" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Beyond Weight: A More Complete Health Picture</h3>
          <p className="mb-4" data-id="cm0vrwqgm" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            Weight is just one of many factors that influence health. For a more comprehensive assessment, consider these additional metrics:
          </p>
          
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="vw0pe02cm" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            <li data-id="306i9m0t0" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="0n0g0zxmx" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Body composition:</strong> Body fat percentage and lean mass</li>
            <li data-id="pds8flyaa" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="953jn2mmf" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Waist circumference:</strong> A measurement of abdominal fat, linked to metabolic risk</li>
            <li data-id="xhxzl1eto" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="nc19wu3fi" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Metabolic health markers:</strong> Blood glucose, lipid profiles, blood pressure</li>
            <li data-id="2v1v3wej6" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="fzj27udbi" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Physical fitness:</strong> Cardiovascular fitness, strength, flexibility</li>
            <li data-id="x36l3ib0j" data-path="src/pages/calculators/IdealWeightCalculator.tsx"><strong data-id="mttnbrxzf" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Overall well-being:</strong> Energy levels, sleep quality, mood</li>
          </ul>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="6obrz10i1" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="q0yc0gev5" data-path="src/pages/calculators/IdealWeightCalculator.tsx">Learn More About Ideal Weight</h3>
            <p className="mb-3" data-id="ih6zckq0t" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
              For an in-depth understanding of the science behind ideal weight, different formulas, and setting realistic weight goals, check out our comprehensive guide:
            </p>
            <Link
            to="/blog/ideal-weight-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete Ideal Weight Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="5lv8aqz6v" data-path="src/pages/calculators/IdealWeightCalculator.tsx">
            Remember that ideal weight formulas provide reference points, not rigid targets. Your optimal weight is influenced by numerous individual factors including genetics, body composition, lifestyle, and personal health goals.
          </p>
        </div>
    </CalculatorLayout>);

};

export default IdealWeightCalculator;