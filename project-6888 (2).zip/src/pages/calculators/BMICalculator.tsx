import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import MetaTags from "@/components/SEO/MetaTags";
import ResultActions from "@/components/ResultActions";
import { Link } from "react-router-dom";

const BMICalculator = () => {
  const [unit, setUnit] = useState("metric");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [bmi, setBmi] = useState<number | null>(null);
  const [bmiCategory, setBmiCategory] = useState("");
  const [error, setError] = useState("");

  const calculateBMI = () => {
    setError("");

    try {
      let calculatedBMI = 0;

      if (unit === "metric") {
        const heightInMeters = parseFloat(height) / 100;
        const weightInKg = parseFloat(weight);

        if (isNaN(heightInMeters) || isNaN(weightInKg) || heightInMeters <= 0 || weightInKg <= 0) {
          throw new Error("Please enter valid height and weight values");
        }

        calculatedBMI = weightInKg / (heightInMeters * heightInMeters);
      } else {
        const heightInInches = parseFloat(feet) * 12 + parseFloat(inches);
        const weightInLbs = parseFloat(weight);

        if (isNaN(heightInInches) || isNaN(weightInLbs) || heightInInches <= 0 || weightInLbs <= 0) {
          throw new Error("Please enter valid height and weight values");
        }

        calculatedBMI = weightInLbs * 703 / (heightInInches * heightInInches);
      }

      setBmi(calculatedBMI);

      // Determine BMI category
      if (calculatedBMI < 18.5) {
        setBmiCategory("Underweight");
      } else if (calculatedBMI < 25) {
        setBmiCategory("Normal weight");
      } else if (calculatedBMI < 30) {
        setBmiCategory("Overweight");
      } else if (calculatedBMI < 35) {
        setBmiCategory("Obesity (Class 1)");
      } else if (calculatedBMI < 40) {
        setBmiCategory("Obesity (Class 2)");
      } else {
        setBmiCategory("Obesity (Class 3)");
      }
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setBmi(null);
      setBmiCategory("");
    }
  };

  const resetCalculator = () => {
    setHeight("");
    setWeight("");
    setFeet("");
    setInches("");
    setBmi(null);
    setBmiCategory("");
    setError("");
  };

  return (
    <>
      <MetaTags
        title="BMI Calculator 2023 | Free Online Body Mass Index Calculator Tool"
        description="Use our free BMI calculator to check if your weight is healthy. Calculate BMI for men, women, and find your ideal weight range based on height. Updated for 2023."
        keywords="bmi calculator for women, how to calculate bmi step by step, body mass index calculator kg cm, bmi calculator by age and gender, bmi calculator for seniors, bmi calculator for different ethnicities, bmi calculator without weight, bmi formula with example"
        canonicalUrl="https://fitcalchub.com/calculators/bmi"
        publishedDate="2022-05-15"
        modifiedDate="2023-08-01"
        author="Dr. Sarah Johnson, Nutritional Specialist"
        structuredData={{
          '@context': 'https://schema.org',
          '@type': 'MedicalWebPage',
          'name': 'BMI Calculator | Fitness Calculator Hub',
          'description': 'Calculate your Body Mass Index (BMI) to determine if your weight is healthy for your height.',
          'url': 'https://fitcalchub.com/calculators/bmi',
          'lastReviewed': '2023-08-01',
          'reviewedBy': {
            '@type': 'Person',
            'name': 'Dr. Sarah Johnson',
            'jobTitle': 'Nutritional Specialist'
          },
          'mainEntity': {
            '@type': 'MedicalCalculator',
            'name': 'BMI Calculator',
            'description': 'Calculates Body Mass Index based on height and weight measurements',
            'medicineSystem': 'Western Medicine',
            'specialty': ['Primary Care', 'Weight Management'],
            'audience': {
              '@type': 'MedicalAudience',
              'audienceType': 'General Public'
            }
          }
        }}
        language="en" />

    <CalculatorLayout
        title="BMI Calculator"
        description="Calculate your Body Mass Index (BMI) to determine if your weight is healthy for your height."
        icon={
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="je70e5128" data-path="src/pages/calculators/BMICalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" data-id="lmef2nuny" data-path="src/pages/calculators/BMICalculator.tsx" />
        </svg>
        }>

      <div className="space-y-6" data-id="mv14dyee3" data-path="src/pages/calculators/BMICalculator.tsx">
        <div data-id="qzlvbvnqr" data-path="src/pages/calculators/BMICalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
              value={unit}
              onValueChange={setUnit}
              className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="rxqgvt1n3" data-path="src/pages/calculators/BMICalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (cm, kg)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="ecrut2cct" data-path="src/pages/calculators/BMICalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (ft, in, lbs)</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div className="space-y-4" data-id="i2epcgjbq" data-path="src/pages/calculators/BMICalculator.tsx">
          {unit === "metric" ?
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="11ffopplx" data-path="src/pages/calculators/BMICalculator.tsx">
                <div className="space-y-2" data-id="kwypuetxc" data-path="src/pages/calculators/BMICalculator.tsx">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="e.g., 170"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="h8cmd6tel" data-path="src/pages/calculators/BMICalculator.tsx">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 70"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </> :

            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="1z4i52gcr" data-path="src/pages/calculators/BMICalculator.tsx">
                <div className="space-y-2" data-id="3fsouc1g4" data-path="src/pages/calculators/BMICalculator.tsx">
                  <Label htmlFor="feet">Height (ft)</Label>
                  <Input
                    id="feet"
                    type="number"
                    placeholder="e.g., 5"
                    value={feet}
                    onChange={(e) => setFeet(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="t2p8rfsrf" data-path="src/pages/calculators/BMICalculator.tsx">
                  <Label htmlFor="inches">Height (in)</Label>
                  <Input
                    id="inches"
                    type="number"
                    placeholder="e.g., 10"
                    value={inches}
                    onChange={(e) => setInches(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="u5cc2rkha" data-path="src/pages/calculators/BMICalculator.tsx">
                  <Label htmlFor="weight">Weight (lbs)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 160"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </>
            }
        </div>

        <div className="flex gap-3" data-id="qh6202ezf" data-path="src/pages/calculators/BMICalculator.tsx">
          <Button
              onClick={calculateBMI}
              className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">

            Calculate BMI
          </Button>
          <Button
              variant="outline"
              onClick={resetCalculator}>

            Reset
          </Button>
        </div>

        {error &&
          <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="e4ojdm040" data-path="src/pages/calculators/BMICalculator.tsx">
            {error}
          </div>
          }

        {bmi !== null && !error &&
          <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="text-center space-y-4" data-id="olenxuz7i" data-path="src/pages/calculators/BMICalculator.tsx">
                <div data-id="heendi8e0" data-path="src/pages/calculators/BMICalculator.tsx">
                  <p className="text-lg font-medium" data-id="ss1l8h6qj" data-path="src/pages/calculators/BMICalculator.tsx">Your BMI is</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="kdllr6wux" data-path="src/pages/calculators/BMICalculator.tsx">
                    {bmi.toFixed(1)}
                  </p>
                </div>
                <div data-id="bqajhm1hk" data-path="src/pages/calculators/BMICalculator.tsx">
                  <p className="text-lg font-medium" data-id="iwxakx2ln" data-path="src/pages/calculators/BMICalculator.tsx">Classification</p>
                  <p className={`text-2xl font-bold ${
                  bmiCategory === "Normal weight" ?
                  "text-green-600" :
                  bmiCategory === "Underweight" ?
                  "text-orange-500" :
                  "text-red-500"}`
                  } data-id="cn5m825na" data-path="src/pages/calculators/BMICalculator.tsx">
                    {bmiCategory}
                  </p>
                </div>
                
                <ResultActions
                  title="BMI Result"
                  value={bmi.toFixed(1)}
                  category={bmiCategory}
                  details={{
                    Height: unit === "metric" ? `${height} cm` : `${feet}'${inches}"`,
                    Weight: unit === "metric" ? `${weight} kg` : `${weight} lbs`,
                    Unit: unit === "metric" ? "Metric" : "Imperial"
                  }} />

                
                <div className="mt-4 border-t pt-4" data-id="hy5atfboi" data-path="src/pages/calculators/BMICalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="3jfwqgkq0" data-path="src/pages/calculators/BMICalculator.tsx">Medical Advice</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="5yswfyok5" data-path="src/pages/calculators/BMICalculator.tsx">
                    {bmiCategory === "Underweight" &&
                    <>
                        <p className="mb-2" data-id="yrsyjuem1" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="v8oslaz2c" data-path="src/pages/calculators/BMICalculator.tsx">Saran Medis:</strong> BMI Anda menunjukkan berat badan kurang. Ini dapat meningkatkan risiko kekurangan nutrisi dan sistem kekebalan yang lemah.</p>
                        <ul className="list-disc pl-6 space-y-1" data-id="i7y3y615b" data-path="src/pages/calculators/BMICalculator.tsx">
                          <li data-id="p3fmreko4" data-path="src/pages/calculators/BMICalculator.tsx">Konsultasikan dengan dokter atau ahli gizi untuk evaluasi kesehatan</li>
                          <li data-id="veeuc9i7f" data-path="src/pages/calculators/BMICalculator.tsx">Fokus pada makanan padat nutrisi dan kaya kalori yang sehat</li>
                          <li data-id="qy683dm3x" data-path="src/pages/calculators/BMICalculator.tsx">Pertimbangkan untuk menambah porsi makan atau frekuensi makan</li>
                          <li data-id="wxga48fkw" data-path="src/pages/calculators/BMICalculator.tsx">Tambahkan latihan kekuatan untuk membangun massa otot</li>
                        </ul>
                      </>
                    }
                    
                    {bmiCategory === "Normal weight" &&
                    <>
                        <p className="mb-2" data-id="v75eui19h" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="7lyenexj2" data-path="src/pages/calculators/BMICalculator.tsx">Saran Medis:</strong> BMI Anda dalam rentang sehat. Ini bagus! Pertahankan kebiasaan sehat Anda.</p>
                        <ul className="list-disc pl-6 space-y-1" data-id="iz6d3r245" data-path="src/pages/calculators/BMICalculator.tsx">
                          <li data-id="xwv3f7oxn" data-path="src/pages/calculators/BMICalculator.tsx">Lanjutkan pola makan seimbang dengan berbagai nutrisi</li>
                          <li data-id="zl2zpceue" data-path="src/pages/calculators/BMICalculator.tsx">Jaga aktivitas fisik secara teratur (minimal 150 menit/minggu)</li>
                          <li data-id="372jtmrzk" data-path="src/pages/calculators/BMICalculator.tsx">Lakukan pemeriksaan kesehatan rutin</li>
                          <li data-id="jgvjd7eap" data-path="src/pages/calculators/BMICalculator.tsx">Perhatikan perubahan berat badan yang signifikan</li>
                        </ul>
                      </>
                    }
                    
                    {(bmiCategory === "Overweight" || bmiCategory.includes("Obesity")) &&
                    <>
                        <p className="mb-2" data-id="e1qcfwqis" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="zav4o8yqf" data-path="src/pages/calculators/BMICalculator.tsx">Saran Medis:</strong> BMI Anda menunjukkan {bmiCategory === "Overweight" ? "kelebihan berat badan" : "obesitas"}. Ini dapat meningkatkan risiko berbagai masalah kesehatan seperti diabetes, penyakit jantung, dan tekanan darah tinggi.</p>
                        <ul className="list-disc pl-6 space-y-1" data-id="2jh20nupk" data-path="src/pages/calculators/BMICalculator.tsx">
                          <li data-id="pzh29tjix" data-path="src/pages/calculators/BMICalculator.tsx">Pertimbangkan untuk berkonsultasi dengan profesional kesehatan</li>
                          <li data-id="sbwwbc2vh" data-path="src/pages/calculators/BMICalculator.tsx">Mulai program penurunan berat badan yang realistis dan bertahap</li>
                          <li data-id="zf6a2ejg8" data-path="src/pages/calculators/BMICalculator.tsx">Tingkatkan aktivitas fisik (mulai secara bertahap)</li>
                          <li data-id="0rrjffekn" data-path="src/pages/calculators/BMICalculator.tsx">Fokus pada diet seimbang dengan porsi terkontrol</li>
                          <li data-id="nhqfpc7ye" data-path="src/pages/calculators/BMICalculator.tsx">Pantau tekanan darah, gula darah, dan kolesterol secara teratur</li>
                        </ul>
                      </>
                    }
                    <p className="mt-3 text-sm italic" data-id="uteec3q32" data-path="src/pages/calculators/BMICalculator.tsx">Disclaimer: Informasi ini bersifat umum dan tidak menggantikan nasihat medis profesional. Selalu konsultasikan dengan dokter sebelum memulai program diet atau olahraga baru.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          }

        <div className="mt-8 bg-slate-50 p-6 rounded-lg prose prose-slate max-w-none" data-id="n9ixszsrl" data-path="src/pages/calculators/BMICalculator.tsx">
          <h2 className="text-2xl font-bold text-gray-900 mb-4" data-id="9yto5bioi" data-path="src/pages/calculators/BMICalculator.tsx">Understanding Your Body Mass Index (BMI)</h2>
          
          <img
              src="https://images.unsplash.com/photo-1594882645126-14020914d58d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80"
              alt="BMI measurement concept"
              className="w-full h-[300px] object-cover rounded-lg mb-6" data-id="du1earhey" data-path="src/pages/calculators/BMICalculator.tsx" />

          
          <h3 className="text-xl font-semibold mb-2" data-id="2xxc2meq9" data-path="src/pages/calculators/BMICalculator.tsx">What is BMI?</h3>
          <p className="mb-4" data-id="09153f86j" data-path="src/pages/calculators/BMICalculator.tsx">
            Body Mass Index (BMI) or Indeks Massa Tubuh (IMT) is a simple calculation based on your height and weight. BMI is widely used as a screening tool to identify possible weight problems in adults and is calculated using the formula: BMI = weight(kg) / height²(m²).
          </p>
          
          <h3 className="text-xl font-semibold mb-2" data-id="8vofiky1b" data-path="src/pages/calculators/BMICalculator.tsx">BMI Categories and Health Risks</h3>
          <div className="overflow-x-auto mb-6" data-id="aqgekzfsi" data-path="src/pages/calculators/BMICalculator.tsx">
            <table className="min-w-full border border-gray-300" data-id="8dliwsw9o" data-path="src/pages/calculators/BMICalculator.tsx">
              <thead data-id="8ewbm3i9s" data-path="src/pages/calculators/BMICalculator.tsx">
                <tr className="bg-blue-100" data-id="91bvldue2" data-path="src/pages/calculators/BMICalculator.tsx">
                  <th className="border px-4 py-2" data-id="8s6rmvovc" data-path="src/pages/calculators/BMICalculator.tsx">BMI Range</th>
                  <th className="border px-4 py-2" data-id="m7gck9fja" data-path="src/pages/calculators/BMICalculator.tsx">Weight Category</th>
                  <th className="border px-4 py-2" data-id="rl130rnqg" data-path="src/pages/calculators/BMICalculator.tsx">Health Risk</th>
                </tr>
              </thead>
              <tbody data-id="5az2uljzw" data-path="src/pages/calculators/BMICalculator.tsx">
                <tr data-id="sts1sbkt5" data-path="src/pages/calculators/BMICalculator.tsx">
                  <td className="border px-4 py-2" data-id="dpn4h7c5l" data-path="src/pages/calculators/BMICalculator.tsx">Below 18.5</td>
                  <td className="border px-4 py-2" data-id="f9v53ruum" data-path="src/pages/calculators/BMICalculator.tsx">Underweight</td>
                  <td className="border px-4 py-2" data-id="4stt2bjzx" data-path="src/pages/calculators/BMICalculator.tsx">Increased risk of nutritional deficiencies, osteoporosis, and weakened immune system</td>
                </tr>
                <tr className="bg-green-50" data-id="khwusw0l7" data-path="src/pages/calculators/BMICalculator.tsx">
                  <td className="border px-4 py-2" data-id="jqi97usog" data-path="src/pages/calculators/BMICalculator.tsx">18.5 to 24.9</td>
                  <td className="border px-4 py-2" data-id="ekaoh35yw" data-path="src/pages/calculators/BMICalculator.tsx">Normal weight</td>
                  <td className="border px-4 py-2" data-id="0m7tnv6go" data-path="src/pages/calculators/BMICalculator.tsx">Lowest risk of health problems related to weight</td>
                </tr>
                <tr data-id="gy0k3jo8q" data-path="src/pages/calculators/BMICalculator.tsx">
                  <td className="border px-4 py-2" data-id="wr2gldy0p" data-path="src/pages/calculators/BMICalculator.tsx">25.0 to 29.9</td>
                  <td className="border px-4 py-2" data-id="2hwz4tfrw" data-path="src/pages/calculators/BMICalculator.tsx">Overweight</td>
                  <td className="border px-4 py-2" data-id="l53t7tevf" data-path="src/pages/calculators/BMICalculator.tsx">Increased risk of heart disease, high blood pressure, stroke, type 2 diabetes</td>
                </tr>
                <tr data-id="ma0u5rzin" data-path="src/pages/calculators/BMICalculator.tsx">
                  <td className="border px-4 py-2" data-id="knghus2ec" data-path="src/pages/calculators/BMICalculator.tsx">30.0 to 34.9</td>
                  <td className="border px-4 py-2" data-id="lkzag8qc9" data-path="src/pages/calculators/BMICalculator.tsx">Obesity (Class 1)</td>
                  <td className="border px-4 py-2" data-id="02i6gya5f" data-path="src/pages/calculators/BMICalculator.tsx">High risk of the above conditions, plus osteoarthritis, gallbladder disease</td>
                </tr>
                <tr data-id="mpa185t0i" data-path="src/pages/calculators/BMICalculator.tsx">
                  <td className="border px-4 py-2" data-id="9qyp161q5" data-path="src/pages/calculators/BMICalculator.tsx">35.0 to 39.9</td>
                  <td className="border px-4 py-2" data-id="s28l4ednt" data-path="src/pages/calculators/BMICalculator.tsx">Obesity (Class 2)</td>
                  <td className="border px-4 py-2" data-id="wzd8ag8q7" data-path="src/pages/calculators/BMICalculator.tsx">Very high risk of developing health problems</td>
                </tr>
                <tr data-id="55h2x5epm" data-path="src/pages/calculators/BMICalculator.tsx">
                  <td className="border px-4 py-2" data-id="whghgmr5e" data-path="src/pages/calculators/BMICalculator.tsx">40.0 and above</td>
                  <td className="border px-4 py-2" data-id="guacrobib" data-path="src/pages/calculators/BMICalculator.tsx">Obesity (Class 3)</td>
                  <td className="border px-4 py-2" data-id="bcekxe56m" data-path="src/pages/calculators/BMICalculator.tsx">Extremely high risk of health problems, severe quality of life impairments</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <h3 className="text-xl font-semibold mb-2" data-id="38z7870be" data-path="src/pages/calculators/BMICalculator.tsx">How BMI is Calculated</h3>
          <p className="mb-4" data-id="9j0ues660" data-path="src/pages/calculators/BMICalculator.tsx">
            BMI is calculated using one of these formulas:
          </p>
          <ul className="list-disc pl-6 mb-4" data-id="rz15x6wb0" data-path="src/pages/calculators/BMICalculator.tsx">
            <li data-id="yk94ukml7" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="724ogwzl1" data-path="src/pages/calculators/BMICalculator.tsx">Metric Units:</strong> BMI = weight (kg) / [height (m)]²</li>
            <li data-id="d3s6jevuk" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="614itzyuk" data-path="src/pages/calculators/BMICalculator.tsx">Imperial Units:</strong> BMI = 703 × weight (lbs) / [height (in)]²</li>
          </ul>
          
          <div className="bg-blue-50 p-4 rounded-lg mb-6" data-id="i5xzvr2a2" data-path="src/pages/calculators/BMICalculator.tsx">
            <h4 className="text-lg font-semibold mb-2" data-id="g6eihg0g5" data-path="src/pages/calculators/BMICalculator.tsx">Example Calculation:</h4>
            <p data-id="0y6m5poo2" data-path="src/pages/calculators/BMICalculator.tsx">For a person weighing 70 kg and standing 170 cm tall:</p>
            <ul className="list-disc pl-6" data-id="z92g57mm5" data-path="src/pages/calculators/BMICalculator.tsx">
              <li data-id="e6hxbtx95" data-path="src/pages/calculators/BMICalculator.tsx">Height in meters: 1.70 m</li>
              <li data-id="iyf14mecf" data-path="src/pages/calculators/BMICalculator.tsx">Height squared: 1.70 × 1.70 = 2.89 m²</li>
              <li data-id="tytg6jsqr" data-path="src/pages/calculators/BMICalculator.tsx">BMI calculation: 70 ÷ 2.89 = 24.2 kg/m²</li>
              <li data-id="6z53dl6lb" data-path="src/pages/calculators/BMICalculator.tsx">This person's BMI of 24.2 places them in the Normal weight category.</li>
            </ul>
          </div>
          
          <h3 className="text-xl font-semibold mb-2" data-id="rezyydemz" data-path="src/pages/calculators/BMICalculator.tsx">Limitations of BMI</h3>
          <p className="mb-4" data-id="w85gn6srn" data-path="src/pages/calculators/BMICalculator.tsx">
            While BMI is a useful screening tool, it has several limitations:
          </p>
          <ul className="list-disc pl-6 mb-4" data-id="v9x1zca73" data-path="src/pages/calculators/BMICalculator.tsx">
            <li data-id="fpooy1ecx" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="he9w79myq" data-path="src/pages/calculators/BMICalculator.tsx">Muscle Mass:</strong> BMI doesn't distinguish between muscle and fat. Athletes and bodybuilders may have a high BMI due to muscle mass rather than excess fat.</li>
            <li data-id="e7ec7p0z4" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="goovbtbde" data-path="src/pages/calculators/BMICalculator.tsx">Body Composition:</strong> BMI doesn't account for differences in bone density, muscle mass, or fat distribution.</li>
            <li data-id="hhmpmxcmq" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="05zhk487g" data-path="src/pages/calculators/BMICalculator.tsx">Age Considerations:</strong> BMI may not be as accurate for elderly individuals who have lost muscle mass.</li>
            <li data-id="gak1lj8oo" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="j6o7kkk1w" data-path="src/pages/calculators/BMICalculator.tsx">Ethnic Differences:</strong> Different ethnic groups may have different body compositions and health risks at the same BMI.</li>
            <li data-id="favdjjk1v" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="2592i7etc" data-path="src/pages/calculators/BMICalculator.tsx">Pregnancy:</strong> BMI is not applicable for pregnant women.</li>
          </ul>
          
          <h3 className="text-xl font-semibold mb-2" data-id="rd0wd4q14" data-path="src/pages/calculators/BMICalculator.tsx">BMI for Different Populations</h3>
          <p className="mb-4" data-id="ihkr5iz61" data-path="src/pages/calculators/BMICalculator.tsx">
            Research has shown that BMI thresholds may need to be adjusted for different populations:
          </p>
          <ul className="list-disc pl-6 mb-6" data-id="5rcikg8te" data-path="src/pages/calculators/BMICalculator.tsx">
            <li data-id="p65gd806w" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="kiouz2mym" data-path="src/pages/calculators/BMICalculator.tsx">Asian Populations:</strong> Health risks may begin at a lower BMI. Some experts suggest that for Asian populations, a BMI of 23 or higher may indicate increased health risks.</li>
            <li data-id="7zzt6wrj7" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="8nptd0xw4" data-path="src/pages/calculators/BMICalculator.tsx">Children and Teenagers:</strong> BMI is calculated the same way for children, but the interpretation is different and takes into account age and sex using percentile rankings.</li>
            <li data-id="y0z1ki2fq" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="70nbwfmlw" data-path="src/pages/calculators/BMICalculator.tsx">Elderly:</strong> BMI thresholds may be slightly higher for older adults due to natural changes in body composition with aging.</li>
          </ul>
          
          <h3 className="text-xl font-semibold mb-2" data-id="d2yic3tgq" data-path="src/pages/calculators/BMICalculator.tsx">Beyond BMI: Other Health Indicators</h3>
          <p className="mb-4" data-id="rx48xxpdk" data-path="src/pages/calculators/BMICalculator.tsx">
            For a more complete assessment of health, BMI should be used alongside other indicators:
          </p>
          <ul className="list-disc pl-6 mb-6" data-id="dhfsj6q4t" data-path="src/pages/calculators/BMICalculator.tsx">
            <li data-id="elcxj4qxu" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="vzr9q7t20" data-path="src/pages/calculators/BMICalculator.tsx">Waist Circumference:</strong> A waist measurement of over 35 inches (88 cm) for women and over 40 inches (102 cm) for men indicates increased health risk.</li>
            <li data-id="y6odlxag1" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="549ds3e48" data-path="src/pages/calculators/BMICalculator.tsx">Waist-to-Hip Ratio:</strong> This measures fat distribution and can indicate health risks related to "apple" versus "pear" body shapes.</li>
            <li data-id="fgfjhx59q" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="a60w8ahk7" data-path="src/pages/calculators/BMICalculator.tsx">Body Fat Percentage:</strong> Directly measures the proportion of body fat, providing a more accurate assessment of body composition.</li>
            <li data-id="50tr4gohz" data-path="src/pages/calculators/BMICalculator.tsx"><strong data-id="bidhcjk4f" data-path="src/pages/calculators/BMICalculator.tsx">Blood Pressure, Cholesterol, and Blood Sugar Levels:</strong> These metabolic indicators can identify health risks even when BMI is in a healthy range.</li>
          </ul>
          
          <h3 className="text-xl font-semibold mb-2" data-id="mxuujie3s" data-path="src/pages/calculators/BMICalculator.tsx">Actions to Take Based on Your BMI</h3>
          <div className="mb-6" data-id="x0om5gmn5" data-path="src/pages/calculators/BMICalculator.tsx">
            <h4 className="text-lg font-semibold mb-2" data-id="w6t4eda09" data-path="src/pages/calculators/BMICalculator.tsx">If Your BMI is Below 18.5 (Underweight):</h4>
            <ul className="list-disc pl-6 mb-4" data-id="6r2s5tcd7" data-path="src/pages/calculators/BMICalculator.tsx">
              <li data-id="yw2lvdyc6" data-path="src/pages/calculators/BMICalculator.tsx">Consider consulting with a healthcare provider to rule out underlying medical conditions</li>
              <li data-id="z15spoary" data-path="src/pages/calculators/BMICalculator.tsx">Work with a dietitian to develop a healthy weight gain plan</li>
              <li data-id="4zb6j38f2" data-path="src/pages/calculators/BMICalculator.tsx">Focus on nutrient-dense foods with adequate protein, healthy fats, and complex carbohydrates</li>
              <li data-id="ck2x4eixw" data-path="src/pages/calculators/BMICalculator.tsx">Incorporate strength training to build muscle mass</li>
            </ul>
            
            <h4 className="text-lg font-semibold mb-2" data-id="guvb7lh9j" data-path="src/pages/calculators/BMICalculator.tsx">If Your BMI is 18.5-24.9 (Normal Weight):</h4>
            <ul className="list-disc pl-6 mb-4" data-id="cuosa0nig" data-path="src/pages/calculators/BMICalculator.tsx">
              <li data-id="l30vtz2fv" data-path="src/pages/calculators/BMICalculator.tsx">Maintain your current healthy habits</li>
              <li data-id="9irpjocm9" data-path="src/pages/calculators/BMICalculator.tsx">Engage in regular physical activity (at least 150 minutes of moderate activity per week)</li>
              <li data-id="63kljw4ln" data-path="src/pages/calculators/BMICalculator.tsx">Follow a balanced diet rich in fruits, vegetables, whole grains, and lean proteins</li>
              <li data-id="4bn3zyd3m" data-path="src/pages/calculators/BMICalculator.tsx">Continue regular health check-ups to monitor overall wellness</li>
            </ul>
            
            <h4 className="text-lg font-semibold mb-2" data-id="c7a2zhd8c" data-path="src/pages/calculators/BMICalculator.tsx">If Your BMI is 25.0-29.9 (Overweight):</h4>
            <ul className="list-disc pl-6 mb-4" data-id="7rgrehaag" data-path="src/pages/calculators/BMICalculator.tsx">
              <li data-id="xc05zobd9" data-path="src/pages/calculators/BMICalculator.tsx">Consider a gradual weight loss goal of 5-10% of your current weight</li>
              <li data-id="h14cxzebd" data-path="src/pages/calculators/BMICalculator.tsx">Increase physical activity to at least 150-300 minutes per week</li>
              <li data-id="24frgag5e" data-path="src/pages/calculators/BMICalculator.tsx">Focus on portion control and reducing intake of highly processed foods</li>
              <li data-id="9vhhglqse" data-path="src/pages/calculators/BMICalculator.tsx">Monitor other health markers like blood pressure and blood sugar</li>
            </ul>
            
            <h4 className="text-lg font-semibold mb-2" data-id="uth4v754t" data-path="src/pages/calculators/BMICalculator.tsx">If Your BMI is 30.0 or Higher (Obesity):</h4>
            <ul className="list-disc pl-6" data-id="srpyt1sij" data-path="src/pages/calculators/BMICalculator.tsx">
              <li data-id="dyq0j9t2w" data-path="src/pages/calculators/BMICalculator.tsx">Consult with healthcare providers for a comprehensive health assessment</li>
              <li data-id="fo2qh5gzk" data-path="src/pages/calculators/BMICalculator.tsx">Consider working with a team including a doctor, dietitian, and possibly a therapist or coach</li>
              <li data-id="nw9hln758" data-path="src/pages/calculators/BMICalculator.tsx">Set realistic, gradual weight loss goals (1-2 pounds per week)</li>
              <li data-id="j113kvp28" data-path="src/pages/calculators/BMICalculator.tsx">Focus on sustainable lifestyle changes rather than quick fixes</li>
              <li data-id="yqlbzvuro" data-path="src/pages/calculators/BMICalculator.tsx">Get screened for weight-related health conditions</li>
              <li data-id="ddbi71aqu" data-path="src/pages/calculators/BMICalculator.tsx">Consider behavioral strategies to support long-term changes</li>
            </ul>
          </div>
          
          <h3 className="text-xl font-semibold mb-2" data-id="99uwe58mq" data-path="src/pages/calculators/BMICalculator.tsx">BMI in Indonesian Public Health Context</h3>
          <p className="mb-6" data-id="9ae62cglt" data-path="src/pages/calculators/BMICalculator.tsx">
            In Indonesia, BMI guidelines are similar to international standards but with some adaptations. The Indonesian Ministry of Health uses BMI to assess nutritional status and monitor public health trends. Public health initiatives in Indonesia often focus on addressing both undernutrition and the growing obesity epidemic, with BMI serving as an important tracking metric.
          </p>
          
          <div className="bg-yellow-50 p-4 rounded-lg mb-6" data-id="kmfgxzntr" data-path="src/pages/calculators/BMICalculator.tsx">
            <h4 className="text-lg font-semibold mb-2" data-id="ceqtxdepn" data-path="src/pages/calculators/BMICalculator.tsx">Important Note:</h4>
            <p data-id="f643so4n0" data-path="src/pages/calculators/BMICalculator.tsx">
              BMI is a screening tool, not a diagnostic tool. A high or low BMI should prompt further assessment by healthcare professionals to evaluate overall health status and identify appropriate interventions. Always consult with healthcare providers before making significant changes to your diet or exercise routine.
            </p>
          </div>
          
          <h3 className="text-xl font-semibold mb-2" data-id="sf54y9usg" data-path="src/pages/calculators/BMICalculator.tsx">FAQs About BMI</h3>
          <div className="space-y-4 mb-6" data-id="cwc9ja83f" data-path="src/pages/calculators/BMICalculator.tsx">
            <div data-id="ovv9qqh7z" data-path="src/pages/calculators/BMICalculator.tsx">
              <h4 className="font-semibold" data-id="yw0vzcpxv" data-path="src/pages/calculators/BMICalculator.tsx">Is BMI accurate for all body types?</h4>
              <p data-id="3l152mmcc" data-path="src/pages/calculators/BMICalculator.tsx">No, BMI has limitations, particularly for athletes, bodybuilders, pregnant women, and elderly individuals. It doesn't account for differences in muscle mass, bone density, or fat distribution.</p>
            </div>
            <div data-id="drxr0y7ky" data-path="src/pages/calculators/BMICalculator.tsx">
              <h4 className="font-semibold" data-id="vqfe1doz7" data-path="src/pages/calculators/BMICalculator.tsx">Can my BMI category change with age?</h4>
              <p data-id="b9j9cerkp" data-path="src/pages/calculators/BMICalculator.tsx">Yes, body composition naturally changes with age. Muscle mass tends to decrease and fat mass often increases with age, which can affect BMI. Some health experts suggest slightly higher BMI targets may be appropriate for older adults.</p>
            </div>
            <div data-id="6h39fu70i" data-path="src/pages/calculators/BMICalculator.tsx">
              <h4 className="font-semibold" data-id="514u1j0gf" data-path="src/pages/calculators/BMICalculator.tsx">How often should I check my BMI?</h4>
              <p data-id="ibby2r6yv" data-path="src/pages/calculators/BMICalculator.tsx">For most adults, checking BMI once or twice a year is sufficient, often as part of regular health check-ups. If you're actively trying to gain or lose weight, you might track it more frequently alongside other metrics.</p>
            </div>
            <div data-id="xz8qb76yy" data-path="src/pages/calculators/BMICalculator.tsx">
              <h4 className="font-semibold" data-id="tidzumedl" data-path="src/pages/calculators/BMICalculator.tsx">Can BMI predict my health risks?</h4>
              <p data-id="9d6hqrdrv" data-path="src/pages/calculators/BMICalculator.tsx">BMI is associated with certain health risks, but it's not a perfect predictor of individual health. Other factors like family history, lifestyle, and specific health markers provide a more complete picture of health status and risk.</p>
            </div>
          </div>
          
          <div className="bg-slate-100 p-4 rounded-lg italic mt-8" data-id="o1eyg3vq0" data-path="src/pages/calculators/BMICalculator.tsx">
            <p className="text-sm" data-id="vrvzv1fx5" data-path="src/pages/calculators/BMICalculator.tsx">
              Disclaimer: The information provided in this article is for educational purposes only and does not constitute medical advice. Always consult with qualified healthcare providers for personalized medical guidance, particularly before making significant changes to your diet, exercise routine, or health management approach.
            </p>
          </div>
        </div>

        <div className="mt-6 text-gray-700" data-id="d80w8h6rm" data-path="src/pages/calculators/BMICalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="cifn6yri4" data-path="src/pages/calculators/BMICalculator.tsx">Kalkulator BMI Indonesia: Apa Itu BMI?</h3>
          <p className="mb-4" data-id="f9gw230hb" data-path="src/pages/calculators/BMICalculator.tsx">
            Body Mass Index (BMI) atau Indeks Massa Tubuh (IMT) adalah perhitungan sederhana yang menggunakan tinggi dan berat badan seseorang. BMI calculator Indonesia ini menggunakan rumus BMI = kg/m² di mana kg adalah berat badan seseorang dalam kilogram dan m² adalah tinggi dalam meter kuadrat.
          </p>
          <p className="mb-4" data-id="qxgnll91v" data-path="src/pages/calculators/BMICalculator.tsx">
            Di Indonesia, kalkulator BMI (BMI calculator Indonesia) menjadi alat yang semakin populer untuk memantau kesehatan. BMI 25,0 atau lebih dianggap kelebihan berat badan, sementara rentang sehat adalah 18,5 hingga 24,9. BMI berlaku untuk sebagian besar orang dewasa berusia 18-65 tahun.
          </p>
          <h3 className="text-lg font-semibold mb-2" data-id="75ou8y85p" data-path="src/pages/calculators/BMICalculator.tsx">Kategori BMI:</h3>
          <ul className="list-disc pl-6 space-y-1" data-id="inxulnbg4" data-path="src/pages/calculators/BMICalculator.tsx">
            <li data-id="3neiev2wz" data-path="src/pages/calculators/BMICalculator.tsx">Berat Badan Kurang (Underweight) = kurang dari 18,5</li>
            <li data-id="bgs1j3sq1" data-path="src/pages/calculators/BMICalculator.tsx">Berat Badan Normal (Normal weight) = 18,5 sampai 24,9</li>
            <li data-id="kg4ylpnz7" data-path="src/pages/calculators/BMICalculator.tsx">Kelebihan Berat Badan (Overweight) = 25 sampai 29,9</li>
            <li data-id="km8h7lnip" data-path="src/pages/calculators/BMICalculator.tsx">Obesitas Kelas 1 (Obesity Class 1) = 30 sampai 34,9</li>
            <li data-id="3nwxn6lf3" data-path="src/pages/calculators/BMICalculator.tsx">Obesitas Kelas 2 (Obesity Class 2) = 35 sampai 39,9</li>
            <li data-id="hgewd0kie" data-path="src/pages/calculators/BMICalculator.tsx">Obesitas Kelas 3 (Obesity Class 3) = 40 atau lebih</li>
          </ul>
          <p className="mt-4 mb-4" data-id="pskr38py5" data-path="src/pages/calculators/BMICalculator.tsx">
            Menggunakan kalkulator BMI Indonesia ini secara rutin dapat membantu Anda memantau berat badan ideal dan membuat pilihan gaya hidup yang lebih sehat sesuai dengan standar kesehatan di Indonesia.  
          </p>
          
          <div className="bg-blue-50 p-4 rounded-md mt-6" data-id="jkguzpa1a" data-path="src/pages/calculators/BMICalculator.tsx">
            <h4 className="font-semibold mb-2" data-id="ul1jsz8xv" data-path="src/pages/calculators/BMICalculator.tsx">Hitung Lebih Jauh Kebutuhan Tubuh Anda:</h4>
            <p className="mb-3" data-id="fkstzhtn7" data-path="src/pages/calculators/BMICalculator.tsx">Untuk pemahaman yang lebih komprehensif tentang kesehatan Anda, kami menyarankan untuk juga menghitung:</p>
            <ul className="list-disc pl-6 space-y-1" data-id="6kw4lbkxo" data-path="src/pages/calculators/BMICalculator.tsx">
              <li data-id="y4wdnn7hl" data-path="src/pages/calculators/BMICalculator.tsx"><Link to="/calculators/bmr" className="text-blue-600 hover:underline">BMR (Basal Metabolic Rate)</Link> - Mengetahui kebutuhan kalori dasar tubuh Anda</li>
              <li data-id="o9tks0czg" data-path="src/pages/calculators/BMICalculator.tsx"><Link to="/calculators/tdee" className="text-blue-600 hover:underline">TDEE (Total Daily Energy Expenditure)</Link> - Menghitung kebutuhan kalori harian total</li>
              <li data-id="t30acri7s" data-path="src/pages/calculators/BMICalculator.tsx"><Link to="/calculators/ideal-weight" className="text-blue-600 hover:underline">Berat Badan Ideal</Link> - Memeriksa berat yang ideal untuk tubuh Anda</li>
              <li data-id="n55s7k2tn" data-path="src/pages/calculators/BMICalculator.tsx"><Link to="/calculators/body-fat" className="text-blue-600 hover:underline">Persentase Lemak Tubuh</Link> - Estimasi persentase lemak dalam tubuh Anda</li>
              <li data-id="p55e1vovk" data-path="src/pages/calculators/BMICalculator.tsx"><Link to="/blog/bmi-guide" className="text-blue-600 hover:underline">Panduan Lengkap BMI</Link> - Mempelajari lebih dalam tentang BMI</li>
            </ul>
          </div>
          
          <div className="mt-6 p-3 border-l-4 border-blue-500 bg-blue-50" data-id="zgghm94do" data-path="src/pages/calculators/BMICalculator.tsx">
            <p className="text-sm italic" data-id="wmuh850c8" data-path="src/pages/calculators/BMICalculator.tsx">Semua kalkulator kami telah ditinjau secara medis dan menggunakan rumus yang diakui secara ilmiah untuk memberikan hasil yang akurat.</p>
          </div>
        </div>
      </div>
    </CalculatorLayout>
    </>);


};

export default BMICalculator;