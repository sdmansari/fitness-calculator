import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

const BodyFatCalculator = () => {
  const [method, setMethod] = useState("navy");
  const [gender, setGender] = useState("male");
  const [unit, setUnit] = useState("metric");
  const [age, setAge] = useState("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [neck, setNeck] = useState("");
  const [waist, setWaist] = useState("");
  const [hip, setHip] = useState("");
  const [bodyFat, setBodyFat] = useState<number | null>(null);
  const [category, setCategory] = useState("");
  const [error, setError] = useState("");

  const calculateBodyFat = () => {
    setError("");

    try {
      let heightInCm: number;
      let waistInCm = parseFloat(waist);
      let neckInCm = parseFloat(neck);
      let hipInCm = gender === "female" ? parseFloat(hip) : 0;

      // Convert imperial measurements to metric if needed
      if (unit === "imperial") {
        const feetValue = parseFloat(feet);
        const inchesValue = parseFloat(inches);

        if (isNaN(feetValue) || isNaN(inchesValue)) {
          throw new Error("Please enter valid height values");
        }

        heightInCm = (feetValue * 12 + inchesValue) * 2.54;
        waistInCm = waistInCm * 2.54;
        neckInCm = neckInCm * 2.54;
        if (gender === "female") {
          hipInCm = hipInCm * 2.54;
        }
      } else {
        heightInCm = parseFloat(height);
      }

      if (isNaN(heightInCm) || isNaN(waistInCm) || isNaN(neckInCm) ||
      gender === "female" && isNaN(hipInCm) ||
      heightInCm <= 0 || waistInCm <= 0 || neckInCm <= 0 ||
      gender === "female" && hipInCm <= 0) {
        throw new Error("Please enter valid measurements");
      }

      // U.S. Navy Method formula
      let calculatedBodyFat = 0;

      if (gender === "male") {
        const logValue = Math.log10(waistInCm - neckInCm);
        calculatedBodyFat = 495 / (1.0324 - 0.19077 * logValue + 0.15456 * Math.log10(heightInCm)) - 450;
      } else {
        const logValue = Math.log10(waistInCm + hipInCm - neckInCm);
        calculatedBodyFat = 495 / (1.29579 - 0.35004 * logValue + 0.22100 * Math.log10(heightInCm)) - 450;
      }

      setBodyFat(Math.round(calculatedBodyFat * 10) / 10);

      // Determine body fat category
      if (gender === "male") {
        if (calculatedBodyFat < 6) {
          setCategory("Essential Fat");
        } else if (calculatedBodyFat < 14) {
          setCategory("Athletic");
        } else if (calculatedBodyFat < 18) {
          setCategory("Fitness");
        } else if (calculatedBodyFat < 25) {
          setCategory("Average");
        } else {
          setCategory("Obese");
        }
      } else {
        if (calculatedBodyFat < 16) {
          setCategory("Essential Fat");
        } else if (calculatedBodyFat < 24) {
          setCategory("Athletic");
        } else if (calculatedBodyFat < 31) {
          setCategory("Fitness");
        } else if (calculatedBodyFat < 36) {
          setCategory("Average");
        } else {
          setCategory("Obese");
        }
      }
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setBodyFat(null);
      setCategory("");
    }
  };

  const resetCalculator = () => {
    setHeight("");
    setWeight("");
    setFeet("");
    setInches("");
    setNeck("");
    setWaist("");
    setHip("");
    setBodyFat(null);
    setCategory("");
    setError("");
  };

  return (
    <CalculatorLayout
      title="Body Fat Calculator"
      description="Calculate your body fat percentage using the U.S. Navy method."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="zamedmd14" data-path="src/pages/calculators/BodyFatCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" data-id="t2v3n9i0e" data-path="src/pages/calculators/BodyFatCalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="7zzekagvi" data-path="src/pages/calculators/BodyFatCalculator.tsx">
        <div data-id="15hin2azy" data-path="src/pages/calculators/BodyFatCalculator.tsx">
          <Label className="text-lg font-medium">Gender</Label>
          <RadioGroup
            value={gender}
            onValueChange={setGender}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="7uhgiscbb" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">Male</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="h25ddhf6v" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">Female</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div data-id="ing68fu48" data-path="src/pages/calculators/BodyFatCalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
            value={unit}
            onValueChange={setUnit}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="3dqex61hh" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (cm)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="7cm4xdjcu" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (ft, in)</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div className="space-y-4" data-id="i5oin0v41" data-path="src/pages/calculators/BodyFatCalculator.tsx">
          {unit === "metric" ?
          <div className="space-y-2" data-id="4ck2ku2oh" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <Label htmlFor="height">Height (cm)</Label>
              <Input
              id="height"
              type="number"
              placeholder="e.g., 170"
              value={height}
              onChange={(e) => setHeight(e.target.value)} />

            </div> :

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="lyr32gace" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <div className="space-y-2" data-id="ihskeru9i" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                <Label htmlFor="feet">Height (ft)</Label>
                <Input
                id="feet"
                type="number"
                placeholder="e.g., 5"
                value={feet}
                onChange={(e) => setFeet(e.target.value)} />

              </div>
              <div className="space-y-2" data-id="86yv6yrup" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                <Label htmlFor="inches">Height (in)</Label>
                <Input
                id="inches"
                type="number"
                placeholder="e.g., 10"
                value={inches}
                onChange={(e) => setInches(e.target.value)} />

              </div>
            </div>
          }

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="s1ivckgy4" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            <div className="space-y-2" data-id="04njsukyv" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <Label htmlFor="neck">Neck Circumference {unit === "metric" ? "(cm)" : "(inches)"}</Label>
              <Input
                id="neck"
                type="number"
                placeholder={unit === "metric" ? "e.g., 36" : "e.g., 14"}
                value={neck}
                onChange={(e) => setNeck(e.target.value)} />

            </div>
            <div className="space-y-2" data-id="2xjdflgb4" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <Label htmlFor="waist">Waist Circumference {unit === "metric" ? "(cm)" : "(inches)"}</Label>
              <Input
                id="waist"
                type="number"
                placeholder={unit === "metric" ? "e.g., 80" : "e.g., 32"}
                value={waist}
                onChange={(e) => setWaist(e.target.value)} />

            </div>
          </div>

          {gender === "female" &&
          <div className="space-y-2" data-id="73ny55t0p" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <Label htmlFor="hip">Hip Circumference {unit === "metric" ? "(cm)" : "(inches)"}</Label>
              <Input
              id="hip"
              type="number"
              placeholder={unit === "metric" ? "e.g., 90" : "e.g., 35"}
              value={hip}
              onChange={(e) => setHip(e.target.value)} />

            </div>
          }
        </div>

        <div className="flex gap-3" data-id="twfi1eibg" data-path="src/pages/calculators/BodyFatCalculator.tsx">
          <Button
            onClick={calculateBodyFat}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
            Calculate Body Fat
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>
            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="u08audipk" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            {error}
          </div>
        }

        {bodyFat !== null && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="text-center space-y-4" data-id="evospnvaa" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                <div data-id="ejaw3j0qt" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                  <p className="text-lg font-medium" data-id="61sto3gsz" data-path="src/pages/calculators/BodyFatCalculator.tsx">Your Body Fat Percentage</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="d01scww4s" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                    {bodyFat.toFixed(1)}%
                  </p>
                </div>
                <div data-id="eyxslrq6d" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                  <p className="text-lg font-medium" data-id="6wv1rwc0e" data-path="src/pages/calculators/BodyFatCalculator.tsx">Classification</p>
                  <p className={`text-2xl font-bold ${
                category === "Athletic" || category === "Fitness" ?
                "text-green-600" :
                category === "Essential Fat" ?
                "text-orange-500" :
                category === "Average" ?
                "text-yellow-600" :
                "text-red-500"}`
                } data-id="vfoyxkhp4" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                    {category}
                  </p>
                </div>

                <div className="mt-4 border-t pt-4" data-id="8i87l4rrk" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="4gvgcmj8w" data-path="src/pages/calculators/BodyFatCalculator.tsx">Interpretation</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="1umk85m2b" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                    <p className="mb-2" data-id="4qj4wshv2" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                      <strong data-id="gzo45sssy" data-path="src/pages/calculators/BodyFatCalculator.tsx">Body Fat Percentage Categories for {gender === "male" ? "Men" : "Women"}:</strong>
                    </p>
                    {gender === "male" ?
                  <ul className="list-disc pl-6 space-y-1" data-id="ab9vwy7zb" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                        <li data-id="0p34ifdbx" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="1kkoy9yhs" data-path="src/pages/calculators/BodyFatCalculator.tsx">Essential Fat:</strong> 2-5%</li>
                        <li data-id="bqbeduj61" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="911oy6ndc" data-path="src/pages/calculators/BodyFatCalculator.tsx">Athletic:</strong> 6-13%</li>
                        <li data-id="ohpyzgx75" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="w88ccorfc" data-path="src/pages/calculators/BodyFatCalculator.tsx">Fitness:</strong> 14-17%</li>
                        <li data-id="1jgxqfmth" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="hfnbke02e" data-path="src/pages/calculators/BodyFatCalculator.tsx">Average:</strong> 18-24%</li>
                        <li data-id="xb6st85pk" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="mplejkta6" data-path="src/pages/calculators/BodyFatCalculator.tsx">Obese:</strong> 25% and above</li>
                      </ul> :

                  <ul className="list-disc pl-6 space-y-1" data-id="7zirdb59c" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                        <li data-id="6age5p9ie" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="h4tv4fd3i" data-path="src/pages/calculators/BodyFatCalculator.tsx">Essential Fat:</strong> 10-15%</li>
                        <li data-id="p8s161r3d" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="e2q81a01s" data-path="src/pages/calculators/BodyFatCalculator.tsx">Athletic:</strong> 16-23%</li>
                        <li data-id="2gtolbc06" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="miuklwdw4" data-path="src/pages/calculators/BodyFatCalculator.tsx">Fitness:</strong> 24-30%</li>
                        <li data-id="i0zmooby3" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="2wjx2idbr" data-path="src/pages/calculators/BodyFatCalculator.tsx">Average:</strong> 31-35%</li>
                        <li data-id="76143n4hd" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="vjup9gvop" data-path="src/pages/calculators/BodyFatCalculator.tsx">Obese:</strong> 36% and above</li>
                      </ul>
                  }
                    <p className="mt-3 text-sm italic" data-id="3v1fso25u" data-path="src/pages/calculators/BodyFatCalculator.tsx">Disclaimer: This calculation provides an estimate and should not replace professional medical evaluations. For the most accurate body fat assessment, consult with a healthcare professional.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="4qclz5oat" data-path="src/pages/calculators/BodyFatCalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="bn8jailnp" data-path="src/pages/calculators/BodyFatCalculator.tsx">About Body Fat Percentage</h3>
          <p className="mb-4" data-id="dnm40r1kw" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            Body fat percentage represents the proportion of fat tissue in your body compared to your total body weight. It's considered a more accurate measure of fitness than BMI because it distinguishes between fat and lean mass.
          </p>
          <h3 className="text-lg font-semibold mb-2" data-id="q6lkqcl99" data-path="src/pages/calculators/BodyFatCalculator.tsx">How to Measure:</h3>
          <ul className="list-disc pl-6 space-y-1" data-id="6ka7z39vj" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            <li data-id="u8dq63y46" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="8as234ncn" data-path="src/pages/calculators/BodyFatCalculator.tsx">Neck:</strong> Measure around the narrowest part, typically just below the Adam's apple for men.</li>
            <li data-id="4s14tm8de" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="m3iax8q7k" data-path="src/pages/calculators/BodyFatCalculator.tsx">Waist:</strong> Measure around the narrowest part of your waist, typically at the navel level.</li>
            <li data-id="cj24azd3m" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="fauvc3jlk" data-path="src/pages/calculators/BodyFatCalculator.tsx">Hips (females only):</strong> Measure around the widest part of your hips and buttocks.</li>
          </ul>
          <p className="mt-4 mb-4" data-id="be8d4kp04" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            The U.S. Navy Method is a circumference-based calculation developed to estimate body fat percentage. While it's not as accurate as methods like DEXA scans or water displacement, it provides a reasonable estimate for most individuals and is widely used in military and fitness settings.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="jc0gx8j85" data-path="src/pages/calculators/BodyFatCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="iiqv2naru" data-path="src/pages/calculators/BodyFatCalculator.tsx">Understanding Body Fat Percentage</h2>
          
          <p className="mb-4" data-id="si8dto321" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            Body fat percentage represents the proportion of your total body weight that is fat. It's a much more meaningful health metric than weight or BMI alone because it distinguishes between fat mass and lean tissue (muscle, bone, organs, and water).
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="h48b77hrm" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="xtv31dsqe" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="7mrj6iny5" data-path="src/pages/calculators/BodyFatCalculator.tsx">Healthy Body Fat Ranges</h3>
              <p className="mb-2" data-id="z3i9r5i8n" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="dk9guf8uj" data-path="src/pages/calculators/BodyFatCalculator.tsx">For Men:</strong></p>
              <ul className="list-disc pl-5 space-y-1" data-id="ey1agaksp" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                <li data-id="hb7mgddo2" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="yz1gcvsg1" data-path="src/pages/calculators/BodyFatCalculator.tsx">Essential fat:</strong> 2-5%</li>
                <li data-id="e6qrcjxrs" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="rza1fswvg" data-path="src/pages/calculators/BodyFatCalculator.tsx">Athletes:</strong> 6-13%</li>
                <li data-id="wx81qbng0" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="32goifpy6" data-path="src/pages/calculators/BodyFatCalculator.tsx">Fitness:</strong> 14-17%</li>
                <li data-id="e1a9pmddq" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="iqyvesm2q" data-path="src/pages/calculators/BodyFatCalculator.tsx">Average:</strong> 18-24%</li>
                <li data-id="7tutk6h8v" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="u5gvc77lx" data-path="src/pages/calculators/BodyFatCalculator.tsx">Obese:</strong> 25%+</li>
              </ul>
              <p className="mt-3 mb-2" data-id="ywxvw6ls1" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="fe3yrogx2" data-path="src/pages/calculators/BodyFatCalculator.tsx">For Women:</strong></p>
              <ul className="list-disc pl-5 space-y-1" data-id="yvmzacnvg" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                <li data-id="45uwrcde3" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="rib6e7h02" data-path="src/pages/calculators/BodyFatCalculator.tsx">Essential fat:</strong> 10-13%</li>
                <li data-id="zxo70udf7" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="fvbsl36wa" data-path="src/pages/calculators/BodyFatCalculator.tsx">Athletes:</strong> 14-20%</li>
                <li data-id="svslcjnuc" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="7ttv2dnw0" data-path="src/pages/calculators/BodyFatCalculator.tsx">Fitness:</strong> 21-24%</li>
                <li data-id="q0g1a3nyd" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="todnjw0kj" data-path="src/pages/calculators/BodyFatCalculator.tsx">Average:</strong> 25-31%</li>
                <li data-id="wzf5zl79b" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="l9f3kl1os" data-path="src/pages/calculators/BodyFatCalculator.tsx">Obese:</strong> 32%+</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="npncros30" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="vqhg6bt7l" data-path="src/pages/calculators/BodyFatCalculator.tsx">Why Body Fat Matters</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="xw5vhogke" data-path="src/pages/calculators/BodyFatCalculator.tsx">
                <li data-id="1a5notdck" data-path="src/pages/calculators/BodyFatCalculator.tsx">Differentiates between muscle loss and fat loss</li>
                <li data-id="agxqx3qyd" data-path="src/pages/calculators/BodyFatCalculator.tsx">Provides better health risk assessment than BMI</li>
                <li data-id="lrerwiutj" data-path="src/pages/calculators/BodyFatCalculator.tsx">Helps track progress during fitness programs</li>
                <li data-id="2hrkkbimy" data-path="src/pages/calculators/BodyFatCalculator.tsx">Enables more personalized nutrition planning</li>
                <li data-id="r0h1jtnqo" data-path="src/pages/calculators/BodyFatCalculator.tsx">Identifies potential health risks from very high or low body fat</li>
                <li data-id="fpx5dd5tr" data-path="src/pages/calculators/BodyFatCalculator.tsx">Provides insights into metabolic health</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="fqil8ra0q" data-path="src/pages/calculators/BodyFatCalculator.tsx">About the Navy Method</h3>
          <p className="mb-4" data-id="b0xyvus1z" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            Our calculator uses the U.S. Navy circumference method, which estimates body fat percentage using measurements from specific body sites. While not as accurate as methods like DEXA scans or hydrostatic weighing, the Navy method provides a reasonable estimate when measurements are taken correctly.
          </p>
          
          <div className="space-y-4 mb-6" data-id="jehychr3s" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="ohlu5gyyz" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <h4 className="font-medium" data-id="1d5sp2g1q" data-path="src/pages/calculators/BodyFatCalculator.tsx">For Men</h4>
              <p className="font-mono text-sm" data-id="cgb13nk07" data-path="src/pages/calculators/BodyFatCalculator.tsx">Body Fat % = 86.010 × log10(waist - neck) - 70.041 × log10(height) + 36.76</p>
              <p className="text-sm text-gray-600 mt-2" data-id="2d5hirgjd" data-path="src/pages/calculators/BodyFatCalculator.tsx">Where waist, neck, and height are in centimeters</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="8ath2y7jd" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              <h4 className="font-medium" data-id="s89kokhh6" data-path="src/pages/calculators/BodyFatCalculator.tsx">For Women</h4>
              <p className="font-mono text-sm" data-id="bfy8acm0c" data-path="src/pages/calculators/BodyFatCalculator.tsx">Body Fat % = 163.205 × log10(waist + hip - neck) - 97.684 × log10(height) - 78.387</p>
              <p className="text-sm text-gray-600 mt-2" data-id="e4g17gg1j" data-path="src/pages/calculators/BodyFatCalculator.tsx">Where waist, hip, neck, and height are in centimeters</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="vqjt9ik0e" data-path="src/pages/calculators/BodyFatCalculator.tsx">Measurement Tips for Accuracy</h3>
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="j0qypvz3d" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            <li data-id="5tk5dqhsx" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="l23s6um76" data-path="src/pages/calculators/BodyFatCalculator.tsx">Use a flexible tape measure</strong>, not a rigid ruler</li>
            <li data-id="qj72u6kfv" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="ap274t94w" data-path="src/pages/calculators/BodyFatCalculator.tsx">Measure consistently</strong> at the same time of day (morning is best)</li>
            <li data-id="eks47e39o" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="0in2ogcy2" data-path="src/pages/calculators/BodyFatCalculator.tsx">For neck:</strong> Measure at the middle of your neck, below the larynx (Adam's apple)</li>
            <li data-id="pmeqh51ia" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="4u7d5pfv6" data-path="src/pages/calculators/BodyFatCalculator.tsx">For waist:</strong> Measure at the narrowest point, typically around the navel</li>
            <li data-id="kd9dmq4eo" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="anr7qphit" data-path="src/pages/calculators/BodyFatCalculator.tsx">For hips:</strong> Measure at the widest point around the buttocks</li>
            <li data-id="clhkdm4sk" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="pjgw58ebx" data-path="src/pages/calculators/BodyFatCalculator.tsx">Keep the tape snug but not tight</strong>, and parallel to the floor</li>
            <li data-id="0regfp1td" data-path="src/pages/calculators/BodyFatCalculator.tsx"><strong data-id="i3ibkel7c" data-path="src/pages/calculators/BodyFatCalculator.tsx">Take each measurement 2-3 times</strong> and use the average</li>
          </ul>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="dvrwbdi5o" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="z2e43fyzi" data-path="src/pages/calculators/BodyFatCalculator.tsx">Learn More About Body Fat</h3>
            <p className="mb-3" data-id="cql5ojmt0" data-path="src/pages/calculators/BodyFatCalculator.tsx">
              For in-depth information about body fat, measurement methods, and strategies for healthy body composition, check out our comprehensive guide:
            </p>
            <Link
            to="/blog/body-fat-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete Body Fat Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="sphu6dm1k" data-path="src/pages/calculators/BodyFatCalculator.tsx">
            Remember that body fat calculators provide estimates that may have a margin of error of ±3-4%. For the most accurate assessment, consider methods like DEXA scans, BodPod, or hydrostatic weighing performed by qualified professionals.
          </p>
        </div>
    </CalculatorLayout>);

};

export default BodyFatCalculator;