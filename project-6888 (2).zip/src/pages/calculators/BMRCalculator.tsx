import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";
import MetaTags from "@/components/SEO/MetaTags";

const BMRCalculator = () => {
  const [unit, setUnit] = useState("metric");
  const [gender, setGender] = useState("male");
  const [age, setAge] = useState("");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [formula, setFormula] = useState("mifflin");
  const [bmr, setBmr] = useState<number | null>(null);
  const [error, setError] = useState("");

  const calculateBMR = () => {
    setError("");

    try {
      const ageValue = parseFloat(age);

      if (isNaN(ageValue) || ageValue <= 0) {
        throw new Error("Please enter a valid age");
      }

      let heightInCm: number;
      let weightInKg: number;

      if (unit === "metric") {
        heightInCm = parseFloat(height);
        weightInKg = parseFloat(weight);

        if (isNaN(heightInCm) || isNaN(weightInKg) || heightInCm <= 0 || weightInKg <= 0) {
          throw new Error("Please enter valid height and weight values");
        }
      } else {
        const heightInInches = parseFloat(feet) * 12 + parseFloat(inches);
        const weightInLbs = parseFloat(weight);

        if (isNaN(heightInInches) || isNaN(weightInLbs) || heightInInches <= 0 || weightInLbs <= 0) {
          throw new Error("Please enter valid height and weight values");
        }

        heightInCm = heightInInches * 2.54;
        weightInKg = weightInLbs * 0.453592;
      }

      let calculatedBMR = 0;

      // Calculate BMR based on selected formula
      if (formula === "mifflin") {
        // Mifflin-St Jeor Equation
        if (gender === "male") {
          calculatedBMR = 10 * weightInKg + 6.25 * heightInCm - 5 * ageValue + 5;
        } else {
          calculatedBMR = 10 * weightInKg + 6.25 * heightInCm - 5 * ageValue - 161;
        }
      } else if (formula === "harris") {
        // Harris-Benedict Equation
        if (gender === "male") {
          calculatedBMR = 88.362 + 13.397 * weightInKg + 4.799 * heightInCm - 5.677 * ageValue;
        } else {
          calculatedBMR = 447.593 + 9.247 * weightInKg + 3.098 * heightInCm - 4.330 * ageValue;
        }
      } else if (formula === "katch") {
        // Katch-McArdle Formula (requires body fat percentage, simplified version here)
        calculatedBMR = 370 + 21.6 * (weightInKg * 0.73); // Assuming lean body mass is 73% of total weight as an approximation
      }

      setBmr(calculatedBMR);
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setBmr(null);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setHeight("");
    setWeight("");
    setFeet("");
    setInches("");
    setBmr(null);
    setError("");
  };

  return (
    <>
      <MetaTags
        title="BMR Calculator | Calculate Your Basal Metabolic Rate"
        description="Calculate your Basal Metabolic Rate (BMR) to understand how many calories your body needs at rest. Our medically-reviewed calculator provides accurate results."
        keywords="BMR calculator, basal metabolic rate, calorie calculator, resting metabolic rate, metabolism calculator, calorie needs, Harris-Benedict equation, Mifflin-St Jeor"
        canonicalUrl="https://fitnesscalculatorhub.com/calculators/bmr"
        structuredData={{
          '@context': 'https://schema.org',
          '@type': 'HealthAndBeautyBusiness',
          'name': 'BMR Calculator | Fitness Calculator Hub',
          'description': 'Calculate your Basal Metabolic Rate (BMR) to understand how many calories your body needs at rest.',
          'url': 'https://fitcalchub.com/calculators/bmr',
          'medicalSpecialty': 'Nutrition'
        }} />
    <CalculatorLayout
        title="BMR Calculator"
        description="Calculate your Basal Metabolic Rate (BMR) to know how many calories your body needs at rest."
        icon={
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="joxreh0ps" data-path="src/pages/calculators/BMRCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" data-id="qin7strfo" data-path="src/pages/calculators/BMRCalculator.tsx" />
        </svg>
        }>

      <div className="space-y-6" data-id="qk50xc3fp" data-path="src/pages/calculators/BMRCalculator.tsx">
        <div data-id="veqfeeyky" data-path="src/pages/calculators/BMRCalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
              value={unit}
              onValueChange={setUnit}
              className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="a0ov9dt2e" data-path="src/pages/calculators/BMRCalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (cm, kg)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="z24r64l2x" data-path="src/pages/calculators/BMRCalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (ft, in, lbs)</Label>
            </div>
          </RadioGroup>
        </div>

        <div data-id="8albyqcum" data-path="src/pages/calculators/BMRCalculator.tsx">
          <Label className="text-lg font-medium">Gender</Label>
          <RadioGroup
              value={gender}
              onValueChange={setGender}
              className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="she1ndabk" data-path="src/pages/calculators/BMRCalculator.tsx">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">Male</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="aylnjqkf7" data-path="src/pages/calculators/BMRCalculator.tsx">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">Female</Label>
            </div>
          </RadioGroup>
        </div>

        <div data-id="qbccel3lo" data-path="src/pages/calculators/BMRCalculator.tsx">
          <Label className="text-lg font-medium">Formula</Label>
          <Select value={formula} onValueChange={setFormula}>
            <SelectTrigger className="mt-2">
              <SelectValue placeholder="Select formula" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mifflin">Mifflin-St Jeor (Recommended)</SelectItem>
              <SelectItem value="harris">Harris-Benedict</SelectItem>
              <SelectItem value="katch">Katch-McArdle</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Separator />

        <div className="space-y-4" data-id="dprwolthq" data-path="src/pages/calculators/BMRCalculator.tsx">
          <div className="space-y-2" data-id="nbo8vgyde" data-path="src/pages/calculators/BMRCalculator.tsx">
            <Label htmlFor="age">Age (years)</Label>
            <Input
                id="age"
                type="number"
                placeholder="e.g., 30"
                value={age}
                onChange={(e) => setAge(e.target.value)} />

          </div>

          {unit === "metric" ?
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="zkffhe75i" data-path="src/pages/calculators/BMRCalculator.tsx">
                <div className="space-y-2" data-id="mbdra5yu0" data-path="src/pages/calculators/BMRCalculator.tsx">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="e.g., 170"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="elov0rhmv" data-path="src/pages/calculators/BMRCalculator.tsx">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 70"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </> :

            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="8h5flnwqc" data-path="src/pages/calculators/BMRCalculator.tsx">
                <div className="space-y-2" data-id="z66dxm24h" data-path="src/pages/calculators/BMRCalculator.tsx">
                  <Label htmlFor="feet">Height (ft)</Label>
                  <Input
                    id="feet"
                    type="number"
                    placeholder="e.g., 5"
                    value={feet}
                    onChange={(e) => setFeet(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="4pqc2yzu6" data-path="src/pages/calculators/BMRCalculator.tsx">
                  <Label htmlFor="inches">Height (in)</Label>
                  <Input
                    id="inches"
                    type="number"
                    placeholder="e.g., 10"
                    value={inches}
                    onChange={(e) => setInches(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="rosm2fxzl" data-path="src/pages/calculators/BMRCalculator.tsx">
                  <Label htmlFor="weight">Weight (lbs)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 160"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </>
            }
        </div>

        <div className="flex gap-3" data-id="ykoqt32lt" data-path="src/pages/calculators/BMRCalculator.tsx">
          <Button
              onClick={calculateBMR}
              className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">

            Calculate BMR
          </Button>
          <Button
              variant="outline"
              onClick={resetCalculator}>

            Reset
          </Button>
        </div>

        {error &&
          <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="1zske3wme" data-path="src/pages/calculators/BMRCalculator.tsx">
            {error}
          </div>
          }

        {bmr !== null && !error &&
          <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="text-center space-y-4" data-id="fk1r5lwpf" data-path="src/pages/calculators/BMRCalculator.tsx">
                <div data-id="33zwloolf" data-path="src/pages/calculators/BMRCalculator.tsx">
                  <p className="text-lg font-medium" data-id="8r4ivso7f" data-path="src/pages/calculators/BMRCalculator.tsx">Your Basal Metabolic Rate (BMR) is</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="gis02r9in" data-path="src/pages/calculators/BMRCalculator.tsx">
                    {Math.round(bmr)} calories/day
                  </p>
                  <p className="text-lg mt-4" data-id="nohj2y2cc" data-path="src/pages/calculators/BMRCalculator.tsx">
                    This is the number of calories your body needs while resting for 24 hours.
                  </p>
                </div>
                
                <div className="mt-4 border-t pt-4" data-id="qqucoxm76" data-path="src/pages/calculators/BMRCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="af2epukm7" data-path="src/pages/calculators/BMRCalculator.tsx">Medical Advice</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="gth9jsbvb" data-path="src/pages/calculators/BMRCalculator.tsx">
                    <p className="mb-2" data-id="izvcz9lii" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="6a4r45tvi" data-path="src/pages/calculators/BMRCalculator.tsx">Saran Medis:</strong> BMR Anda adalah {Math.round(bmr)} kalori per hari. Berikut adalah beberapa saran berdasarkan hasil ini:</p>
                    <ul className="list-disc pl-6 space-y-1" data-id="ik5colmcy" data-path="src/pages/calculators/BMRCalculator.tsx">
                      <li data-id="yc55z6vn6" data-path="src/pages/calculators/BMRCalculator.tsx">BMR hanya menunjukkan kebutuhan kalori dasar tubuh. Untuk total kebutuhan kalori harian, pertimbangkan juga tingkat aktivitas Anda (gunakan kalkulator TDEE).</li>
                      <li data-id="utwfpir1r" data-path="src/pages/calculators/BMRCalculator.tsx">Jangan mengonsumsi kalori di bawah BMR Anda dalam jangka panjang tanpa pengawasan medis, karena ini bisa memperlambat metabolisme dan menyebabkan kekurangan nutrisi.</li>
                      <li data-id="puwf1jyfk" data-path="src/pages/calculators/BMRCalculator.tsx">{Math.round(bmr) < 1200 ? "BMR Anda tergolong rendah. Ini mungkin karena faktor usia, berat badan, atau tinggi badan. Konsultasikan dengan ahli gizi untuk memastikan Anda mendapatkan nutrisi yang cukup." : Math.round(bmr) > 2000 ? "BMR Anda relatif tinggi. Ini bisa menguntungkan untuk membakar kalori, tetapi pastikan Anda mengonsumsi makanan yang cukup untuk mendukung kebutuhan metabolisme Anda." : "BMR Anda berada dalam rentang umum. Pastikan asupan nutrisi Anda seimbang dan cukup untuk memenuhi kebutuhan kalori dasar ini."}</li>
                      <li data-id="hbn60kxf7" data-path="src/pages/calculators/BMRCalculator.tsx">Pertimbangkan untuk membuat jurnal makanan untuk melacak asupan kalori dan memastikan Anda mendapatkan nutrisi yang cukup.</li>
                      <li data-id="b82lqv9rk" data-path="src/pages/calculators/BMRCalculator.tsx">Latihan kekuatan dapat membantu meningkatkan massa otot, yang pada gilirannya meningkatkan BMR Anda.</li>
                    </ul>
                    <p className="mt-3 text-sm italic" data-id="ilh4xhnnt" data-path="src/pages/calculators/BMRCalculator.tsx">Disclaimer: Informasi ini bersifat umum dan tidak menggantikan nasihat medis profesional. Selalu konsultasikan dengan dokter atau ahli gizi sebelum memulai program diet atau olahraga baru.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          }

        <div className="mt-8 border-t pt-6" data-id="ujiqm57ba" data-path="src/pages/calculators/BMRCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="scb1izgnh" data-path="src/pages/calculators/BMRCalculator.tsx">Understanding Basal Metabolic Rate (BMR)</h2>
          
          <p className="mb-4" data-id="5g9oc157k" data-path="src/pages/calculators/BMRCalculator.tsx">
            Basal Metabolic Rate (BMR) represents the minimum amount of energy your body needs to perform essential functions while at complete rest. These functions include breathing, circulating blood, cell production, maintaining body temperature, and more.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="gxfmjmkaz" data-path="src/pages/calculators/BMRCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="5svy138j1" data-path="src/pages/calculators/BMRCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="sa9nr0map" data-path="src/pages/calculators/BMRCalculator.tsx">Why BMR Matters</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="zas9d3neb" data-path="src/pages/calculators/BMRCalculator.tsx">
                <li data-id="fxkanaoar" data-path="src/pages/calculators/BMRCalculator.tsx">Establishes your baseline calorie needs</li>
                <li data-id="7ykz8umov" data-path="src/pages/calculators/BMRCalculator.tsx">Forms the foundation for weight management</li>
                <li data-id="gexofo18p" data-path="src/pages/calculators/BMRCalculator.tsx">Helps identify potential metabolic issues</li>
                <li data-id="q5ilmtcny" data-path="src/pages/calculators/BMRCalculator.tsx">Allows for personalized nutrition planning</li>
                <li data-id="7s7uebmb3" data-path="src/pages/calculators/BMRCalculator.tsx">Accounts for 60-70% of your daily calorie expenditure</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="4e3j7kkj4" data-path="src/pages/calculators/BMRCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="42gz54xrb" data-path="src/pages/calculators/BMRCalculator.tsx">Factors Affecting Your BMR</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="wlewsh7iu" data-path="src/pages/calculators/BMRCalculator.tsx">
                <li data-id="2g1h9wnzp" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="47vn6r629" data-path="src/pages/calculators/BMRCalculator.tsx">Age:</strong> BMR decreases by 1-2% per decade after age 20</li>
                <li data-id="9b4jx9x1l" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="5zbgmo5ye" data-path="src/pages/calculators/BMRCalculator.tsx">Gender:</strong> Men typically have higher BMRs than women</li>
                <li data-id="2hvta3hng" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="3nuq5rdqc" data-path="src/pages/calculators/BMRCalculator.tsx">Body composition:</strong> More muscle means higher BMR</li>
                <li data-id="n5q07nocf" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="wo3w0nwvm" data-path="src/pages/calculators/BMRCalculator.tsx">Genetics:</strong> Inherited metabolic differences</li>
                <li data-id="7nqzrm49c" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="wqneb4hin" data-path="src/pages/calculators/BMRCalculator.tsx">Hormonal factors:</strong> Thyroid issues can impact BMR</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="pufaahzfr" data-path="src/pages/calculators/BMRCalculator.tsx">BMR Calculation Methods</h3>
          <p className="mb-4" data-id="ftjwom3jq" data-path="src/pages/calculators/BMRCalculator.tsx">Our calculator offers three proven formulas for calculating BMR:</p>
          
          <div className="space-y-4 mb-6" data-id="a4rlaull6" data-path="src/pages/calculators/BMRCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="nfrrorsz0" data-path="src/pages/calculators/BMRCalculator.tsx">
              <h4 className="font-medium" data-id="k33cuaanh" data-path="src/pages/calculators/BMRCalculator.tsx">Mifflin-St Jeor Equation (Recommended)</h4>
              <p className="text-sm text-gray-600 italic mb-2" data-id="1svmv3g54" data-path="src/pages/calculators/BMRCalculator.tsx">Most accurate for the general population</p>
              <p className="font-mono text-sm" data-id="uct7ns5up" data-path="src/pages/calculators/BMRCalculator.tsx">Men: BMR = (10 × weight in kg) + (6.25 × height in cm) - (5 × age in years) + 5</p>
              <p className="font-mono text-sm" data-id="wlaxaqv3w" data-path="src/pages/calculators/BMRCalculator.tsx">Women: BMR = (10 × weight in kg) + (6.25 × height in cm) - (5 × age in years) - 161</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="8vpcbylcm" data-path="src/pages/calculators/BMRCalculator.tsx">
              <h4 className="font-medium" data-id="9nlt0zcjz" data-path="src/pages/calculators/BMRCalculator.tsx">Harris-Benedict Equation</h4>
              <p className="text-sm text-gray-600 italic mb-2" data-id="xuurxyygk" data-path="src/pages/calculators/BMRCalculator.tsx">Classic formula, widely used in clinical settings</p>
              <p className="font-mono text-sm" data-id="rdhklwxvb" data-path="src/pages/calculators/BMRCalculator.tsx">Men: BMR = 88.362 + (13.397 × weight in kg) + (4.799 × height in cm) - (5.677 × age in years)</p>
              <p className="font-mono text-sm" data-id="6cjjhploq" data-path="src/pages/calculators/BMRCalculator.tsx">Women: BMR = 447.593 + (9.247 × weight in kg) + (3.098 × height in cm) - (4.330 × age in years)</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="e5kzzbiyx" data-path="src/pages/calculators/BMRCalculator.tsx">
              <h4 className="font-medium" data-id="v0wu4zpeq" data-path="src/pages/calculators/BMRCalculator.tsx">Katch-McArdle Formula</h4>
              <p className="text-sm text-gray-600 italic mb-2" data-id="p3ir3yv0s" data-path="src/pages/calculators/BMRCalculator.tsx">Considers lean body mass, better for athletic individuals</p>
              <p className="font-mono text-sm" data-id="lihe2qqr1" data-path="src/pages/calculators/BMRCalculator.tsx">BMR = 370 + (21.6 × lean body mass in kg)</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="vjrpy1puf" data-path="src/pages/calculators/BMRCalculator.tsx">Using Your BMR Results</h3>
          <p className="mb-4" data-id="8l3whj3kn" data-path="src/pages/calculators/BMRCalculator.tsx">
            Your BMR provides valuable insight into your body's basic energy needs. Here's how to use this information:
          </p>
          
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="w3bclo624" data-path="src/pages/calculators/BMRCalculator.tsx">
            <li data-id="4fd83u9u0" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="w77ggy4ys" data-path="src/pages/calculators/BMRCalculator.tsx">For weight maintenance:</strong> Combine BMR with activity level to determine total daily energy expenditure (TDEE)</li>
            <li data-id="me9t8acln" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="34wubzkvn" data-path="src/pages/calculators/BMRCalculator.tsx">For weight loss:</strong> Create a moderate caloric deficit, but avoid consuming less than your BMR long-term</li>
            <li data-id="qrn8txnlt" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="t2599f0vf" data-path="src/pages/calculators/BMRCalculator.tsx">For muscle building:</strong> Consume more than your BMR + activity level to support muscle growth</li>
            <li data-id="3x6i922qg" data-path="src/pages/calculators/BMRCalculator.tsx"><strong data-id="0bm5cguec" data-path="src/pages/calculators/BMRCalculator.tsx">For metabolic health:</strong> Track BMR changes over time to assess metabolic efficiency</li>
          </ul>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="fzakejsha" data-path="src/pages/calculators/BMRCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="xndaexwat" data-path="src/pages/calculators/BMRCalculator.tsx">Learn More About BMR</h3>
            <p className="mb-3" data-id="2ox4dqil4" data-path="src/pages/calculators/BMRCalculator.tsx">
              For an in-depth understanding of how BMR affects your metabolism and health, check out our comprehensive guide:
            </p>
            <Link
                to="/blog/bmr-guide"
                className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete BMR Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="dhtgv1y2q" data-path="src/pages/calculators/BMRCalculator.tsx">
            Remember that while BMR calculators provide useful estimates, individual variations exist. For the most accurate assessment of your metabolic rate, consult with healthcare professionals who can perform specialized testing.
          </p>
        </div>
        
        <div className="bg-blue-50 p-4 rounded-md mt-6" data-id="ab24e3q8q" data-path="src/pages/calculators/BMRCalculator.tsx">
          <h4 className="font-semibold mb-2" data-id="gea5b3qzl" data-path="src/pages/calculators/BMRCalculator.tsx">Related Calculators:</h4>
          <p className="mb-3" data-id="8x1ivmz0x" data-path="src/pages/calculators/BMRCalculator.tsx">For a more comprehensive understanding of your health and fitness needs:</p>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-2" data-id="96fom5rej" data-path="src/pages/calculators/BMRCalculator.tsx">
            <li data-id="i4bvj0odx" data-path="src/pages/calculators/BMRCalculator.tsx"><Link to="/calculators/bmi" className="text-blue-600 hover:underline">BMI Calculator</Link> - Check if your weight is healthy</li>
            <li data-id="g0uq52plw" data-path="src/pages/calculators/BMRCalculator.tsx"><Link to="/calculators/tdee" className="text-blue-600 hover:underline">TDEE Calculator</Link> - Find your total daily energy needs</li>
            <li data-id="az1uendt3" data-path="src/pages/calculators/BMRCalculator.tsx"><Link to="/calculators/macro" className="text-blue-600 hover:underline">Macro Calculator</Link> - Calculate optimal macronutrient ratios</li>
            <li data-id="v9r0bfbr7" data-path="src/pages/calculators/BMRCalculator.tsx"><Link to="/calculators/protein-intake" className="text-blue-600 hover:underline">Protein Calculator</Link> - Determine your protein requirements</li>
            <li data-id="e3ru7tq7r" data-path="src/pages/calculators/BMRCalculator.tsx"><Link to="/blog/bmr-guide" className="text-blue-600 hover:underline">Complete BMR Guide</Link> - Learn more about BMR</li>
          </ul>
          <div className="mt-3 p-2 border-l-4 border-blue-500 bg-blue-100" data-id="kf56tbygk" data-path="src/pages/calculators/BMRCalculator.tsx">
            <p className="text-sm italic" data-id="o2760rx4o" data-path="src/pages/calculators/BMRCalculator.tsx">Our calculators are medically reviewed and utilize scientifically recognized formulas for accurate results.</p>
          </div>
        </div>
      </div>
    </CalculatorLayout>
    </>);


};

export default BMRCalculator;