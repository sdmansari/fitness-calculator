import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

const CalciumNeedsCalculator = () => {
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [pregnancy, setPregnancy] = useState("no");
  const [lactation, setLactation] = useState("no");
  const [calciumNeeds, setCalciumNeeds] = useState<number | null>(null);
  const [error, setError] = useState("");

  const calculateCalciumNeeds = () => {
    setError("");

    try {
      const ageValue = parseInt(age);

      if (isNaN(ageValue) || ageValue <= 0) {
        throw new Error("Please enter a valid age");
      }

      let dailyCalciumNeed = 0;

      // Calculate calcium needs based on age, gender, pregnancy and lactation
      if (ageValue <= 6) {
        dailyCalciumNeed = 200; // 0-6 months
      } else if (ageValue <= 12) {
        dailyCalciumNeed = 260; // 7-12 months
      } else if (ageValue <= 3) {
        dailyCalciumNeed = 700; // 1-3 years
      } else if (ageValue <= 8) {
        dailyCalciumNeed = 1000; // 4-8 years
      } else if (ageValue <= 18) {
        dailyCalciumNeed = 1300; // 9-18 years
      } else if (ageValue <= 50) {
        dailyCalciumNeed = 1000; // 19-50 years
      } else if (ageValue <= 70) {
        // Gender differentiation for 51-70 years
        dailyCalciumNeed = gender === "male" ? 1000 : 1200;
      } else {
        dailyCalciumNeed = 1200; // 71+ years
      }

      // Adjust for pregnancy or lactation (only applies to females of childbearing age)
      if (gender === "female" && ageValue >= 14 && ageValue <= 50) {
        if (pregnancy === "yes") {
          // Pregnant women 14-18 years: 1300 mg, 19-50 years: 1000 mg
          dailyCalciumNeed = ageValue <= 18 ? 1300 : 1000;
        } else if (lactation === "yes") {
          // Lactating women 14-18 years: 1300 mg, 19-50 years: 1000 mg
          dailyCalciumNeed = ageValue <= 18 ? 1300 : 1000;
        }
      }

      setCalciumNeeds(dailyCalciumNeed);
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setCalciumNeeds(null);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setCalciumNeeds(null);
    setError("");
  };

  return (
    <CalculatorLayout
      title="Calcium Needs Calculator"
      description="Calculate your recommended daily calcium intake based on age, gender, and special conditions."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="0r7hhk3ig" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" data-id="9rso28s5w" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="80il867oc" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="61bp4zb74" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
          <div className="space-y-2" data-id="18o1ww0xo" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <Label htmlFor="age">Age (years)</Label>
            <Input
              id="age"
              type="number"
              placeholder="e.g., 35"
              value={age}
              onChange={(e) => setAge(e.target.value)} />

          </div>
          
          <div className="space-y-2" data-id="jqpytfsi4" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <Label className="text-base font-medium">Gender</Label>
            <RadioGroup
              value={gender}
              onValueChange={setGender}
              className="flex gap-6">
              <div className="flex items-center space-x-2" data-id="gqrp2pqbu" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <RadioGroupItem value="male" id="male" />
                <Label htmlFor="male">Male</Label>
              </div>
              <div className="flex items-center space-x-2" data-id="x4fo89xt4" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <RadioGroupItem value="female" id="female" />
                <Label htmlFor="female">Female</Label>
              </div>
            </RadioGroup>
          </div>
        </div>

        {gender === "female" &&
        <>
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="t0watjr12" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <div className="space-y-2" data-id="6q6blhmff" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <Label className="text-base font-medium">Pregnant?</Label>
                <RadioGroup
                value={pregnancy}
                onValueChange={setPregnancy}
                className="flex gap-6">
                  <div className="flex items-center space-x-2" data-id="lpgmqzqaz" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                    <RadioGroupItem value="no" id="pregnancy-no" />
                    <Label htmlFor="pregnancy-no">No</Label>
                  </div>
                  <div className="flex items-center space-x-2" data-id="pi8k7qnpu" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                    <RadioGroupItem value="yes" id="pregnancy-yes" />
                    <Label htmlFor="pregnancy-yes">Yes</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-2" data-id="ig4pb9plw" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <Label className="text-base font-medium">Lactating?</Label>
                <RadioGroup
                value={lactation}
                onValueChange={setLactation}
                className="flex gap-6">
                  <div className="flex items-center space-x-2" data-id="rba4vqgve" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                    <RadioGroupItem value="no" id="lactation-no" />
                    <Label htmlFor="lactation-no">No</Label>
                  </div>
                  <div className="flex items-center space-x-2" data-id="bd1qbx6lq" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                    <RadioGroupItem value="yes" id="lactation-yes" />
                    <Label htmlFor="lactation-yes">Yes</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </>
        }

        <div className="flex gap-3" data-id="s6sp88cak" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
          <Button
            onClick={calculateCalciumNeeds}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
            Calculate Calcium Needs
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>
            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="aoefus9lr" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            {error}
          </div>
        }

        {calciumNeeds !== null && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="text-center space-y-4" data-id="fw3z9cmu9" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <div data-id="g512yq0om" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <p className="text-lg font-medium" data-id="ssiv2twb9" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Your Recommended Daily Calcium Intake</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="mhh49cfz1" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                    {calciumNeeds} mg
                  </p>
                </div>
                
                <div className="mt-4 border-t pt-4" data-id="jdyzeyz5v" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="wrzm0txtd" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Food Sources of Calcium</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="nqqd557ds" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                    <p className="mb-3" data-id="mvbdfwpz8" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Here are some calcium-rich foods to help you meet your daily needs:</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="uf3e3eg8v" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                      <div data-id="hdax83gry" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                        <h4 className="font-semibold mb-2" data-id="oex55k4to" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Dairy Sources:</h4>
                        <ul className="list-disc pl-5 space-y-1" data-id="14sblc19l" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                          <li data-id="wucb4eeda" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Milk (300mg per cup)</li>
                          <li data-id="lqwkhncsn" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Yogurt (400mg per cup)</li>
                          <li data-id="y3p79jv5y" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Cheese (200-300mg per ounce)</li>
                          <li data-id="9nv7x76yh" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Cottage cheese (130mg per cup)</li>
                        </ul>
                      </div>
                      <div data-id="pmqjlauyl" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                        <h4 className="font-semibold mb-2" data-id="fr9rwdf1h" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Non-Dairy Sources:</h4>
                        <ul className="list-disc pl-5 space-y-1" data-id="ybza3u0d4" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                          <li data-id="q6za89jem" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Tofu (200-400mg per 1/2 cup)</li>
                          <li data-id="sj27sdzhi" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Fortified plant milks (300mg per cup)</li>
                          <li data-id="bzsrswh1d" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Kale (100mg per cup)</li>
                          <li data-id="tbm9aen3t" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Bok choy (160mg per cup)</li>
                          <li data-id="jj0y1mme4" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Almonds (75mg per ounce)</li>
                          <li data-id="f05peik9s" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Canned salmon with bones (180mg per 3 oz)</li>
                        </ul>
                      </div>
                    </div>
                    <p className="mt-3 text-sm italic" data-id="qfpufacdk" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Disclaimer: This calculation provides a general recommendation based on established guidelines. Individual needs may vary based on health conditions and medications. Consult with a healthcare provider for personalized advice.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="qau0p3b5v" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="hgfl3g6rq" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">About Calcium Requirements</h3>
          <p className="mb-4" data-id="n3uh0emt7" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            Calcium is essential for building and maintaining strong bones and teeth. It also plays vital roles in muscle function, nerve transmission, and hormonal secretion. The body cannot produce calcium, so it must be obtained through diet or supplements.
          </p>
          
          <h3 className="text-lg font-semibold mb-2" data-id="cex8s3zb0" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Recommended Daily Allowance (RDA) for Calcium:</h3>
          <div className="overflow-x-auto" data-id="w72t2rcex" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <table className="min-w-full border-collapse border border-gray-300" data-id="4hyph3qke" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <thead data-id="7w2t73up8" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <tr className="bg-gray-100" data-id="btd4np1qj" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <th className="border border-gray-300 px-4 py-2" data-id="cwz5b96va" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Age Group</th>
                  <th className="border border-gray-300 px-4 py-2" data-id="toc3e0u3k" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">RDA (mg/day)</th>
                </tr>
              </thead>
              <tbody data-id="35v0k3x8t" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <tr data-id="qhcd82a0n" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="glps9r2gc" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">0-6 months</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="rl00iaiih" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">200*</td>
                </tr>
                <tr data-id="qw3ybnnvd" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="m7v2rh3gs" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">7-12 months</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="8zelycppn" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">260*</td>
                </tr>
                <tr data-id="3m1hmqu00" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="qez9ea9u0" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1-3 years</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="siqihp8nz" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">700</td>
                </tr>
                <tr data-id="afwdb48u4" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="47sjswzo8" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">4-8 years</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="10ulbsn4h" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1,000</td>
                </tr>
                <tr data-id="qsikdza0w" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="jx0f47xv6" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">9-18 years</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="9aa7pxp0y" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1,300</td>
                </tr>
                <tr data-id="95ljw88a2" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="6obkbhir0" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">19-50 years</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="7irjgf3of" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1,000</td>
                </tr>
                <tr data-id="w5diyuefr" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="winxu7lm6" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">51-70 years (males)</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="pzq2z3dqq" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1,000</td>
                </tr>
                <tr data-id="6tk283pgs" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="dkhotmq5a" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">51-70 years (females)</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="ffp8qcpcd" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1,200</td>
                </tr>
                <tr data-id="mpsuqkphs" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                  <td className="border border-gray-300 px-4 py-2" data-id="gncmflkae" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">71+ years</td>
                  <td className="border border-gray-300 px-4 py-2" data-id="t9u2fd9un" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1,200</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="text-sm italic mt-2" data-id="yynjvuljw" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">*Adequate Intake (AI) rather than RDA</p>
          
          <p className="mt-4 mb-4" data-id="43s6uz8kc" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            It's important to note that calcium absorption is enhanced by vitamin D, so ensuring adequate vitamin D intake is also essential for bone health. Calcium intake above 2,500 mg/day may increase risk of kidney stones and cardiovascular events in some individuals.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="9xk96q68l" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="czj87pbdj" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Understanding Calcium Requirements</h2>
          
          <p className="mb-4" data-id="7ju9slnt5" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            Calcium is the most abundant mineral in the human body, with about 99% stored in bones and teeth. Beyond its structural role, calcium is crucial for muscle contraction, nerve signal transmission, blood clotting, enzyme activation, and cell division.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="orzomac9r" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="f3em3jmyj" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="c6mu2p68l" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Why Calcium Matters</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="f6ear20gi" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <li data-id="3f7oj7e2w" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Builds and maintains strong bones and teeth</li>
                <li data-id="rd6stesyd" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Supports proper muscle function (including heart)</li>
                <li data-id="9nytyhe7q" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Enables nerve transmission and signaling</li>
                <li data-id="khz6qomg1" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Regulates blood vessel dilation and constriction</li>
                <li data-id="iyn9wqahn" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Assists in hormone secretion</li>
                <li data-id="ced4xcaia" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Helps prevent osteoporosis and fractures</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="6njgqcxpk" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="zh2dfk8kr" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Signs of Inadequate Intake</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="1pncacpgs" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <li data-id="fbrcufpgf" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Numbness and tingling in extremities</li>
                <li data-id="a9o6zqpml" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Muscle cramps and spasms</li>
                <li data-id="c5ygv54nb" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Abnormal heart rhythms</li>
                <li data-id="aq9zwcif3" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Weak and brittle nails</li>
                <li data-id="f1mxtb46w" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Tooth decay and periodontal disease</li>
                <li data-id="aaj3pa4pp" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Low bone mineral density (osteopenia/osteoporosis)</li>
                <li data-id="xriiimcv0" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Increased fracture risk</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="on34hwdqe" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Calcium Requirements by Life Stage</h3>
          <div className="space-y-4 mb-6" data-id="ecy7ooqss" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="gni5gmh3e" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <h4 className="font-medium" data-id="icdl088y7" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Children and Adolescents</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2" data-id="oeo4nasch" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <p className="font-mono text-sm" data-id="vesqwpb8h" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">1-3 years: 700 mg/day</p>
                <p className="font-mono text-sm" data-id="574he4t8g" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">4-8 years: 1,000 mg/day</p>
                <p className="font-mono text-sm" data-id="vdzurxfqe" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">9-18 years: 1,300 mg/day</p>
              </div>
              <p className="text-sm text-gray-600 mt-2" data-id="c16zqy36b" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">These are peak bone-building years when 40-60% of adult bone mass is accumulated.</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="7k3e2rxss" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <h4 className="font-medium" data-id="hsrjncn3s" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Adults</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2" data-id="lc7sw9x7h" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <p className="font-mono text-sm" data-id="kcl2xp9tb" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">19-50 years: 1,000 mg/day</p>
                <p className="font-mono text-sm" data-id="9smrpdp4j" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Men 51-70 years: 1,000 mg/day</p>
                <p className="font-mono text-sm" data-id="km8e766ua" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Women 51-70 years: 1,200 mg/day</p>
                <p className="font-mono text-sm" data-id="ptvep2kgz" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">All adults 71+ years: 1,200 mg/day</p>
              </div>
              <p className="text-sm text-gray-600 mt-2" data-id="k1fzaer7e" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">After age 30, bone mass gradually declines. Women experience accelerated bone loss during menopause.</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="smgyghzfi" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <h4 className="font-medium" data-id="57w8xe84z" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Special Populations</h4>
              <div className="grid grid-cols-1 gap-2 mt-2" data-id="nqqdubkj1" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <p className="font-mono text-sm" data-id="g8so0fl1i" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Pregnant and breastfeeding women: Same as age-matched non-pregnant women</p>
                <p className="font-mono text-sm" data-id="1k7p4r7d9" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Athletes with amenorrhea: May need additional calcium</p>
                <p className="font-mono text-sm" data-id="x0bopzqpz" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">People with malabsorption disorders: May need higher intakes</p>
              </div>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="hpgr4fuiw" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Top Calcium Food Sources</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6" data-id="kyhgnjp3n" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <div data-id="kx7mhkjt7" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <h4 className="font-medium mb-2" data-id="cjqb6dt92" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Dairy Sources (per serving)</h4>
              <ul className="list-disc pl-6 space-y-1" data-id="l3vbe87j0" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <li data-id="dscyofvuq" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Milk (1 cup): 300-350 mg</li>
                <li data-id="sgs7lr0mt" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Yogurt (1 cup): 300-450 mg</li>
                <li data-id="wilmk8sru" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Cheese (1.5 oz hard cheese): 300-350 mg</li>
                <li data-id="9t0b4n7zs" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Cottage cheese (1 cup): 120-150 mg</li>
              </ul>
            </div>
            <div data-id="y0jp4x52c" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              <h4 className="font-medium mb-2" data-id="reo2c0yxs" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Plant-Based Sources (per serving)</h4>
              <ul className="list-disc pl-6 space-y-1" data-id="7z8o2s1no" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
                <li data-id="r99x0653g" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Calcium-fortified plant milks (1 cup): 300-450 mg</li>
                <li data-id="6zpjorno4" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Calcium-set tofu (1/2 cup): 200-400 mg</li>
                <li data-id="4pjme48c4" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Kale, cooked (1 cup): 180 mg</li>
                <li data-id="0wzlfrndk" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Bok choy, cooked (1 cup): 160 mg</li>
                <li data-id="msvplxvb3" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">White beans (1 cup): 160 mg</li>
                <li data-id="t5waqybpc" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Almonds (1/4 cup): 100 mg</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="ksuk7noeg" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Calcium and Vitamin D: Essential Partners</h3>
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="c4ulyqgrz" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <li data-id="pxoywkjdn" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Vitamin D increases calcium absorption from 30-40% to 30-80%</li>
            <li data-id="sqcj5v5xg" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Without adequate vitamin D, only 10-15% of dietary calcium may be absorbed</li>
            <li data-id="gk2jhsuxb" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Vitamin D helps maintain appropriate calcium levels in the blood</li>
            <li data-id="gfhb57grt" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Vitamin D promotes proper mineral deposition in bone</li>
            <li data-id="e3djiwtje" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Sources include sunlight, fatty fish, fortified foods, and supplements</li>
          </ul>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="6l327ahng" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="uw4lxxmvw" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">Learn More About Calcium</h3>
            <p className="mb-3" data-id="xdjqr87to" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
              For an in-depth understanding of calcium's role in health, age-specific requirements, factors affecting absorption, and strategies for optimizing intake, check out our comprehensive guide:
            </p>
            <Link
            to="/blog/calcium-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete Calcium Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="jiu8b2y2n" data-path="src/pages/calculators/CalciumNeedsCalculator.tsx">
            Remember that these recommendations provide general guidelines. Individual needs may vary based on health status, medication use, and other factors. Consult with a healthcare professional before starting calcium supplements, especially if you have kidney disease, heart disease, or are taking certain medications.
          </p>
        </div>
    </CalculatorLayout>);

};

export default CalciumNeedsCalculator;