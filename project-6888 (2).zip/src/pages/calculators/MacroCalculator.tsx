import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

const MacroCalculator = () => {
  const [unit, setUnit] = useState("metric");
  const [gender, setGender] = useState("male");
  const [age, setAge] = useState("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [lbs, setLbs] = useState("");
  const [activityLevel, setActivityLevel] = useState("moderate");
  const [goal, setGoal] = useState("maintain");
  const [macroResults, setMacroResults] = useState<{
    calories: number;
    protein: {grams: number;calories: number;percentage: number;};
    carbs: {grams: number;calories: number;percentage: number;};
    fat: {grams: number;calories: number;percentage: number;};
  } | null>(null);
  const [error, setError] = useState("");

  const calculateBMR = (weight: number, height: number, ageValue: number, genderValue: string) => {
    // Mifflin-St Jeor Equation
    if (genderValue === "male") {
      return 10 * weight + 6.25 * height - 5 * ageValue + 5;
    } else {
      return 10 * weight + 6.25 * height - 5 * ageValue - 161;
    }
  };

  const calculateTDEE = (bmr: number, activityLevelValue: string) => {
    const activityMultipliers = {
      sedentary: 1.2, // Little or no exercise
      light: 1.375, // Light exercise 1-3 days/week
      moderate: 1.55, // Moderate exercise 3-5 days/week
      active: 1.725, // Hard exercise 6-7 days/week
      veryActive: 1.9 // Very hard exercise, physical job or training twice a day
    };

    let multiplier;
    switch (activityLevelValue) {
      case "sedentary":
        multiplier = activityMultipliers.sedentary;
        break;
      case "light":
        multiplier = activityMultipliers.light;
        break;
      case "moderate":
        multiplier = activityMultipliers.moderate;
        break;
      case "active":
        multiplier = activityMultipliers.active;
        break;
      case "veryActive":
        multiplier = activityMultipliers.veryActive;
        break;
      default:
        multiplier = activityMultipliers.moderate;
    }

    return bmr * multiplier;
  };

  const calculateMacros = () => {
    setError("");

    try {
      let weightInKg: number;
      let heightInCm: number;
      const ageValue = parseInt(age);

      if (isNaN(ageValue) || ageValue <= 0 || ageValue > 120) {
        throw new Error("Please enter a valid age between 1 and 120");
      }

      if (unit === "metric") {
        weightInKg = parseFloat(weight);
        heightInCm = parseFloat(height);

        if (isNaN(weightInKg) || isNaN(heightInCm) || weightInKg <= 0 || heightInCm <= 0) {
          throw new Error("Please enter valid height and weight values");
        }
      } else {
        const feetValue = parseFloat(feet);
        const inchesValue = parseFloat(inches);
        const lbsValue = parseFloat(lbs);

        if (isNaN(feetValue) || isNaN(inchesValue) || isNaN(lbsValue) ||
        feetValue <= 0 || lbsValue <= 0) {
          throw new Error("Please enter valid height and weight values");
        }

        weightInKg = lbsValue * 0.453592;
        heightInCm = (feetValue * 12 + inchesValue) * 2.54;
      }

      // Calculate BMR
      const bmr = calculateBMR(weightInKg, heightInCm, ageValue, gender);

      // Calculate TDEE
      const tdee = calculateTDEE(bmr, activityLevel);

      // Adjust calories based on goal
      let targetCalories;
      switch (goal) {
        case "lose":
          targetCalories = tdee * 0.8; // 20% deficit
          break;
        case "maintain":
          targetCalories = tdee;
          break;
        case "gain":
          targetCalories = tdee * 1.1; // 10% surplus
          break;
        default:
          targetCalories = tdee;
      }

      // Round to nearest 10
      targetCalories = Math.round(targetCalories / 10) * 10;

      // Calculate macros based on goal
      let proteinPercentage, carbPercentage, fatPercentage;

      if (goal === "lose") {
        proteinPercentage = 40;
        carbPercentage = 30;
        fatPercentage = 30;
      } else if (goal === "maintain") {
        proteinPercentage = 30;
        carbPercentage = 40;
        fatPercentage = 30;
      } else if (goal === "gain") {
        proteinPercentage = 30;
        carbPercentage = 45;
        fatPercentage = 25;
      }

      // Calculate grams of each macro
      const proteinCalories = targetCalories * (proteinPercentage / 100);
      const carbCalories = targetCalories * (carbPercentage / 100);
      const fatCalories = targetCalories * (fatPercentage / 100);

      const proteinGrams = Math.round(proteinCalories / 4); // 4 calories per gram
      const carbGrams = Math.round(carbCalories / 4); // 4 calories per gram
      const fatGrams = Math.round(fatCalories / 9); // 9 calories per gram

      setMacroResults({
        calories: targetCalories,
        protein: {
          grams: proteinGrams,
          calories: Math.round(proteinGrams * 4),
          percentage: proteinPercentage
        },
        carbs: {
          grams: carbGrams,
          calories: Math.round(carbGrams * 4),
          percentage: carbPercentage
        },
        fat: {
          grams: fatGrams,
          calories: Math.round(fatGrams * 9),
          percentage: fatPercentage
        }
      });
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setMacroResults(null);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setWeight("");
    setHeight("");
    setFeet("");
    setInches("");
    setLbs("");
    setMacroResults(null);
    setError("");
  };

  return (
    <CalculatorLayout
      title="Macro Calculator"
      description="Calculate your optimal macronutrient ratios based on your body and fitness goals."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="duih0mlxl" data-path="src/pages/calculators/MacroCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" data-id="fadl8sbnh" data-path="src/pages/calculators/MacroCalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="nfbemqoyu" data-path="src/pages/calculators/MacroCalculator.tsx">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="0swi7kpmb" data-path="src/pages/calculators/MacroCalculator.tsx">
          <div className="space-y-2" data-id="ggjupsrw2" data-path="src/pages/calculators/MacroCalculator.tsx">
            <Label htmlFor="age">Age (years)</Label>
            <Input
              id="age"
              type="number"
              placeholder="e.g., 30"
              value={age}
              onChange={(e) => setAge(e.target.value)} />

          </div>
          
          <div className="space-y-2" data-id="gwl470nyb" data-path="src/pages/calculators/MacroCalculator.tsx">
            <Label className="text-base font-medium">Gender</Label>
            <RadioGroup
              value={gender}
              onValueChange={setGender}
              className="flex gap-6">
              <div className="flex items-center space-x-2" data-id="8kd5zhorb" data-path="src/pages/calculators/MacroCalculator.tsx">
                <RadioGroupItem value="male" id="male" />
                <Label htmlFor="male">Male</Label>
              </div>
              <div className="flex items-center space-x-2" data-id="4d0ssn3jy" data-path="src/pages/calculators/MacroCalculator.tsx">
                <RadioGroupItem value="female" id="female" />
                <Label htmlFor="female">Female</Label>
              </div>
            </RadioGroup>
          </div>
        </div>

        <Separator />

        <div data-id="fmq2lyjn6" data-path="src/pages/calculators/MacroCalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
            value={unit}
            onValueChange={setUnit}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="vqyi0b7ct" data-path="src/pages/calculators/MacroCalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (cm, kg)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="tz7c6ab5y" data-path="src/pages/calculators/MacroCalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (ft, in, lbs)</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div className="space-y-4" data-id="yr6yuw50r" data-path="src/pages/calculators/MacroCalculator.tsx">
          {unit === "metric" ?
          <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="mgn3yo5wy" data-path="src/pages/calculators/MacroCalculator.tsx">
                <div className="space-y-2" data-id="74i9m4ldp" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                  id="height"
                  type="number"
                  placeholder="e.g., 170"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="hu47kdkk8" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                  id="weight"
                  type="number"
                  placeholder="e.g., 70"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </> :

          <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="aiv7ydf39" data-path="src/pages/calculators/MacroCalculator.tsx">
                <div className="space-y-2" data-id="izs7xexqj" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <Label htmlFor="feet">Height (ft)</Label>
                  <Input
                  id="feet"
                  type="number"
                  placeholder="e.g., 5"
                  value={feet}
                  onChange={(e) => setFeet(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="q8j4ca6z7" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <Label htmlFor="inches">Height (in)</Label>
                  <Input
                  id="inches"
                  type="number"
                  placeholder="e.g., 10"
                  value={inches}
                  onChange={(e) => setInches(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="fw5csahgx" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <Label htmlFor="lbs">Weight (lbs)</Label>
                  <Input
                  id="lbs"
                  type="number"
                  placeholder="e.g., 154"
                  value={lbs}
                  onChange={(e) => setLbs(e.target.value)} />

                </div>
              </div>
            </>
          }
        </div>

        <Separator />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="d2ln0bzbd" data-path="src/pages/calculators/MacroCalculator.tsx">
          <div className="space-y-2" data-id="fe4xg4pdw" data-path="src/pages/calculators/MacroCalculator.tsx">
            <Label htmlFor="activityLevel">Activity Level</Label>
            <Select
              value={activityLevel}
              onValueChange={setActivityLevel}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select activity level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sedentary">Sedentary (Little to no exercise)</SelectItem>
                <SelectItem value="light">Lightly Active (Light exercise 1-3 days/week)</SelectItem>
                <SelectItem value="moderate">Moderately Active (Moderate exercise 3-5 days/week)</SelectItem>
                <SelectItem value="active">Very Active (Hard exercise 6-7 days/week)</SelectItem>
                <SelectItem value="veryActive">Extremely Active (Very hard exercise, physical job)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2" data-id="3cgyxckwf" data-path="src/pages/calculators/MacroCalculator.tsx">
            <Label htmlFor="goal">Goal</Label>
            <Select
              value={goal}
              onValueChange={setGoal}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select your goal" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="lose">Weight Loss</SelectItem>
                <SelectItem value="maintain">Maintain Weight</SelectItem>
                <SelectItem value="gain">Muscle Gain</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-3" data-id="x8ez5ihx4" data-path="src/pages/calculators/MacroCalculator.tsx">
          <Button
            onClick={calculateMacros}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
            Calculate Macros
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>
            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="7ams1yi17" data-path="src/pages/calculators/MacroCalculator.tsx">
            {error}
          </div>
        }

        {macroResults !== null && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="space-y-5" data-id="dejnuoe9l" data-path="src/pages/calculators/MacroCalculator.tsx">
                <div data-id="vubqj1h91" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <p className="text-lg font-medium" data-id="m2nazgkuu" data-path="src/pages/calculators/MacroCalculator.tsx">Your Daily Calorie Target</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="753j9mhx0" data-path="src/pages/calculators/MacroCalculator.tsx">
                    {macroResults.calories} calories
                  </p>
                </div>
                
                <div className="mt-4 border-t pt-4" data-id="s9i7zxc0x" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <p className="text-lg font-medium mb-3" data-id="9m1mrtxcb" data-path="src/pages/calculators/MacroCalculator.tsx">Macronutrient Breakdown</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="2t0u6y90h" data-path="src/pages/calculators/MacroCalculator.tsx">
                    <div className="bg-blue-50 p-3 rounded-lg" data-id="d0erp3p2j" data-path="src/pages/calculators/MacroCalculator.tsx">
                      <p className="font-medium" data-id="2apmz69vu" data-path="src/pages/calculators/MacroCalculator.tsx">Protein</p>
                      <p className="text-xl font-bold text-blue-700" data-id="7xj628gg5" data-path="src/pages/calculators/MacroCalculator.tsx">
                        {macroResults.protein.grams}g
                      </p>
                      <p className="text-sm text-gray-600" data-id="b49od4twv" data-path="src/pages/calculators/MacroCalculator.tsx">
                        {macroResults.protein.calories} calories ({macroResults.protein.percentage}%)
                      </p>
                    </div>
                    <div className="bg-teal-50 p-3 rounded-lg" data-id="2rtvswzw9" data-path="src/pages/calculators/MacroCalculator.tsx">
                      <p className="font-medium" data-id="bwhexlcmq" data-path="src/pages/calculators/MacroCalculator.tsx">Carbohydrates</p>
                      <p className="text-xl font-bold text-teal-700" data-id="61rc6tnvz" data-path="src/pages/calculators/MacroCalculator.tsx">
                        {macroResults.carbs.grams}g
                      </p>
                      <p className="text-sm text-gray-600" data-id="escqkoboj" data-path="src/pages/calculators/MacroCalculator.tsx">
                        {macroResults.carbs.calories} calories ({macroResults.carbs.percentage}%)
                      </p>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg" data-id="zeose68qs" data-path="src/pages/calculators/MacroCalculator.tsx">
                      <p className="font-medium" data-id="brzvbgpet" data-path="src/pages/calculators/MacroCalculator.tsx">Fat</p>
                      <p className="text-xl font-bold text-indigo-700" data-id="wxiacbozb" data-path="src/pages/calculators/MacroCalculator.tsx">
                        {macroResults.fat.grams}g
                      </p>
                      <p className="text-sm text-gray-600" data-id="ljd2719uk" data-path="src/pages/calculators/MacroCalculator.tsx">
                        {macroResults.fat.calories} calories ({macroResults.fat.percentage}%)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 border-t pt-4" data-id="k8ups6wic" data-path="src/pages/calculators/MacroCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="nhf4wuwip" data-path="src/pages/calculators/MacroCalculator.tsx">
                    {goal === "lose" ?
                  "Weight Loss Strategy" :
                  goal === "gain" ?
                  "Muscle Gain Strategy" :
                  "Weight Maintenance Strategy"}
                  </p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="z7kytqzmi" data-path="src/pages/calculators/MacroCalculator.tsx">
                    {goal === "lose" &&
                  <>
                        <p className="mb-2" data-id="di0s2uexa" data-path="src/pages/calculators/MacroCalculator.tsx">
                          Your macros are calculated with a calorie deficit to support weight loss while preserving muscle mass. The higher protein ratio helps maintain lean muscle during fat loss.
                        </p>
                        <ul className="list-disc pl-6 space-y-1 mb-3" data-id="247wbu3wy" data-path="src/pages/calculators/MacroCalculator.tsx">
                          <li data-id="fcqkydrlt" data-path="src/pages/calculators/MacroCalculator.tsx">Focus on high-protein foods to stay satiated</li>
                          <li data-id="ejnxnrai2" data-path="src/pages/calculators/MacroCalculator.tsx">Prioritize complex carbs with high fiber</li>
                          <li data-id="s5jlvn1su" data-path="src/pages/calculators/MacroCalculator.tsx">Include healthy fats for hormone production</li>
                          <li data-id="414zw6qoa" data-path="src/pages/calculators/MacroCalculator.tsx">Aim for a gradual weight loss of 0.5-1kg (1-2lbs) per week</li>
                        </ul>
                      </>
                  }

                    {goal === "maintain" &&
                  <>
                        <p className="mb-2" data-id="t8by8tarl" data-path="src/pages/calculators/MacroCalculator.tsx">
                          Your macros are balanced to maintain your current weight while supporting overall health and activity level.
                        </p>
                        <ul className="list-disc pl-6 space-y-1 mb-3" data-id="sod0g8us3" data-path="src/pages/calculators/MacroCalculator.tsx">
                          <li data-id="0mnm47qn3" data-path="src/pages/calculators/MacroCalculator.tsx">Focus on nutrient-dense whole foods</li>
                          <li data-id="qrb46ng52" data-path="src/pages/calculators/MacroCalculator.tsx">Adjust intake based on hunger and energy levels</li>
                          <li data-id="9ko67q4vt" data-path="src/pages/calculators/MacroCalculator.tsx">Monitor weight weekly to ensure maintenance</li>
                          <li data-id="j7bsmfce1" data-path="src/pages/calculators/MacroCalculator.tsx">Consider cycling calories higher on training days</li>
                        </ul>
                      </>
                  }

                    {goal === "gain" &&
                  <>
                        <p className="mb-2" data-id="1nqsa9r60" data-path="src/pages/calculators/MacroCalculator.tsx">
                          Your macros provide a moderate calorie surplus with higher carbohydrates to fuel muscle growth and training performance.
                        </p>
                        <ul className="list-disc pl-6 space-y-1 mb-3" data-id="wmcfupfje" data-path="src/pages/calculators/MacroCalculator.tsx">
                          <li data-id="qkgcjexvj" data-path="src/pages/calculators/MacroCalculator.tsx">Focus on quality protein sources spread throughout the day</li>
                          <li data-id="yk7x8xydl" data-path="src/pages/calculators/MacroCalculator.tsx">Time carbohydrates around workouts for optimal performance</li>
                          <li data-id="gi0wcm500" data-path="src/pages/calculators/MacroCalculator.tsx">Don't neglect healthy fats for hormone optimization</li>
                          <li data-id="buqpchj6s" data-path="src/pages/calculators/MacroCalculator.tsx">Aim for gradual weight gain (0.25-0.5kg/0.5-1lb per week) to minimize fat gain</li>
                        </ul>
                      </>
                  }
                    <p className="mt-3 text-sm italic" data-id="tgx35vx12" data-path="src/pages/calculators/MacroCalculator.tsx">
                      Disclaimer: These calculations provide a starting point. Adjust your intake based on your results, energy levels, and individual response. For personalized nutrition advice, consult a registered dietitian.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="wfpuritbn" data-path="src/pages/calculators/MacroCalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="q06gr3gcl" data-path="src/pages/calculators/MacroCalculator.tsx">About Macronutrients</h3>
          <p className="mb-4" data-id="c6s9zpupz" data-path="src/pages/calculators/MacroCalculator.tsx">
            Macronutrients, often called "macros," are the three primary nutrients your body needs in large amounts: protein, carbohydrates, and fat. Each plays unique and essential roles in your health and fitness:
          </p>
          
          <ul className="list-disc pl-6 space-y-3" data-id="b08obky9u" data-path="src/pages/calculators/MacroCalculator.tsx">
            <li data-id="pufkdjn8j" data-path="src/pages/calculators/MacroCalculator.tsx">
              <strong data-id="quagpkgah" data-path="src/pages/calculators/MacroCalculator.tsx">Protein (4 calories per gram):</strong> The building block of muscle tissue, protein helps repair muscles after exercise, supports immune function, and helps you feel full longer. Good sources include meat, poultry, fish, eggs, dairy, legumes, and plant-based protein.
            </li>
            <li data-id="obkodqgid" data-path="src/pages/calculators/MacroCalculator.tsx">
              <strong data-id="3lbhu74dc" data-path="src/pages/calculators/MacroCalculator.tsx">Carbohydrates (4 calories per gram):</strong> Your body's primary and preferred energy source, especially for high-intensity exercise. Carbs are stored as glycogen in your muscles and liver. Sources include fruits, vegetables, grains, and sugars.
            </li>
            <li data-id="hxrchey42" data-path="src/pages/calculators/MacroCalculator.tsx">
              <strong data-id="s6g9l7r88" data-path="src/pages/calculators/MacroCalculator.tsx">Fat (9 calories per gram):</strong> Essential for hormone production, brain function, absorption of fat-soluble vitamins, and provides energy during low-intensity activities. Healthy sources include avocados, nuts, seeds, olive oil, and fatty fish.
            </li>
          </ul>
          
          <p className="mt-4 mb-4" data-id="hqt2iqtbs" data-path="src/pages/calculators/MacroCalculator.tsx">
            Finding the right macro balance is often more effective than simply counting calories, as it ensures you're getting the right nutrients for your specific goals. Whether you want to lose fat, gain muscle, or maintain your current body composition, understanding and tracking macros can help optimize your nutrition.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="d8gtg3ezu" data-path="src/pages/calculators/MacroCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="zxn24j55s" data-path="src/pages/calculators/MacroCalculator.tsx">Understanding Macronutrients</h2>
          
          <p className="mb-4" data-id="o27qdn7h3" data-path="src/pages/calculators/MacroCalculator.tsx">
            Macronutrients—proteins, carbohydrates, and fats—are the three primary nutrients that provide energy and serve essential functions in the body. While calorie balance remains fundamental for weight management, macronutrient distribution significantly impacts body composition, energy levels, and overall health.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6" data-id="tg4p1kn4k" data-path="src/pages/calculators/MacroCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="5kz4fjfsp" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="413vovz1x" data-path="src/pages/calculators/MacroCalculator.tsx">Protein (4 calories/g)</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="4llv3ejht" data-path="src/pages/calculators/MacroCalculator.tsx">
                <li data-id="knqm2xlu0" data-path="src/pages/calculators/MacroCalculator.tsx">Builds and repairs tissues</li>
                <li data-id="rmboq3haf" data-path="src/pages/calculators/MacroCalculator.tsx">Supports enzyme and hormone production</li>
                <li data-id="nn8fgzti3" data-path="src/pages/calculators/MacroCalculator.tsx">Enhances satiety and preserves muscle</li>
                <li data-id="hk91zr03x" data-path="src/pages/calculators/MacroCalculator.tsx">Has highest thermic effect (20-30%)</li>
                <li data-id="6lhgxn1nn" data-path="src/pages/calculators/MacroCalculator.tsx">Essential for recovery and immune function</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="wu1pz97dy" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="0uyasnakn" data-path="src/pages/calculators/MacroCalculator.tsx">Carbohydrates (4 calories/g)</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="3qnsmoeqd" data-path="src/pages/calculators/MacroCalculator.tsx">
                <li data-id="ywg5d5bpw" data-path="src/pages/calculators/MacroCalculator.tsx">Primary energy source for high-intensity activities</li>
                <li data-id="fe0ujlhvf" data-path="src/pages/calculators/MacroCalculator.tsx">Spares protein for tissue building/repair</li>
                <li data-id="8gk2pnxpj" data-path="src/pages/calculators/MacroCalculator.tsx">Fuels brain function</li>
                <li data-id="ujar6kudk" data-path="src/pages/calculators/MacroCalculator.tsx">Provides fiber for digestive health</li>
                <li data-id="3dwczb5e1" data-path="src/pages/calculators/MacroCalculator.tsx">Supports athletic performance</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="ox3ot2r2p" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="3q1cv7fdi" data-path="src/pages/calculators/MacroCalculator.tsx">Fats (9 calories/g)</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="fato4032i" data-path="src/pages/calculators/MacroCalculator.tsx">
                <li data-id="d53a5xulc" data-path="src/pages/calculators/MacroCalculator.tsx">Supports hormone production</li>
                <li data-id="4h6ng07d8" data-path="src/pages/calculators/MacroCalculator.tsx">Provides essential fatty acids</li>
                <li data-id="3k7uhp8kr" data-path="src/pages/calculators/MacroCalculator.tsx">Enables absorption of fat-soluble vitamins</li>
                <li data-id="2n4892axk" data-path="src/pages/calculators/MacroCalculator.tsx">Forms cell membranes</li>
                <li data-id="17cirjkok" data-path="src/pages/calculators/MacroCalculator.tsx">Energy source for low-intensity activities</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="up5ysvntg" data-path="src/pages/calculators/MacroCalculator.tsx">Starter Macronutrient Ratios by Goal</h3>
          <div className="space-y-4 mb-6" data-id="02eeo88i1" data-path="src/pages/calculators/MacroCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="mia23qnly" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="0gmg0yekk" data-path="src/pages/calculators/MacroCalculator.tsx">Balanced Maintenance</h4>
              <p className="font-mono text-sm" data-id="ogr0fgcxr" data-path="src/pages/calculators/MacroCalculator.tsx">Protein: 25-30% | Carbohydrates: 40-50% | Fats: 25-35%</p>
              <p className="text-sm text-gray-600 mt-1" data-id="j1o4p2h55" data-path="src/pages/calculators/MacroCalculator.tsx">Good for general health and weight maintenance</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="fyirnz5am" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="cuar39cre" data-path="src/pages/calculators/MacroCalculator.tsx">Fat Loss (Moderate Carb)</h4>
              <p className="font-mono text-sm" data-id="yms2tqbmf" data-path="src/pages/calculators/MacroCalculator.tsx">Protein: 30-35% | Carbohydrates: 30-40% | Fats: 25-35%</p>
              <p className="text-sm text-gray-600 mt-1" data-id="cn1kxwunr" data-path="src/pages/calculators/MacroCalculator.tsx">Higher protein supports muscle preservation during caloric deficit</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="hbdhkjcw1" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="96jy23704" data-path="src/pages/calculators/MacroCalculator.tsx">Fat Loss (Lower Carb)</h4>
              <p className="font-mono text-sm" data-id="e3frerbas" data-path="src/pages/calculators/MacroCalculator.tsx">Protein: 30-35% | Carbohydrates: 15-25% | Fats: 40-50%</p>
              <p className="text-sm text-gray-600 mt-1" data-id="w7c1drk0c" data-path="src/pages/calculators/MacroCalculator.tsx">Some individuals find lower carb approaches more effective for fat loss</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="c9zqn2nif" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="31hgrobny" data-path="src/pages/calculators/MacroCalculator.tsx">Muscle Gain</h4>
              <p className="font-mono text-sm" data-id="etzql3ynz" data-path="src/pages/calculators/MacroCalculator.tsx">Protein: 25-30% | Carbohydrates: 45-55% | Fats: 20-30%</p>
              <p className="text-sm text-gray-600 mt-1" data-id="qequacfhg" data-path="src/pages/calculators/MacroCalculator.tsx">Higher carbohydrates support training performance and recovery</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="shz5in2c6" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="n0k0hkzy9" data-path="src/pages/calculators/MacroCalculator.tsx">Endurance Performance</h4>
              <p className="font-mono text-sm" data-id="7ndxm5thq" data-path="src/pages/calculators/MacroCalculator.tsx">Protein: 20-25% | Carbohydrates: 50-65% | Fats: 20-30%</p>
              <p className="text-sm text-gray-600 mt-1" data-id="5smzx5j7f" data-path="src/pages/calculators/MacroCalculator.tsx">Higher carbohydrate intake supports glycogen stores for endurance</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="x8lhaeu1n" data-path="src/pages/calculators/MacroCalculator.tsx">Beyond the Ratio: Quality Matters Too</h3>
          <div className="space-y-4 mb-6" data-id="hwhfltv25" data-path="src/pages/calculators/MacroCalculator.tsx">
            <div className="border-l-4 border-primary pl-4 py-1" data-id="kxuoqewis" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="wbb6ut2k2" data-path="src/pages/calculators/MacroCalculator.tsx">Protein Quality</h4>
              <p className="text-sm" data-id="i3vbg1pzo" data-path="src/pages/calculators/MacroCalculator.tsx">Emphasize complete proteins with all essential amino acids. Include a variety of sources including animal proteins (if consumed) and plant proteins.</p>
            </div>
            
            <div className="border-l-4 border-primary pl-4 py-1" data-id="aqqm51onq" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="oec25w3kg" data-path="src/pages/calculators/MacroCalculator.tsx">Carbohydrate Quality</h4>
              <p className="text-sm" data-id="zdq5v2sgs" data-path="src/pages/calculators/MacroCalculator.tsx">Prioritize fiber-rich, minimally processed sources (fruits, vegetables, whole grains, legumes). Moderate refined carbohydrates and added sugars.</p>
            </div>
            
            <div className="border-l-4 border-primary pl-4 py-1" data-id="hc0irwuya" data-path="src/pages/calculators/MacroCalculator.tsx">
              <h4 className="font-medium" data-id="ekivhqloc" data-path="src/pages/calculators/MacroCalculator.tsx">Fat Quality</h4>
              <p className="text-sm" data-id="zi9z9pe21" data-path="src/pages/calculators/MacroCalculator.tsx">Include omega-3 fatty acids from fatty fish, walnuts, or flax. Emphasize monounsaturated fats from olive oil, avocados, and nuts. Moderate saturated fats and minimize trans fats.</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="41ztwsspw" data-path="src/pages/calculators/MacroCalculator.tsx">Tips for Implementing Your Macro Plan</h3>
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="lprm0ywht" data-path="src/pages/calculators/MacroCalculator.tsx">
            <li data-id="m9iptnrrl" data-path="src/pages/calculators/MacroCalculator.tsx"><strong data-id="haxyo8t30" data-path="src/pages/calculators/MacroCalculator.tsx">Start gradually</strong> - Adjust one meal at a time rather than overhauling your entire diet</li>
            <li data-id="ceriso0o9" data-path="src/pages/calculators/MacroCalculator.tsx"><strong data-id="u4m606kzx" data-path="src/pages/calculators/MacroCalculator.tsx">Plan ahead</strong> - Prepare meals and snacks that align with your macro targets</li>
            <li data-id="zdoznx5ew" data-path="src/pages/calculators/MacroCalculator.tsx"><strong data-id="lmvwjb5u7" data-path="src/pages/calculators/MacroCalculator.tsx">Focus on whole foods first</strong> - Build your diet around nutrient-dense options</li>
            <li data-id="5v1wrf07j" data-path="src/pages/calculators/MacroCalculator.tsx"><strong data-id="78h2n7zf5" data-path="src/pages/calculators/MacroCalculator.tsx">Use a tracking app</strong> - At least initially, to learn portion sizes and food composition</li>
            <li data-id="i31dymwwr" data-path="src/pages/calculators/MacroCalculator.tsx"><strong data-id="w874k8hg2" data-path="src/pages/calculators/MacroCalculator.tsx">Be flexible</strong> - Small variations day-to-day are normal and not significant</li>
            <li data-id="nns4171ur" data-path="src/pages/calculators/MacroCalculator.tsx"><strong data-id="ci1zobdov" data-path="src/pages/calculators/MacroCalculator.tsx">Reassess regularly</strong> - Adjust your macros as your body, goals, and activity levels change</li>
          </ul>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="oinwotguw" data-path="src/pages/calculators/MacroCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="idcxtgvji" data-path="src/pages/calculators/MacroCalculator.tsx">Learn More About Macronutrients</h3>
            <p className="mb-3" data-id="txvb59y3q" data-path="src/pages/calculators/MacroCalculator.tsx">
              For an in-depth understanding of macronutrients, optimal ratios for different goals, food quality considerations, and practical implementation strategies, check out our comprehensive guide:
            </p>
            <Link
            to="/blog/macro-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete Macro Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="kqkznltt8" data-path="src/pages/calculators/MacroCalculator.tsx">
            Remember that these recommendations provide general guidelines. Individual needs vary based on metabolism, activity patterns, and personal response. The most effective approach balances evidence-based guidelines with personal preferences and sustainability.
          </p>
        </div>
    </CalculatorLayout>);

};

export default MacroCalculator;