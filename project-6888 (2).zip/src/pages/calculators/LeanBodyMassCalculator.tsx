import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

const LeanBodyMassCalculator = () => {
  const [unit, setUnit] = useState("metric");
  const [gender, setGender] = useState("male");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [lbs, setLbs] = useState("");
  const [lbm, setLbm] = useState<{boer: number;james: number;hume: number;} | null>(null);
  const [error, setError] = useState("");

  const calculateLBM = () => {
    setError("");

    try {
      let heightInCm: number;
      let weightInKg: number;

      if (unit === "metric") {
        heightInCm = parseFloat(height);
        weightInKg = parseFloat(weight);

        if (isNaN(heightInCm) || isNaN(weightInKg) || heightInCm <= 0 || weightInKg <= 0) {
          throw new Error("Please enter valid height and weight values");
        }
      } else {
        const feetValue = parseFloat(feet);
        const inchesValue = parseFloat(inches);
        const lbsValue = parseFloat(lbs);

        if (isNaN(feetValue) || isNaN(inchesValue) || isNaN(lbsValue) ||
        feetValue <= 0 || lbsValue <= 0) {
          throw new Error("Please enter valid height and weight values");
        }

        heightInCm = (feetValue * 12 + inchesValue) * 2.54;
        weightInKg = lbsValue * 0.453592;
      }

      // Calculate LBM using different formulas
      let boer, james, hume;

      if (gender === "male") {
        // For males
        boer = 0.407 * weightInKg + 0.267 * heightInCm - 19.2;
        james = 1.1 * weightInKg - 128 * (weightInKg / heightInCm) * (weightInKg / heightInCm);
        hume = 0.32810 * weightInKg + 0.33929 * heightInCm - 29.5336;
      } else {
        // For females
        boer = 0.252 * weightInKg + 0.473 * heightInCm - 48.3;
        james = 1.07 * weightInKg - 148 * (weightInKg / heightInCm) * (weightInKg / heightInCm);
        hume = 0.29569 * weightInKg + 0.41813 * heightInCm - 43.2933;
      }

      setLbm({
        boer: Math.round(boer * 10) / 10,
        james: Math.round(james * 10) / 10,
        hume: Math.round(hume * 10) / 10
      });
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setLbm(null);
    }
  };

  const resetCalculator = () => {
    setHeight("");
    setWeight("");
    setFeet("");
    setInches("");
    setLbs("");
    setLbm(null);
    setError("");
  };

  return (
    <CalculatorLayout
      title="Lean Body Mass Calculator"
      description="Calculate your lean body mass (LBM) - the weight of your body excluding fat."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="y6rvjc8wy" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" data-id="kqes6mqtr" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="4jec3drdb" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
        <div data-id="cru9ceqlu" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
          <Label className="text-lg font-medium">Gender</Label>
          <RadioGroup
            value={gender}
            onValueChange={setGender}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="2r3vjthwx" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">Male</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="cobo8jihl" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">Female</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div data-id="hj5aenajd" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
            value={unit}
            onValueChange={setUnit}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="thyqwbo21" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (cm, kg)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="2sil9yl6j" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (ft, in, lbs)</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div className="space-y-4" data-id="57c1euqny" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
          {unit === "metric" ?
          <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="jju5yutpd" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                <div className="space-y-2" data-id="0baljgg56" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                  id="height"
                  type="number"
                  placeholder="e.g., 170"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="js5kfdx9v" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                  id="weight"
                  type="number"
                  placeholder="e.g., 70"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)} />

                </div>
              </div>
            </> :

          <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="15iv79xne" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                <div className="space-y-2" data-id="obtfn1g86" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <Label htmlFor="feet">Height (ft)</Label>
                  <Input
                  id="feet"
                  type="number"
                  placeholder="e.g., 5"
                  value={feet}
                  onChange={(e) => setFeet(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="g0115wd8b" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <Label htmlFor="inches">Height (in)</Label>
                  <Input
                  id="inches"
                  type="number"
                  placeholder="e.g., 10"
                  value={inches}
                  onChange={(e) => setInches(e.target.value)} />

                </div>
                <div className="space-y-2" data-id="bhw43vwwj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <Label htmlFor="lbs">Weight (lbs)</Label>
                  <Input
                  id="lbs"
                  type="number"
                  placeholder="e.g., 160"
                  value={lbs}
                  onChange={(e) => setLbs(e.target.value)} />

                </div>
              </div>
            </>
          }
        </div>

        <div className="flex gap-3" data-id="2862mefdl" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
          <Button
            onClick={calculateLBM}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
            Calculate Lean Body Mass
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>
            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="n10xlxc5s" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            {error}
          </div>
        }

        {lbm !== null && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="space-y-4" data-id="p4jstw9zf" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                <div data-id="5h33xheqs" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <p className="text-lg font-medium" data-id="9v1jxvl2p" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Your Lean Body Mass (Average)</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="wlvxt5kyj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                    {((lbm.boer + lbm.james + lbm.hume) / 3).toFixed(1)} {unit === "metric" ? "kg" : "lbs"}
                  </p>
                </div>
                
                <div className="mt-4 border-t pt-4" data-id="hdx9wgxaf" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <p className="text-lg font-medium mb-3" data-id="4hlfb75km" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Results by Formula</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="g3z3dt1wm" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                    <div className="bg-blue-50 p-3 rounded-lg" data-id="j2sqan7rw" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                      <p className="font-medium" data-id="hh5n5w6m0" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Boer Formula</p>
                      <p className="text-xl font-bold text-blue-700" data-id="qdvipkjwg" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                        {unit === "metric" ?
                      `${lbm.boer} kg` :
                      `${Math.round(lbm.boer * 2.20462 * 10) / 10} lbs`}
                      </p>
                    </div>
                    <div className="bg-teal-50 p-3 rounded-lg" data-id="ib6jed6q8" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                      <p className="font-medium" data-id="5h1dfvczx" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">James Formula</p>
                      <p className="text-xl font-bold text-teal-700" data-id="b9epzlr0h" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                        {unit === "metric" ?
                      `${lbm.james} kg` :
                      `${Math.round(lbm.james * 2.20462 * 10) / 10} lbs`}
                      </p>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg" data-id="m2hawbhwk" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                      <p className="font-medium" data-id="9qoc3mhm9" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Hume Formula</p>
                      <p className="text-xl font-bold text-indigo-700" data-id="m050y3zto" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                        {unit === "metric" ?
                      `${lbm.hume} kg` :
                      `${Math.round(lbm.hume * 2.20462 * 10) / 10} lbs`}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 border-t pt-4" data-id="vxbhu69yv" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="js8jactnj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Interpretation</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="kzh7arq5i" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                    <p className="mb-2" data-id="fc2998r77" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                      Your lean body mass is the weight of your body excluding fat. This includes muscles, bones, organs, blood, skin, and everything else that is not fat tissue.
                    </p>
                    <p className="mb-2" data-id="bqxrcr7bq" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                      Lean body mass is an important metric for:
                    </p>
                    <ul className="list-disc pl-6 space-y-1 mb-2" data-id="hw62un8yo" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                      <li data-id="kb43u5qe8" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Determining calorie and protein needs</li>
                      <li data-id="gda1vy48b" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Tracking fitness progress beyond scale weight</li>
                      <li data-id="bcv9snvny" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Calculating dosages for certain medications</li>
                      <li data-id="60vdf2c2c" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Estimating metabolic rate and energy requirements</li>
                    </ul>
                    <p className="mt-3 text-sm italic" data-id="pp12pa7kh" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                      Disclaimer: These calculations provide estimates only. For more accurate measurements, consider methods like DEXA scans, hydrostatic weighing, or bioelectrical impedance analysis under professional guidance.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="dbqhsnasu" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="4g2hrrtft" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">About Lean Body Mass</h3>
          <p className="mb-4" data-id="e9mmtaugv" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            Lean Body Mass (LBM) is the weight of everything in your body except fat. This includes muscles, bones, organs, blood, and skin. LBM is an important metric for assessing health and fitness beyond just your total weight.
          </p>
          <h3 className="text-lg font-semibold mb-2" data-id="v82elxjol" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Lean Body Mass Formulas:</h3>
          <ul className="list-disc pl-6 space-y-1" data-id="96k7dwl0l" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            <li data-id="e928r42ge" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="aimrcdw3q" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Boer Formula (1984):</strong> Uses a linear relationship between height, weight, and gender.</li>
            <li data-id="65wuz9iz9" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="yzpzow8ma" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">James Formula (1976):</strong> Accounts for the non-linear relationship between height and weight.</li>
            <li data-id="00putbzcm" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="3xgiy9w9k" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Hume Formula (1966):</strong> Based on studies using underwater weighing techniques.</li>
          </ul>
          <p className="mt-4 mb-4" data-id="rc64cxq28" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            These formulas provide estimates based on statistical models. For more precise measurements, professional methods like DEXA scans, bioelectrical impedance analysis (BIA), or underwater weighing offer greater accuracy.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="bwtlqcplw" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="97wjx730w" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Understanding Lean Body Mass</h2>
          
          <p className="mb-4" data-id="wfnaz1tcx" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            Lean Body Mass (LBM), also called Fat-Free Mass (FFM), refers to all the body components except fat. This includes muscle, bones, organs, water, and connective tissues. Of these components, skeletal muscle is the largest and most metabolically active.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="piblcnsix" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="f0aztosb8" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="g0g65bxcg" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Why Lean Body Mass Matters</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="0gl3296bs" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                <li data-id="4ndb445sv" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="3m2b5ya8p" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Metabolic rate:</strong> Muscle burns calories even at rest</li>
                <li data-id="r43oe1vaj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="zp2s28zh5" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Glucose regulation:</strong> Muscles help manage blood sugar</li>
                <li data-id="gkkuak1mm" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="v1vzwz9k1" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Functional capacity:</strong> Strength and endurance depend on muscle</li>
                <li data-id="7h94hwoqe" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="lp8n91p08" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Hormonal health:</strong> Muscle influences hormone production</li>
                <li data-id="k8gr8se21" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="ldqdun52g" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Bone health:</strong> Muscle contractions stimulate bone maintenance</li>
                <li data-id="wfhdzievc" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="gmzng9u1t" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Longevity:</strong> Higher muscle mass is associated with longer life</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="dx49vzrc9" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="3vop70s3m" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Using LBM to Optimize Health</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="xwqypk3sz" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                <li data-id="6l1q1wrcj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="xkmcwwvqy" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Calorie needs:</strong> More accurate BMR calculation</li>
                <li data-id="hqi59nq4l" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="3cuajk22c" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Protein requirements:</strong> Better calculated based on LBM</li>
                <li data-id="llv8mahqt" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="a53w1ksfu" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Hydration needs:</strong> Lean tissue contains more water</li>
                <li data-id="mi87mefrg" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="hn9hwe9jn" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Exercise programming:</strong> Guides resistance training goals</li>
                <li data-id="yn3fcj6y3" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="hrg3hmpgx" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Body composition goals:</strong> More meaningful than weight alone</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="d0v1bcdvs" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">About the Calculation Methods</h3>
          <p className="mb-4" data-id="e80vhvolr" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            Our calculator uses several established formulas to estimate lean body mass when direct body fat measurements aren't available:
          </p>
          
          <div className="space-y-4 mb-6" data-id="w6kbogvkv" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="aroig0agm" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <h4 className="font-medium" data-id="dreob4cl9" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Boer Formula</h4>
              <p className="font-mono text-sm" data-id="tc6hui4op" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Men: LBM = 0.407 × Weight (kg) + 0.267 × Height (cm) - 19.2</p>
              <p className="font-mono text-sm" data-id="p9rjty8hz" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Women: LBM = 0.252 × Weight (kg) + 0.473 × Height (cm) - 48.3</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="b35i374f6" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <h4 className="font-medium" data-id="ob9n9mypq" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">James Formula</h4>
              <p className="font-mono text-sm" data-id="xtgglti9x" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Men: LBM = 1.1 × Weight (kg) - 128 × (Weight (kg) ÷ Height (cm))²</p>
              <p className="font-mono text-sm" data-id="6eukiz396" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Women: LBM = 1.07 × Weight (kg) - 148 × (Weight (kg) ÷ Height (cm))²</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="7ede595li" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <h4 className="font-medium" data-id="7z7e8qjk8" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Hume Formula</h4>
              <p className="font-mono text-sm" data-id="cke95a85i" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Men: LBM = 0.32810 × Weight (kg) + 0.33929 × Height (cm) - 29.5336</p>
              <p className="font-mono text-sm" data-id="wbfbwz0su" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Women: LBM = 0.29569 × Weight (kg) + 0.41813 × Height (cm) - 43.2933</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="vkmnpr4wu" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Strategies to Preserve and Build Lean Body Mass</h3>
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="jn14zzwrg" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="9d72bl6mp" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              <div data-id="2u0tavh74" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                <li data-id="9rr7dx84n" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="4t2qa2xbx" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Resistance training:</strong> 2-3 times per week, focusing on compound movements</li>
                <li data-id="pldsrx9h4" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="5rv4e0inm" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Adequate protein:</strong> 1.6-2.2g per kg of body weight daily</li>
                <li data-id="n28y1mue8" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="l1085u72e" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Calorie sufficiency:</strong> Avoid severe or prolonged caloric restriction</li>
                <li data-id="jm6gznyxj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="w3l6co70i" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Progressive overload:</strong> Gradually increase weights or repetitions</li>
              </div>
              <div data-id="picjy3b67" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
                <li data-id="5pjwra68x" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="bsexc8kz3" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Quality sleep:</strong> 7-9 hours per night for optimal recovery</li>
                <li data-id="md4lgfdna" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="4yzf7o4wn" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Stress management:</strong> Chronic stress increases muscle breakdown</li>
                <li data-id="exfa4wigx" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="tbezuo2aj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Hydration:</strong> Proper fluid intake supports protein synthesis</li>
                <li data-id="1mkgy7lvl" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx"><strong data-id="b44adqt75" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Recovery time:</strong> Allow 48-72 hours between training same muscle groups</li>
              </div>
            </div>
          </ul>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="6u6kjjfmj" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="j7vjbsuag" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">Learn More About Lean Body Mass</h3>
            <p className="mb-3" data-id="yzycymms6" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
              For an in-depth understanding of lean body mass, its importance for health and metabolism, and strategies to build and preserve muscle, check out our comprehensive guide:
            </p>
            <Link
            to="/blog/lean-body-mass-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete Lean Body Mass Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="eo9ieb9mf" data-path="src/pages/calculators/LeanBodyMassCalculator.tsx">
            Remember that these formulas provide estimates of lean body mass. For the most accurate assessment, consider methods like DEXA scans, bioelectrical impedance analysis from professional equipment, or hydrostatic weighing performed by qualified professionals.
          </p>
        </div>
    </CalculatorLayout>);

};

export default LeanBodyMassCalculator;