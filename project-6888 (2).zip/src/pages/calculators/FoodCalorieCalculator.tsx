import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

interface FoodItem {
  name: string;
  amount: string;
  unit: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

// Database of common foods with nutritional values per 100g
const foodDatabase = [
// Proteins
{ value: "chicken_breast", label: "Chicken Breast", calories: 165, protein: 31, carbs: 0, fat: 3.6 },
{ value: "beef_ground", label: "Ground Beef (90% lean)", calories: 176, protein: 26, carbs: 0, fat: 8 },
{ value: "tuna", label: "Tuna (canned in water)", calories: 109, protein: 24, carbs: 0, fat: 0.9 },
{ value: "salmon", label: "Salmon", calories: 206, protein: 22, carbs: 0, fat: 13 },
{ value: "eggs", label: "Eggs", calories: 143, protein: 13, carbs: 0.7, fat: 10 },
{ value: "tofu", label: "Tofu", calories: 76, protein: 8, carbs: 2, fat: 4.2 },
{ value: "greek_yogurt", label: "Greek Yogurt (plain, non-fat)", calories: 59, protein: 10, carbs: 3.6, fat: 0.4 },

// Carbohydrates
{ value: "rice_white", label: "White Rice (cooked)", calories: 130, protein: 2.7, carbs: 28, fat: 0.3 },
{ value: "rice_brown", label: "Brown Rice (cooked)", calories: 112, protein: 2.6, carbs: 23, fat: 0.9 },
{ value: "potato", label: "Potato", calories: 77, protein: 2, carbs: 17, fat: 0.1 },
{ value: "sweet_potato", label: "Sweet Potato", calories: 86, protein: 1.6, carbs: 20, fat: 0.1 },
{ value: "bread_white", label: "White Bread", calories: 265, protein: 9, carbs: 49, fat: 3.2 },
{ value: "bread_whole", label: "Whole Wheat Bread", calories: 247, protein: 13, carbs: 41, fat: 3.4 },
{ value: "pasta", label: "Pasta (cooked)", calories: 158, protein: 5.8, carbs: 31, fat: 0.9 },
{ value: "oats", label: "Oats", calories: 389, protein: 16.9, carbs: 66, fat: 6.9 },

// Fruits
{ value: "apple", label: "Apple", calories: 52, protein: 0.3, carbs: 14, fat: 0.2 },
{ value: "banana", label: "Banana", calories: 89, protein: 1.1, carbs: 23, fat: 0.3 },
{ value: "orange", label: "Orange", calories: 47, protein: 0.9, carbs: 12, fat: 0.1 },
{ value: "grapes", label: "Grapes", calories: 69, protein: 0.7, carbs: 18, fat: 0.2 },
{ value: "strawberries", label: "Strawberries", calories: 32, protein: 0.7, carbs: 7.7, fat: 0.3 },
{ value: "blueberries", label: "Blueberries", calories: 57, protein: 0.7, carbs: 14, fat: 0.3 },

// Vegetables
{ value: "broccoli", label: "Broccoli", calories: 34, protein: 2.8, carbs: 7, fat: 0.4 },
{ value: "spinach", label: "Spinach", calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4 },
{ value: "kale", label: "Kale", calories: 49, protein: 4.3, carbs: 8.8, fat: 0.9 },
{ value: "carrots", label: "Carrots", calories: 41, protein: 0.9, carbs: 10, fat: 0.2 },
{ value: "tomato", label: "Tomato", calories: 18, protein: 0.9, carbs: 3.9, fat: 0.2 },
{ value: "cucumber", label: "Cucumber", calories: 15, protein: 0.7, carbs: 3.6, fat: 0.1 },

// Dairy and Alternatives
{ value: "milk", label: "Milk (whole)", calories: 61, protein: 3.2, carbs: 4.8, fat: 3.3 },
{ value: "milk_skim", label: "Milk (skim)", calories: 34, protein: 3.4, carbs: 5, fat: 0.1 },
{ value: "almond_milk", label: "Almond Milk (unsweetened)", calories: 15, protein: 0.5, carbs: 0.6, fat: 1.1 },
{ value: "cheese_cheddar", label: "Cheddar Cheese", calories: 402, protein: 25, carbs: 1.3, fat: 33 },

// Nuts and Seeds
{ value: "almonds", label: "Almonds", calories: 579, protein: 21, carbs: 22, fat: 50 },
{ value: "walnuts", label: "Walnuts", calories: 654, protein: 15, carbs: 14, fat: 65 },
{ value: "chia_seeds", label: "Chia Seeds", calories: 486, protein: 17, carbs: 42, fat: 31 },

// Fats and Oils
{ value: "olive_oil", label: "Olive Oil", calories: 884, protein: 0, carbs: 0, fat: 100 },
{ value: "avocado", label: "Avocado", calories: 160, protein: 2, carbs: 8.5, fat: 15 },
{ value: "butter", label: "Butter", calories: 717, protein: 0.9, carbs: 0.1, fat: 81 },

// Other
{ value: "honey", label: "Honey", calories: 304, protein: 0.3, carbs: 82, fat: 0 },
{ value: "sugar", label: "Sugar", calories: 387, protein: 0, carbs: 100, fat: 0 },
{ value: "dark_chocolate", label: "Dark Chocolate (70%)", calories: 598, protein: 7.8, carbs: 46, fat: 43 }];


const FoodCalorieCalculator = () => {
  const [foodItems, setFoodItems] = useState<FoodItem[]>([
  { name: "", amount: "", unit: "grams", calories: 0, protein: 0, carbs: 0, fat: 0 }]
  );
  const [totalNutrition, setTotalNutrition] = useState<{
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }>({ calories: 0, protein: 0, carbs: 0, fat: 0 });
  const [error, setError] = useState("");

  const updateFoodItem = (index: number, field: keyof FoodItem, value: string) => {
    const updatedItems = [...foodItems];

    if (field === "name") {
      const selectedFood = foodDatabase.find((food) => food.value === value);
      if (selectedFood) {
        updatedItems[index] = {
          ...updatedItems[index],
          name: value,
          calories: selectedFood.calories,
          protein: selectedFood.protein,
          carbs: selectedFood.carbs,
          fat: selectedFood.fat
        };
      }
    } else if (field === "amount" || field === "unit") {
      updatedItems[index] = {
        ...updatedItems[index],
        [field]: value
      };
    }

    setFoodItems(updatedItems);
  };

  const addFoodItem = () => {
    setFoodItems([
    ...foodItems,
    { name: "", amount: "", unit: "grams", calories: 0, protein: 0, carbs: 0, fat: 0 }]
    );
  };

  const removeFoodItem = (index: number) => {
    if (foodItems.length > 1) {
      const updatedItems = foodItems.filter((_, i) => i !== index);
      setFoodItems(updatedItems);
    }
  };

  const calculateNutrition = () => {
    setError("");

    try {
      // Validate input
      for (const item of foodItems) {
        if (!item.name || !item.amount) {
          throw new Error("Please select a food and enter an amount for all items");
        }

        const amount = parseFloat(item.amount);
        if (isNaN(amount) || amount <= 0) {
          throw new Error("Please enter a valid amount for all items");
        }
      }

      let totalCals = 0;
      let totalProtein = 0;
      let totalCarbs = 0;
      let totalFat = 0;

      foodItems.forEach((item) => {
        const amount = parseFloat(item.amount);
        const multiplier = item.unit === "grams" ? amount / 100 : amount;

        totalCals += item.calories * multiplier;
        totalProtein += item.protein * multiplier;
        totalCarbs += item.carbs * multiplier;
        totalFat += item.fat * multiplier;
      });

      setTotalNutrition({
        calories: Math.round(totalCals),
        protein: Math.round(totalProtein * 10) / 10,
        carbs: Math.round(totalCarbs * 10) / 10,
        fat: Math.round(totalFat * 10) / 10
      });
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
    }
  };

  const resetCalculator = () => {
    setFoodItems([
    { name: "", amount: "", unit: "grams", calories: 0, protein: 0, carbs: 0, fat: 0 }]
    );
    setTotalNutrition({ calories: 0, protein: 0, carbs: 0, fat: 0 });
    setError("");
  };

  return (
    <CalculatorLayout
      title="Food Calorie Calculator"
      description="Calculate the calories and macronutrients in your meals with this simple food calculator."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="boaard6r6" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" data-id="y43fzcs8y" data-path="src/pages/calculators/FoodCalorieCalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="fvx65nysq" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
        <p className="text-sm text-gray-500" data-id="ueeyepl7c" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Select foods from our database and enter the amount to calculate total calories and macronutrients.</p>
        
        {foodItems.map((item, index) =>
        <div key={index} className="space-y-3 border p-4 rounded-lg" data-id="dkfqpwdlw" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            <div className="flex items-center justify-between" data-id="dq9h1r79o" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <Label className="text-base font-medium">Food Item #{index + 1}</Label>
              {foodItems.length > 1 &&
            <Button
              variant="ghost"
              size="sm"
              onClick={() => removeFoodItem(index)}
              className="text-red-500 hover:text-red-700 hover:bg-red-50">

                  Remove
                </Button>
            }
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="8d7343hb2" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <div className="space-y-2" data-id="p9al4fo78" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                <Label htmlFor={`food-${index}`}>Food</Label>
                <Select
                value={item.name}
                onValueChange={(value) => updateFoodItem(index, "name", value)}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select a food" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Select a food</SelectItem>
                    
                    <SelectItem value="section-protein" disabled>
                      -- Proteins --
                    </SelectItem>
                    {foodDatabase.slice(0, 7).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                    
                    <SelectItem value="section-carbs" disabled>
                      -- Carbohydrates --
                    </SelectItem>
                    {foodDatabase.slice(7, 15).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                    
                    <SelectItem value="section-fruits" disabled>
                      -- Fruits --
                    </SelectItem>
                    {foodDatabase.slice(15, 21).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                    
                    <SelectItem value="section-vegetables" disabled>
                      -- Vegetables --
                    </SelectItem>
                    {foodDatabase.slice(21, 27).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                    
                    <SelectItem value="section-dairy" disabled>
                      -- Dairy & Alternatives --
                    </SelectItem>
                    {foodDatabase.slice(27, 31).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                    
                    <SelectItem value="section-nuts" disabled>
                      -- Nuts & Seeds --
                    </SelectItem>
                    {foodDatabase.slice(31, 34).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                    
                    <SelectItem value="section-fats" disabled>
                      -- Fats & Oils --
                    </SelectItem>
                    {foodDatabase.slice(34, 37).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                    
                    <SelectItem value="section-other" disabled>
                      -- Other --
                    </SelectItem>
                    {foodDatabase.slice(37).map((food) =>
                  <SelectItem key={food.value} value={food.value}>
                        {food.label}
                      </SelectItem>
                  )}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex space-x-2" data-id="qmyfz5518" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                <div className="space-y-2 flex-grow" data-id="4w5m4k8ic" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                  <Label htmlFor={`amount-${index}`}>Amount</Label>
                  <Input
                  id={`amount-${index}`}
                  type="number"
                  placeholder="e.g., 100"
                  value={item.amount}
                  onChange={(e) => updateFoodItem(index, "amount", e.target.value)} />

                </div>
                <div className="space-y-2 w-24" data-id="lmcry4w1i" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                  <Label htmlFor={`unit-${index}`}>Unit</Label>
                  <Select
                  value={item.unit}
                  onValueChange={(value) => updateFoodItem(index, "unit", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="grams">grams</SelectItem>
                      <SelectItem value="servings">servings</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            {item.name &&
          <div className="text-sm text-gray-600 bg-gray-50 p-2 rounded" data-id="l9kevvuxe" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                <p data-id="1aewumwl7" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Per 100g: {item.calories} calories, {item.protein}g protein, {item.carbs}g carbs, {item.fat}g fat</p>
              </div>
          }
          </div>
        )}
        
        <Button
          variant="outline"
          onClick={addFoodItem}
          className="w-full">

          + Add Another Food
        </Button>
        
        <div className="flex gap-3" data-id="toq31mmmz" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
          <Button
            onClick={calculateNutrition}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
            Calculate Nutrition
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>
            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="rvkdk9gvl" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            {error}
          </div>
        }

        {totalNutrition.calories > 0 && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="space-y-5" data-id="kt98wslcp" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                <div data-id="ocvacdfk8" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                  <p className="text-lg font-medium" data-id="1zwaqjbi0" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Total Nutrition</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="ck1nd3ele" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                    {totalNutrition.calories} calories
                  </p>
                </div>
                
                <div className="mt-4 border-t pt-4" data-id="mvgk2ekno" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                  <p className="text-lg font-medium mb-3" data-id="ylefg5cnb" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Macronutrient Breakdown</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="cnquzl58c" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                    <div className="bg-blue-50 p-3 rounded-lg" data-id="yvrnggzba" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                      <p className="font-medium" data-id="rz7wrdp8r" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Protein</p>
                      <p className="text-xl font-bold text-blue-700" data-id="0wcdbl1vh" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                        {totalNutrition.protein}g
                      </p>
                      <p className="text-sm text-gray-600" data-id="5qjri02yv" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                        {Math.round(totalNutrition.protein * 4)} calories ({Math.round(totalNutrition.protein * 4 / totalNutrition.calories * 100)}%)
                      </p>
                    </div>
                    <div className="bg-teal-50 p-3 rounded-lg" data-id="33p94djon" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                      <p className="font-medium" data-id="vm9mess4a" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Carbohydrates</p>
                      <p className="text-xl font-bold text-teal-700" data-id="0goldm00y" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                        {totalNutrition.carbs}g
                      </p>
                      <p className="text-sm text-gray-600" data-id="1za8dtdoi" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                        {Math.round(totalNutrition.carbs * 4)} calories ({Math.round(totalNutrition.carbs * 4 / totalNutrition.calories * 100)}%)
                      </p>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg" data-id="989hjesml" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                      <p className="font-medium" data-id="rszg2puoc" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Fat</p>
                      <p className="text-xl font-bold text-indigo-700" data-id="kl9ky3r66" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                        {totalNutrition.fat}g
                      </p>
                      <p className="text-sm text-gray-600" data-id="mcqsoajoz" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                        {Math.round(totalNutrition.fat * 9)} calories ({Math.round(totalNutrition.fat * 9 / totalNutrition.calories * 100)}%)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 border-t pt-4" data-id="ncyozry98" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="pgedmyr7o" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Nutrition Summary</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="v4ien72ze" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                    <p className="mb-2" data-id="qmir9hy1q" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                      This meal/food combination provides {totalNutrition.calories} calories with a macronutrient ratio of approximately {Math.round(totalNutrition.protein * 4 / totalNutrition.calories * 100)}% protein, {Math.round(totalNutrition.carbs * 4 / totalNutrition.calories * 100)}% carbohydrates, and {Math.round(totalNutrition.fat * 9 / totalNutrition.calories * 100)}% fat.
                    </p>
                    <p className="mt-3 text-sm italic" data-id="l0143q7xu" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                      Note: All calculations are estimates based on average nutritional values. Actual content may vary by brand, preparation method, and serving size.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="kor3klvbr" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="9cy66jti8" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">About Food Calories and Macronutrients</h3>
          <p className="mb-4" data-id="janhgn6ts" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            Understanding the calorie and macronutrient content of your food helps you make informed decisions about your diet. Calories provide a measure of energy content, while macronutrients (protein, carbohydrates, and fat) provide different benefits:
          </p>
          
          <ul className="list-disc pl-6 space-y-2" data-id="erzo5il6q" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            <li data-id="wjre79skz" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="q984i5uzb" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Protein (4 calories per gram):</strong> Essential for muscle repair and growth, immune function, and enzyme production.</li>
            <li data-id="n0zo5oodt" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="u21utpu24" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Carbohydrates (4 calories per gram):</strong> Your body's primary energy source, especially for high-intensity activities and brain function.</li>
            <li data-id="u0plu0iw0" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="u8cj8iwrv" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Fat (9 calories per gram):</strong> Provides concentrated energy, supports cell structure, hormone production, and helps absorb fat-soluble vitamins.</li>
          </ul>
          
          <p className="mt-4 mb-4" data-id="exk68zs14" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            This calculator provides estimates based on standard nutritional data. For the most accurate information, refer to nutrition labels on packaged foods or consult comprehensive nutritional databases.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="g0fny9jld" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="q81lv2j3n" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Understanding Food Calories</h2>
          
          <p className="mb-4" data-id="6wrpk9wr1" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            In nutrition, a calorie is a unit of energy. Specifically, the calories listed on food labels are actually kilocalories (kcal), which represent the amount of energy needed to raise the temperature of one kilogram of water by one degree Celsius. This energy measurement helps us understand how much fuel our foods provide to power bodily functions and physical activities.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="3iz8wh4qa" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="jwj63skd6" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="tbar0hvov" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Calories in Macronutrients</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="s3mugeanw" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                <li data-id="unwirmsmq" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="fs48bhwpa" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Carbohydrates:</strong> 4 calories per gram</li>
                <li data-id="xlepa3cov" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="4nmkrwlxo" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Proteins:</strong> 4 calories per gram</li>
                <li data-id="2pbou1uug" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="5pdqtzy95" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Fats:</strong> 9 calories per gram</li>
                <li data-id="rqz88fzik" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="v4180uqd8" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Alcohol:</strong> 7 calories per gram</li>
                <li data-id="1sklei8w2" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="76ep3llsm" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Fiber:</strong> 2 calories per gram (often listed under carbohydrates)</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="f0famck7n" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="28u6txkgr" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Calories vs. Nutrition</h3>
              <p className="mb-2" data-id="9zqf25n4x" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Calories tell us about energy content, but not nutritional value. Two foods with identical calorie counts can differ in:</p>
              <ul className="list-disc pl-5 space-y-1" data-id="kwi9xmfw2" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
                <li data-id="0gkpzpyzn" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Vitamin and mineral content</li>
                <li data-id="65g98yzp4" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Fiber content</li>
                <li data-id="dmqxlhf4t" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Protein quality</li>
                <li data-id="exyjz682c" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Fat quality (types of fatty acids)</li>
                <li data-id="z442kvhx3" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Antioxidants and phytonutrients</li>
                <li data-id="ehm81yaqd" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Processing level and additives</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="tddluzff6" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Understanding Calorie Density</h3>
          <p className="mb-4" data-id="ivh81v9el" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            Calorie density (calories per gram of food) significantly impacts satiety and total calorie intake. Foods can be categorized based on their calorie density:
          </p>
          
          <div className="space-y-4 mb-6" data-id="p32zu9tt1" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="fo1djieil" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h4 className="font-medium" data-id="843pcqii5" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Very Low Calorie Density (0-0.6 calories per gram)</h4>
              <p className="mb-1" data-id="04vvt48pq" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Examples: Lettuce, strawberries, broccoli, most non-starchy vegetables</p>
              <p className="text-sm text-gray-600" data-id="mfvofj3o9" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">These foods allow large portions with minimal calories, helping with satiety.</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="ynaxp906f" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h4 className="font-medium" data-id="b8l30va6d" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Low Calorie Density (0.6-1.5 calories per gram)</h4>
              <p className="mb-1" data-id="kvendzs0o" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Examples: Potatoes, non-fat yogurt, beans, most fruits</p>
              <p className="text-sm text-gray-600" data-id="qv0oeb10l" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">These foods provide more calories but still offer good volume per calorie.</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="ruw0c4t9d" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h4 className="font-medium" data-id="7p35w0px2" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Medium Calorie Density (1.5-4.0 calories per gram)</h4>
              <p className="mb-1" data-id="mpori1ap5" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Examples: Chicken breast, eggs, whole grain bread, hummus</p>
              <p className="text-sm text-gray-600" data-id="e5vkowwsl" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">These foods provide substantial nutrition with moderate energy content.</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="vjs7fpdg8" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h4 className="font-medium" data-id="x5erbtd6c" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">High Calorie Density (4.0-9.0 calories per gram)</h4>
              <p className="mb-1" data-id="ieh52fbrt" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Examples: Nuts, oils, butter, chocolate, chips</p>
              <p className="text-sm text-gray-600" data-id="iie1gq56x" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">These foods provide substantial calories in small volumes, making portion control important.</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="fnaaggb7i" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Reading Food Labels for Calorie Information</h3>
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="nvzex02ox" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            <li data-id="y3yhkxziz" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="b474sosds" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Check serving size:</strong> All nutrition information is based on this amount</li>
            <li data-id="d2o2ysd71" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="8kltj9fct" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Note servings per container:</strong> Many packages contain multiple servings</li>
            <li data-id="ifpu5hk8a" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="jr44hvpar" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Review calories per serving:</strong> The total energy in one serving</li>
            <li data-id="lta7l57wp" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="18lgm1e8s" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Examine macronutrient breakdown:</strong> How calories are distributed among carbs, protein, and fat</li>
            <li data-id="l4cpfmldi" data-path="src/pages/calculators/FoodCalorieCalculator.tsx"><strong data-id="mw7j7tdyn" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Watch for rounding:</strong> By law, manufacturers can round calorie values, which can be misleading for small servings</li>
          </ul>
          
          <h3 className="text-xl font-semibold mb-3" data-id="sw9l6jlgx" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Using Calorie Information for Weight Management</h3>
          <div className="space-y-4 mb-6" data-id="aw0uuy0bz" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            <div className="border-l-4 border-primary pl-4 py-1" data-id="25x0t0klc" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h4 className="font-medium" data-id="cjf3vgv2m" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">For Weight Maintenance</h4>
              <p className="text-sm" data-id="md5cv6i85" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Aim to consume approximately the same number of calories as your Total Daily Energy Expenditure (TDEE).</p>
            </div>
            
            <div className="border-l-4 border-primary pl-4 py-1" data-id="zu5uwtzco" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h4 className="font-medium" data-id="u394rhdv4" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">For Weight Loss</h4>
              <p className="text-sm" data-id="goe4vty2x" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Create a moderate calorie deficit (typically 15-25% below TDEE or about 500 calories/day for 1 pound per week).</p>
            </div>
            
            <div className="border-l-4 border-primary pl-4 py-1" data-id="wd3cwq14b" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              <h4 className="font-medium" data-id="jg7xhdxq8" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">For Weight Gain</h4>
              <p className="text-sm" data-id="mouikicuu" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Create a moderate calorie surplus (typically 10-20% above TDEE) and combine with strength training for muscle gain.</p>
            </div>
          </div>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="st2dhmvji" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="esle40uvi" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">Learn More About Food Calories</h3>
            <p className="mb-3" data-id="xlo2v6ddl" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
              For an in-depth understanding of calories, calorie density, measurement methods, and using calorie information for effective weight management, check out our comprehensive guide:
            </p>
            <Link
            to="/blog/food-calorie-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete Food Calorie Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="z3b9bh592" data-path="src/pages/calculators/FoodCalorieCalculator.tsx">
            Remember that while counting calories can be helpful for weight management, focusing on food quality, nutrient density, and sustainable eating patterns is equally important for long-term health and success.
          </p>
        </div>
    </CalculatorLayout>);

};

export default FoodCalorieCalculator;