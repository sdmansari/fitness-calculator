import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Link } from "react-router-dom";

const ProteinIntakeCalculator = () => {
  const [unit, setUnit] = useState("metric");
  const [weight, setWeight] = useState("");
  const [lbs, setLbs] = useState("");
  const [activityLevel, setActivityLevel] = useState("sedentary");
  const [goal, setGoal] = useState("maintain");
  const [proteinResults, setProteinResults] = useState<{
    minimum: number;
    recommended: number;
    maximum: number;
    perMeal: number;
  } | null>(null);
  const [error, setError] = useState("");

  const calculateProteinIntake = () => {
    setError("");

    try {
      let weightInKg: number;

      if (unit === "metric") {
        weightInKg = parseFloat(weight);

        if (isNaN(weightInKg) || weightInKg <= 0) {
          throw new Error("Please enter a valid weight value");
        }
      } else {
        const lbsValue = parseFloat(lbs);

        if (isNaN(lbsValue) || lbsValue <= 0) {
          throw new Error("Please enter a valid weight value");
        }

        weightInKg = lbsValue * 0.453592;
      }

      // Protein multipliers (g/kg of body weight)
      let minimumMultiplier = 0.8; // RDA minimum
      let recommendedMultiplier = 0;
      let maximumMultiplier = 0;

      // Set multipliers based on activity level and goal
      if (activityLevel === "sedentary") {
        if (goal === "lose") {
          recommendedMultiplier = 1.2;
          maximumMultiplier = 1.5;
        } else if (goal === "maintain") {
          recommendedMultiplier = 0.8;
          maximumMultiplier = 1.0;
        } else if (goal === "gain") {
          recommendedMultiplier = 1.0;
          maximumMultiplier = 1.2;
        }
      } else if (activityLevel === "moderate") {
        if (goal === "lose") {
          recommendedMultiplier = 1.5;
          maximumMultiplier = 1.8;
        } else if (goal === "maintain") {
          recommendedMultiplier = 1.2;
          maximumMultiplier = 1.4;
        } else if (goal === "gain") {
          recommendedMultiplier = 1.4;
          maximumMultiplier = 1.6;
        }
      } else if (activityLevel === "active") {
        if (goal === "lose") {
          recommendedMultiplier = 1.6;
          maximumMultiplier = 2.0;
        } else if (goal === "maintain") {
          recommendedMultiplier = 1.4;
          maximumMultiplier = 1.6;
        } else if (goal === "gain") {
          recommendedMultiplier = 1.6;
          maximumMultiplier = 2.0;
        }
      } else if (activityLevel === "athlete") {
        if (goal === "lose") {
          recommendedMultiplier = 1.8;
          maximumMultiplier = 2.2;
        } else if (goal === "maintain") {
          recommendedMultiplier = 1.6;
          maximumMultiplier = 1.8;
        } else if (goal === "gain") {
          recommendedMultiplier = 1.8;
          maximumMultiplier = 2.4;
        }
      }

      // Calculate protein needs
      const minimum = Math.round(weightInKg * minimumMultiplier);
      const recommended = Math.round(weightInKg * recommendedMultiplier);
      const maximum = Math.round(weightInKg * maximumMultiplier);
      const perMeal = Math.round(recommended / 4); // Assuming 4 meals per day

      setProteinResults({
        minimum,
        recommended,
        maximum,
        perMeal
      });
    } catch (err: any) {
      setError(err.message || "An error occurred during calculation");
      setProteinResults(null);
    }
  };

  const resetCalculator = () => {
    setWeight("");
    setLbs("");
    setProteinResults(null);
    setError("");
  };

  const getActivityLevelDescription = (level: string) => {
    switch (level) {
      case "sedentary":
        return "Little to no exercise";
      case "moderate":
        return "Light exercise 1-3 days/week";
      case "active":
        return "Moderate exercise 3-5 days/week";
      case "athlete":
        return "Hard exercise 6-7 days/week";
      default:
        return "";
    }
  };

  const getGoalDescription = (goalType: string) => {
    switch (goalType) {
      case "lose":
        return "Weight loss";
      case "maintain":
        return "Maintain weight";
      case "gain":
        return "Muscle gain";
      default:
        return "";
    }
  };

  return (
    <CalculatorLayout
      title="Protein Intake Calculator"
      description="Calculate your recommended daily protein intake based on your weight, activity level, and fitness goals."
      icon={
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="88osy93zc" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" data-id="oyk61vasx" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx" />
        </svg>
      }>

      <div className="space-y-6" data-id="wzamkumur" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
        <div data-id="9mvi27z47" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <Label className="text-lg font-medium">Unit System</Label>
          <RadioGroup
            value={unit}
            onValueChange={setUnit}
            className="flex gap-6 mt-2">

            <div className="flex items-center space-x-2" data-id="eq47fwyhv" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <RadioGroupItem value="metric" id="metric" />
              <Label htmlFor="metric">Metric (kg)</Label>
            </div>
            <div className="flex items-center space-x-2" data-id="2ons52kxz" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <RadioGroupItem value="imperial" id="imperial" />
              <Label htmlFor="imperial">Imperial (lbs)</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        <div className="space-y-4" data-id="lb2wujjyz" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <div className="space-y-2" data-id="lgvwkl2qz" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <Label htmlFor={unit === "metric" ? "weight" : "lbs"}>
              Weight {unit === "metric" ? "(kg)" : "(lbs)"}
            </Label>
            <Input
              id={unit === "metric" ? "weight" : "lbs"}
              type="number"
              placeholder={unit === "metric" ? "e.g., 70" : "e.g., 154"}
              value={unit === "metric" ? weight : lbs}
              onChange={(e) => unit === "metric" ? setWeight(e.target.value) : setLbs(e.target.value)} />

          </div>
        </div>

        <Separator />

        <div className="space-y-4" data-id="se15osmdt" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <div className="space-y-2" data-id="x8lpnmtag" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <Label htmlFor="activityLevel">Activity Level</Label>
            <Select
              value={activityLevel}
              onValueChange={setActivityLevel}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select activity level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sedentary">Sedentary (Little to no exercise)</SelectItem>
                <SelectItem value="moderate">Lightly Active (Light exercise 1-3 days/week)</SelectItem>
                <SelectItem value="active">Active (Moderate exercise 3-5 days/week)</SelectItem>
                <SelectItem value="athlete">Very Active (Hard exercise 6-7 days/week)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4" data-id="uble7bs2v" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <div className="space-y-2" data-id="0wxjduwaz" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <Label htmlFor="goal">Fitness Goal</Label>
            <Select
              value={goal}
              onValueChange={setGoal}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select your goal" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="lose">Weight Loss</SelectItem>
                <SelectItem value="maintain">Maintain Weight</SelectItem>
                <SelectItem value="gain">Muscle Gain</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-3" data-id="q5djx2n8t" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <Button
            onClick={calculateProteinIntake}
            className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
            Calculate Protein Needs
          </Button>
          <Button
            variant="outline"
            onClick={resetCalculator}>
            Reset
          </Button>
        </div>

        {error &&
        <div className="bg-red-50 text-red-600 p-3 rounded-md" data-id="7rlq0dvgx" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            {error}
          </div>
        }

        {proteinResults !== null && !error &&
        <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="space-y-5" data-id="fr69gbhna" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                <div data-id="y9dx0mdw4" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                  <p className="text-lg font-medium" data-id="czvzwfxno" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Your Daily Protein Recommendation</p>
                  <p className="text-5xl font-bold text-blue-600" data-id="skn4h33tt" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                    {proteinResults.recommended} grams
                  </p>
                  <p className="text-gray-600 mt-2" data-id="oegtxdaf1" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                    Based on your weight, {getActivityLevelDescription(activityLevel).toLowerCase()}, and goal to {getGoalDescription(goal).toLowerCase()}
                  </p>
                </div>
                
                <div className="mt-4 border-t pt-4" data-id="lkz6butoe" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                  <p className="text-lg font-medium mb-3" data-id="d8o41mm0l" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Protein Range</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="jchexjcg4" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                    <div className="bg-blue-50 p-3 rounded-lg" data-id="ygi6b3jum" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                      <p className="font-medium" data-id="eczlina6u" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Minimum</p>
                      <p className="text-xl font-bold text-blue-700" data-id="52cfa5kbi" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                        {proteinResults.minimum} g
                      </p>
                      <p className="text-sm text-gray-600" data-id="enjo5unhi" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">RDA minimum</p>
                    </div>
                    <div className="bg-teal-50 p-3 rounded-lg" data-id="7vrd9rho4" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                      <p className="font-medium" data-id="qrnr7115y" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Recommended</p>
                      <p className="text-xl font-bold text-teal-700" data-id="rptplof0b" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                        {proteinResults.recommended} g
                      </p>
                      <p className="text-sm text-gray-600" data-id="b3dlmge51" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Optimal intake</p>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg" data-id="af1hcycsx" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                      <p className="font-medium" data-id="9kzwccagh" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Maximum</p>
                      <p className="text-xl font-bold text-indigo-700" data-id="4s35s6q44" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                        {proteinResults.maximum} g
                      </p>
                      <p className="text-sm text-gray-600" data-id="95iswfi5x" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Upper target</p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 border-t pt-4" data-id="2c1dq8xps" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                  <p className="text-lg font-medium mb-2" data-id="45o5myn6l" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Distribution Tips</p>
                  <div className="text-left p-4 bg-blue-50 rounded-lg" data-id="xb4jkmya3" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                    <p className="mb-3" data-id="in8onx5q9" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                      <strong data-id="damngvfmg" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Per Meal Recommendation:</strong> Approximately <span className="font-bold" data-id="ow2ip07w6" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">{proteinResults.perMeal} grams</span> per meal (assuming 4 meals/day)
                    </p>
                    <p className="mb-3" data-id="0s9uieg2d" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Protein sources with approximately 20-25g protein:</p>
                    <ul className="list-disc pl-6 space-y-1 mb-3" data-id="huva22xio" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                      <li data-id="mjbwbdl3z" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">3 oz (85g) of chicken breast</li>
                      <li data-id="z57uchdfg" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">4 oz (113g) of lean beef or fish</li>
                      <li data-id="hjcmuyrsr" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1 cup of Greek yogurt</li>
                      <li data-id="8iweqzyb7" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">4 eggs</li>
                      <li data-id="utyakj8e5" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1 scoop of most protein powders</li>
                      <li data-id="qs1dfjzct" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1 cup of lentils or beans + 1/2 cup quinoa</li>
                    </ul>
                    <p className="mt-3 text-sm italic" data-id="zguyqqdun" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                      Disclaimer: This calculation provides a general recommendation. Individual protein needs may vary based on age, medical conditions, and specific training programs. Consult with a healthcare provider or registered dietitian for personalized advice.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="mt-6 text-gray-700" data-id="7jddd4xmo" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <h3 className="text-lg font-semibold mb-2" data-id="nu5b94w00" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">About Protein Intake</h3>
          <p className="mb-4" data-id="zdse7peso" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            Protein is an essential macronutrient that plays a critical role in building and repairing tissues, making enzymes and hormones, and supporting immune function. Your optimal protein intake depends on several factors including your weight, activity level, and fitness goals.
          </p>
          
          <h3 className="text-lg font-semibold mb-2" data-id="p8y3lyu5o" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Why Protein Matters:</h3>
          <ul className="list-disc pl-6 space-y-1" data-id="g9wf9vgig" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <li data-id="mc5nxm6vg" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="pdltba3ui" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Muscle Maintenance and Growth:</strong> Protein provides the building blocks (amino acids) necessary for muscle repair and growth.</li>
            <li data-id="xg4fnnbvy" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="3qgr7cw1w" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Satiety and Weight Management:</strong> Protein helps you feel full longer, which may help with weight management.</li>
            <li data-id="yy24jwqle" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="cbf63q4bj" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Metabolic Health:</strong> A higher protein intake can boost metabolism and increase calories burned.</li>
            <li data-id="iyp5ybdrw" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="bo7yr1hfh" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Recovery:</strong> Adequate protein supports recovery from exercise and injury.</li>
          </ul>
          
          <p className="mt-4 mb-4" data-id="m15tueq12" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            The Recommended Dietary Allowance (RDA) for protein is 0.8 grams per kilogram of body weight for the average sedentary adult. However, this is the minimum to prevent deficiency, not necessarily the optimal amount for health, performance, or body composition goals. Athletes and highly active individuals typically need significantly more protein to support their activity levels and recovery needs.
          </p>
        </div>
      </div>
    <div className="mt-8 border-t pt-6" data-id="a7qdtx4zi" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
          <h2 className="text-2xl font-bold mb-4" data-id="nndvzpcb3" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Understanding Protein Requirements</h2>
          
          <p className="mb-4" data-id="yyyz3cvoo" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            Protein is an essential macronutrient composed of amino acids—the fundamental building blocks for virtually all structures and functions in the body. Beyond just building muscle, protein plays critical roles in enzyme production, immune function, tissue repair, and hormone regulation.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" data-id="c4uu65n22" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <div className="bg-blue-50 p-4 rounded-lg" data-id="2dzq1niw4" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="xtc05j4zk" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Benefits of Optimal Protein Intake</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="q9j6s6rig" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                <li data-id="s8qcackdm" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Preserves and builds lean muscle mass</li>
                <li data-id="2ztm366ks" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Increases metabolism and fat burning</li>
                <li data-id="4gjntr9i0" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Improves recovery from exercise and injury</li>
                <li data-id="s6y5j4kvd" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Reduces hunger and supports weight management</li>
                <li data-id="5p09gqbwd" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Stabilizes blood sugar levels</li>
                <li data-id="tbynyvria" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Supports immune system function</li>
                <li data-id="pus30cehr" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Helps maintain bone density</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg" data-id="ar4o41hi2" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h3 className="text-lg font-semibold mb-2" data-id="ga8t8jg9w" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Factors Affecting Protein Needs</h3>
              <ul className="list-disc pl-5 space-y-1" data-id="aqfr5nycq" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                <li data-id="hh7msfxnf" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="mkmnyfwqx" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Activity level:</strong> More activity requires more protein</li>
                <li data-id="9odgjoozs" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="vq16591b4" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Exercise type:</strong> Resistance training increases needs</li>
                <li data-id="40pg9mol2" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="tbbw8plpe" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Body composition goals:</strong> Building muscle or losing fat</li>
                <li data-id="xc412b7an" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="kr85ku7fq" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Age:</strong> Needs increase with age to prevent muscle loss</li>
                <li data-id="ted56gnmr" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="w9c1vxv3s" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Current body weight:</strong> Heavier individuals need more</li>
                <li data-id="4k3wwbtht" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="5jkvwpw7e" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Caloric intake:</strong> Calorie deficits increase protein needs</li>
                <li data-id="eovzdmaer" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="dvzsahjmq" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Diet quality:</strong> Protein source and completeness matters</li>
              </ul>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="oyq08fpak" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Protein Recommendations by Goal</h3>
          <div className="space-y-4 mb-6" data-id="rlc0ehed8" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <div className="border p-4 rounded-md" data-id="a0e78ktmp" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium" data-id="okab80297" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">General Health Maintenance</h4>
              <p className="mb-2" data-id="zi2v0srxo" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">For maintaining general health with minimal physical activity:</p>
              <p className="font-mono text-sm" data-id="v721wzami" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">0.8-1.0g per kg of body weight daily</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="zxl5uijco" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium" data-id="7u49lipi7" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Active Individuals</h4>
              <p className="mb-2" data-id="87ivd5mym" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">For those who exercise regularly with moderate intensity:</p>
              <p className="font-mono text-sm" data-id="ef5iqtl8y" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1.1-1.4g per kg of body weight daily</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="dp4w2u2dd" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium" data-id="pwyuhu7jz" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Building Muscle</h4>
              <p className="mb-2" data-id="cz8jvmprc" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">For those focusing on muscle growth with resistance training:</p>
              <p className="font-mono text-sm" data-id="lhgkqye4a" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1.6-2.2g per kg of body weight daily</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="gwe4kaqc3" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium" data-id="dxxv04v01" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Fat Loss While Preserving Muscle</h4>
              <p className="mb-2" data-id="ouyoxepbw" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">For those in a caloric deficit trying to maintain muscle mass:</p>
              <p className="font-mono text-sm" data-id="3t52f3qdc" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1.8-2.4g per kg of body weight daily</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="v9ichbnu9" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium" data-id="quk353uc1" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Endurance Athletes</h4>
              <p className="mb-2" data-id="atrnkigx1" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">For those engaging in regular endurance training:</p>
              <p className="font-mono text-sm" data-id="2ip3covxj" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1.4-1.8g per kg of body weight daily</p>
            </div>
            
            <div className="border p-4 rounded-md" data-id="bdqv5cl5e" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium" data-id="uk9fsxbc8" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Older Adults (65+)</h4>
              <p className="mb-2" data-id="3n2ep37ey" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">For maintaining muscle mass with aging:</p>
              <p className="font-mono text-sm" data-id="fxbtzmv97" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">1.2-1.6g per kg of body weight daily</p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3" data-id="4jku5xkk5" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Optimal Protein Timing and Distribution</h3>
          <ul className="list-disc pl-6 space-y-2 mb-6" data-id="w902erqbx" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <li data-id="cqmei7mzy" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="9pan66h1y" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Spread protein intake throughout the day</strong> in 3-5 meals/snacks</li>
            <li data-id="58upwcep4" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="jl0t4uv89" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Aim for 20-40g of protein per meal</strong> (depending on body size and goals)</li>
            <li data-id="p88ftc9xe" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="tp43xrtps" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Include protein in post-workout nutrition</strong> within 2 hours of exercise</li>
            <li data-id="ww087bdia" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx"><strong data-id="y73xi6fza" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Consider pre-sleep protein</strong> (30-40g) to support overnight recovery</li>
          </ul>
          
          <h3 className="text-xl font-semibold mb-3" data-id="c0ar5ylba" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">High-Quality Protein Sources</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6" data-id="ikn8szkxs" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <div data-id="35jjq324u" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium mb-2" data-id="btq08u8w0" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Animal-Based (per 100g)</h4>
              <ul className="list-disc pl-6 space-y-1" data-id="x86jmn756" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                <li data-id="n0t546kxw" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Chicken breast: 31g protein</li>
                <li data-id="aygyt7qy6" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Turkey breast: 29g protein</li>
                <li data-id="xr8c5u9yn" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Lean beef: 26-29g protein</li>
                <li data-id="yncnqxu63" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Fish (salmon, tuna): 22-25g protein</li>
                <li data-id="gfeydmbrv" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Greek yogurt: 10g protein</li>
                <li data-id="d1vd74jh8" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Eggs: 6g protein per large egg</li>
                <li data-id="xof6dxgki" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Whey protein powder: ~24g per 30g scoop</li>
              </ul>
            </div>
            <div data-id="a24nbpdsh" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              <h4 className="font-medium mb-2" data-id="uz4ep3pyr" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Plant-Based (per 100g)</h4>
              <ul className="list-disc pl-6 space-y-1" data-id="vlqaqz9zb" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
                <li data-id="c8s0zdptq" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Tofu (firm): 17g protein</li>
                <li data-id="qi52pcn79" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Tempeh: 19g protein</li>
                <li data-id="1y7klwvql" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Seitan: 25g protein</li>
                <li data-id="vwe8ph4h6" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Lentils (cooked): 9g protein</li>
                <li data-id="o1kc2ppha" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Black beans (cooked): 8.9g protein</li>
                <li data-id="ef5gp14ry" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Chickpeas (cooked): 8.9g protein</li>
                <li data-id="niurr6z2t" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Pea protein powder: ~24g per 30g scoop</li>
              </ul>
            </div>
          </div>
          
          <div className="bg-primary/10 p-5 rounded-lg mb-6" data-id="lyw6jn00i" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            <h3 className="text-lg font-semibold mb-2" data-id="klvfy7her" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">Learn More About Protein Intake</h3>
            <p className="mb-3" data-id="hfogzlqqt" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
              For an in-depth understanding of protein's role in the body, optimal amounts for different goals, protein quality, and practical strategies for meeting your needs, check out our comprehensive guide:
            </p>
            <Link
            to="/blog/protein-guide"
            className="inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition">

              Read our Complete Protein Guide
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 italic" data-id="qdu9vh1rb" data-path="src/pages/calculators/ProteinIntakeCalculator.tsx">
            Remember that these recommendations provide general guidelines. Individual protein needs may vary based on specific health conditions, metabolic factors, and training specifics. Those with kidney disease or certain other medical conditions should consult healthcare providers before significantly increasing protein intake.
          </p>
        </div>
    </CalculatorLayout>);

};

export default ProteinIntakeCalculator;