import React from 'react';
import Layout from '@/components/Layout/Layout';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import MetaTags from '@/components/SEO/MetaTags';

export default function BlogPage() {
  return (
    <>
      <MetaTags
        title="Health & Fitness Resources | Fitness Calculator Hub"
        description="Explore our comprehensive collection of health and fitness articles, guides and resources to help you make informed decisions about your wellness journey."
        keywords="fitness calculator, health resources, BMI guide, BMR calculator, TDEE calculation, body fat percentage, protein intake, macro calculator, weight management, nutrition guide"
        canonicalUrl="https://fitnesscalculatorhub.com/blog"
        structuredData={{
          '@context': 'https://schema.org',
          '@type': 'Blog',
          'name': 'Fitness Calculator Hub Blog',
          'description': 'Medically reviewed health and fitness resources to help you make informed decisions about your wellness journey.',
          'url': 'https://fitcalchub.com/blog',
          'publisher': {
            '@type': 'Organization',
            'name': 'Fitness Calculator Hub',
            'logo': {
              '@type': 'ImageObject',
              'url': 'https://fitcalchub.com/images/medical-logo.svg'
            }
          }
        }} />

    <Layout>
      <div className="container mx-auto py-8 px-4" data-id="2hcslmp0n" data-path="src/pages/BlogPage.tsx">
        <h1 className="text-4xl font-bold text-center mb-6" data-id="pi88wd0mi" data-path="src/pages/BlogPage.tsx">Health & Fitness Resources</h1>
        <p className="text-lg text-center mb-8" data-id="2eqk4nd64" data-path="src/pages/BlogPage.tsx">
          Medically reviewed, comprehensive guides to help you understand our calculators and make informed health decisions.
        </p>
        
        <div className="flex justify-center mb-8" data-id="1pd3mn2ab" data-path="src/pages/BlogPage.tsx">
          <div className="inline-flex items-center bg-blue-50 text-blue-700 px-4 py-2 rounded-lg gap-2" data-id="afj5sl8u4" data-path="src/pages/BlogPage.tsx">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="text-blue-500" data-id="xmsszr0jd" data-path="src/pages/BlogPage.tsx">
              <path d="M19 14a1 1 0 0 0-1-1H8.5a1 1 0 0 0-1 1v.5a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2V14z" data-id="qhxwtnu9h" data-path="src/pages/BlogPage.tsx"></path>
              <path d="M18 11V6a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2v-4" data-id="ekd247vr5" data-path="src/pages/BlogPage.tsx"></path>
              <path d="M10 3v3" data-id="qit5r4r43" data-path="src/pages/BlogPage.tsx"></path>
              <path d="M14 3v3" data-id="y0cf3cvsr" data-path="src/pages/BlogPage.tsx"></path>
            </svg>
            <span data-id="hjk3el5f9" data-path="src/pages/BlogPage.tsx">All content medically reviewed by healthcare professionals</span>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-id="tc5yp7xb8" data-path="src/pages/BlogPage.tsx">
          {/* Weight Management Articles */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Complete Guide to BMI Calculation</CardTitle>
              <CardDescription>Understanding your Body Mass Index and what it means for your health</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="748koaks7" data-path="src/pages/BlogPage.tsx">Learn how BMI is calculated, its limitations, and how to interpret your results accurately.</p>
              <Link to="/blog/bmi-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Mastering Your Metabolism with BMR</CardTitle>
              <CardDescription>How Basal Metabolic Rate affects your energy needs</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="jltmy00y0" data-path="src/pages/BlogPage.tsx">Discover how your body burns calories at rest and why knowing your BMR is essential for weight management.</p>
              <Link to="/blog/bmr-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>TDEE: The Key to Energy Balance</CardTitle>
              <CardDescription>Total Daily Energy Expenditure explained</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="j313b5a4f" data-path="src/pages/BlogPage.tsx">Learn how activity levels affect your daily calorie needs and how to use TDEE for effective weight management.</p>
              <Link to="/blog/tdee-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          {/* Body Composition Articles */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Body Fat Percentage: Beyond the Scale</CardTitle>
              <CardDescription>Why body composition matters more than weight</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="4leptfgqs" data-path="src/pages/BlogPage.tsx">Understand how body fat percentage provides deeper insights into your health than weight alone.</p>
              <Link to="/blog/body-fat-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>The Science of Ideal Weight</CardTitle>
              <CardDescription>Finding your healthy weight range based on evidence</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="8htzyssuo" data-path="src/pages/BlogPage.tsx">Learn about different ideal weight formulas and how to set realistic, personalized weight goals.</p>
              <Link to="/blog/ideal-weight-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Lean Body Mass: Your Metabolic Engine</CardTitle>
              <CardDescription>The importance of muscle in health and metabolism</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="3zt9eyw64" data-path="src/pages/BlogPage.tsx">Discover why maintaining muscle mass is crucial for long-term health and metabolic function.</p>
              <Link to="/blog/lean-body-mass-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          {/* Nutrition Articles */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Protein Intake: Building Blocks for Health</CardTitle>
              <CardDescription>How to optimize your protein consumption</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="0iwr9or8p" data-path="src/pages/BlogPage.tsx">Learn about protein requirements for different goals and how to calculate your optimal intake.</p>
              <Link to="/blog/protein-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Macro Nutrients: Finding Your Perfect Balance</CardTitle>
              <CardDescription>How to distribute carbs, proteins, and fats</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="nqoyo7pd0" data-path="src/pages/BlogPage.tsx">Understand how to calculate and adjust your macronutrient ratios for optimal health and performance.</p>
              <Link to="/blog/macro-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Calcium Requirements Through Life</CardTitle>
              <CardDescription>Age-specific calcium needs for optimal bone health</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="2q02so6wr" data-path="src/pages/BlogPage.tsx">Explore how calcium requirements change throughout different life stages and how to meet your needs.</p>
              <Link to="/blog/calcium-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Understanding Food Calories</CardTitle>
              <CardDescription>Making informed decisions about energy intake</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-id="b865s1zgs" data-path="src/pages/BlogPage.tsx">Learn how to accurately track food calories, understand calorie density, and make smarter food choices for effective weight management.</p>
              <Link to="/blog/food-calorie-guide" className="text-primary font-medium hover:underline">
                Read more →
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
    </>);

}