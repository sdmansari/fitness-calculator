import Layout from "@/components/Layout/Layout";
import { Separator } from "@/components/ui/separator";

const PrivacyPolicyPage = () => {
  return (
    <Layout>
      <div className="container mx-auto py-12 px-4" data-id="8fzjg7kdk" data-path="src/pages/PrivacyPolicyPage.tsx">
        <div className="max-w-4xl mx-auto" data-id="lxgy4cqvf" data-path="src/pages/PrivacyPolicyPage.tsx">
          <div className="text-center mb-12" data-id="c3qiimkps" data-path="src/pages/PrivacyPolicyPage.tsx">
            <h1 className="text-4xl font-bold mb-4" data-id="fjeg0ql2f" data-path="src/pages/PrivacyPolicyPage.tsx">Privacy Policy</h1>
            <p className="text-gray-600" data-id="03mnckkzb" data-path="src/pages/PrivacyPolicyPage.tsx">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-blue max-w-none" data-id="ocfngnion" data-path="src/pages/PrivacyPolicyPage.tsx">
            <p className="text-lg mb-6" data-id="2ewnf9vrm" data-path="src/pages/PrivacyPolicyPage.tsx">
              At Fitness Calculator Hub, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.
            </p>

            <Separator className="my-8" />

            <section className="mb-8" data-id="ckn9ji9i5" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="xxa1bmd8m" data-path="src/pages/PrivacyPolicyPage.tsx">Information We Collect</h2>
              <p className="mb-4" data-id="juws18cdj" data-path="src/pages/PrivacyPolicyPage.tsx">
                <strong data-id="lz1nvbev6" data-path="src/pages/PrivacyPolicyPage.tsx">Personal Data:</strong> While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you ("Personal Data"). This may include, but is not limited to:
              </p>
              <ul className="list-disc pl-6 mb-4 space-y-2" data-id="f9ore4tys" data-path="src/pages/PrivacyPolicyPage.tsx">
                <li data-id="h8fsf5d1z" data-path="src/pages/PrivacyPolicyPage.tsx">Email address (when you contact us)</li>
                <li data-id="c7984gr6s" data-path="src/pages/PrivacyPolicyPage.tsx">First name and last name (when you contact us)</li>
                <li data-id="2eu7s7ft3" data-path="src/pages/PrivacyPolicyPage.tsx">Cookies and Usage Data</li>
              </ul>
              <p className="mb-4" data-id="95n5nk22n" data-path="src/pages/PrivacyPolicyPage.tsx">
                <strong data-id="o6yxx3oid" data-path="src/pages/PrivacyPolicyPage.tsx">Health and Fitness Data:</strong> Our calculators may request information such as weight, height, age, gender, and activity levels. This information is processed entirely in your browser and is not stored on our servers or transmitted to us.
              </p>
              <p data-id="smcx4uy72" data-path="src/pages/PrivacyPolicyPage.tsx">
                <strong data-id="crfblpyhr" data-path="src/pages/PrivacyPolicyPage.tsx">Usage Data:</strong> We may also collect information on how the Service is accessed and used ("Usage Data"). This Usage Data may include information such as your computer's Internet Protocol address (IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers, and other diagnostic data.
              </p>
            </section>

            <section className="mb-8" data-id="2i8x0nfgz" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="4fw6l5irh" data-path="src/pages/PrivacyPolicyPage.tsx">Use of Data</h2>
              <p className="mb-4" data-id="7oo8v6a64" data-path="src/pages/PrivacyPolicyPage.tsx">Fitness Calculator Hub uses the collected data for various purposes:</p>
              <ul className="list-disc pl-6 space-y-2" data-id="01k3id6n5" data-path="src/pages/PrivacyPolicyPage.tsx">
                <li data-id="svl9lgc1m" data-path="src/pages/PrivacyPolicyPage.tsx">To provide and maintain our Service</li>
                <li data-id="1zqqf59wd" data-path="src/pages/PrivacyPolicyPage.tsx">To notify you about changes to our Service</li>
                <li data-id="pcdwcqkdp" data-path="src/pages/PrivacyPolicyPage.tsx">To provide customer support</li>
                <li data-id="zsn4wdbsj" data-path="src/pages/PrivacyPolicyPage.tsx">To gather analysis or valuable information so that we can improve our Service</li>
                <li data-id="cef9yrjjm" data-path="src/pages/PrivacyPolicyPage.tsx">To monitor the usage of our Service</li>
                <li data-id="bj3wywi4f" data-path="src/pages/PrivacyPolicyPage.tsx">To detect, prevent and address technical issues</li>
              </ul>
            </section>

            <section className="mb-8" data-id="88faqdtmz" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="9l9oiy3fs" data-path="src/pages/PrivacyPolicyPage.tsx">Cookies</h2>
              <p className="mb-4" data-id="zg9w9p1mj" data-path="src/pages/PrivacyPolicyPage.tsx">
                We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.
              </p>
              <p className="mb-4" data-id="pkv4gq748" data-path="src/pages/PrivacyPolicyPage.tsx">
                Cookies are files with a small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.
              </p>
              <p className="mb-4" data-id="mbohxi9s7" data-path="src/pages/PrivacyPolicyPage.tsx">
                You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.
              </p>
              <p data-id="hays2ijn8" data-path="src/pages/PrivacyPolicyPage.tsx">
                Examples of Cookies we use:
              </p>
              <ul className="list-disc pl-6 space-y-2" data-id="wp4r22p68" data-path="src/pages/PrivacyPolicyPage.tsx">
                <li data-id="qqk81f8b7" data-path="src/pages/PrivacyPolicyPage.tsx"><strong data-id="n95a2kv40" data-path="src/pages/PrivacyPolicyPage.tsx">Session Cookies:</strong> We use Session Cookies to operate our Service.</li>
                <li data-id="artsd7pdk" data-path="src/pages/PrivacyPolicyPage.tsx"><strong data-id="wh2c2f1ef" data-path="src/pages/PrivacyPolicyPage.tsx">Preference Cookies:</strong> We use Preference Cookies to remember your preferences and various settings.</li>
                <li data-id="1c1ljzm21" data-path="src/pages/PrivacyPolicyPage.tsx"><strong data-id="c02uj0l9d" data-path="src/pages/PrivacyPolicyPage.tsx">Security Cookies:</strong> We use Security Cookies for security purposes.</li>
                <li data-id="1x56bzqiy" data-path="src/pages/PrivacyPolicyPage.tsx"><strong data-id="tbjltqobg" data-path="src/pages/PrivacyPolicyPage.tsx">Advertising Cookies:</strong> Advertising Cookies are used to serve you with advertisements that may be relevant to you and your interests.</li>
              </ul>
            </section>

            <section className="mb-8" data-id="vlt2ew94w" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="j0c3gfu7n" data-path="src/pages/PrivacyPolicyPage.tsx">Third-Party Service Providers</h2>
              <p className="mb-4" data-id="275psg0t5" data-path="src/pages/PrivacyPolicyPage.tsx">
                We may employ third-party companies and individuals due to the following reasons:
              </p>
              <ul className="list-disc pl-6 space-y-2 mb-4" data-id="gnhd2uz7m" data-path="src/pages/PrivacyPolicyPage.tsx">
                <li data-id="z72nmc4ag" data-path="src/pages/PrivacyPolicyPage.tsx">To facilitate our Service;</li>
                <li data-id="25s575cyo" data-path="src/pages/PrivacyPolicyPage.tsx">To provide the Service on our behalf;</li>
                <li data-id="0huga0wws" data-path="src/pages/PrivacyPolicyPage.tsx">To perform Service-related services; or</li>
                <li data-id="4hvsuef4w" data-path="src/pages/PrivacyPolicyPage.tsx">To assist us in analyzing how our Service is used.</li>
              </ul>
              <p data-id="xwr9ln69h" data-path="src/pages/PrivacyPolicyPage.tsx">
                These third parties may have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.
              </p>
            </section>

            <section className="mb-8" data-id="9h99czy6i" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="k8ns5h2rq" data-path="src/pages/PrivacyPolicyPage.tsx">Analytics</h2>
              <p className="mb-4" data-id="1tge87zak" data-path="src/pages/PrivacyPolicyPage.tsx">
                We may use third-party Service Providers to monitor and analyze the use of our Service.
              </p>
              <ul className="list-disc pl-6 space-y-2" data-id="0ekz7ttuu" data-path="src/pages/PrivacyPolicyPage.tsx">
                <li data-id="42wf564b5" data-path="src/pages/PrivacyPolicyPage.tsx">
                  <strong data-id="cqgisoiio" data-path="src/pages/PrivacyPolicyPage.tsx">Google Analytics:</strong> Google Analytics is a web analytics service offered by Google that tracks and reports website traffic. Google uses the data collected to track and monitor the use of our Service. This data is shared with other Google services. Google may use the collected data to contextualize and personalize the ads of its own advertising network.
                </li>
              </ul>
            </section>

            <section className="mb-8" data-id="2ebr1x70x" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="n3znbx44j" data-path="src/pages/PrivacyPolicyPage.tsx">Advertising</h2>
              <p className="mb-4" data-id="m60wbsqjp" data-path="src/pages/PrivacyPolicyPage.tsx">
                We may use third-party Service Providers to show advertisements to you to help support and maintain our Service.
              </p>
              <ul className="list-disc pl-6 space-y-2 mb-4" data-id="10xitysda" data-path="src/pages/PrivacyPolicyPage.tsx">
                <li data-id="rsqyp45k9" data-path="src/pages/PrivacyPolicyPage.tsx">
                  <strong data-id="8ftkwjhex" data-path="src/pages/PrivacyPolicyPage.tsx">Google AdSense:</strong> Google AdSense is an advertising service provided by Google. We use Google AdSense to display ads on our Service. It may use a DoubleClick cookie to serve ads based on your visit to our Service and other sites on the Internet.
                </li>
                <li data-id="f86r0nsuh" data-path="src/pages/PrivacyPolicyPage.tsx">
                  <strong data-id="9b3s1oru4" data-path="src/pages/PrivacyPolicyPage.tsx">Other Ad Partners:</strong> We may work with various advertising partners who may use cookies and similar technologies to collect information about your activities on our website and other sites to provide you with targeted advertising.
                </li>
              </ul>
              <p data-id="j3k1jxp4r" data-path="src/pages/PrivacyPolicyPage.tsx">
                You can opt out of targeted advertising by visiting the Digital Advertising Alliance's opt-out portal at: http://optout.aboutads.info/
              </p>
            </section>

            <section className="mb-8" data-id="syu75iy4j" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="8p8od7n0d" data-path="src/pages/PrivacyPolicyPage.tsx">Security of Data</h2>
              <p data-id="bjjcjzi3q" data-path="src/pages/PrivacyPolicyPage.tsx">
                The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.
              </p>
            </section>

            <section className="mb-8" data-id="7e1cv55kk" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="12i8ynbq2" data-path="src/pages/PrivacyPolicyPage.tsx">Children's Privacy</h2>
              <p data-id="m1xv29i2z" data-path="src/pages/PrivacyPolicyPage.tsx">
                Our Service does not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13. If you are a parent or guardian and you are aware that your child has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.
              </p>
            </section>

            <section className="mb-8" data-id="u8hb4fa4z" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="oumlard5e" data-path="src/pages/PrivacyPolicyPage.tsx">Changes to This Privacy Policy</h2>
              <p className="mb-4" data-id="h35e7egyr" data-path="src/pages/PrivacyPolicyPage.tsx">
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.
              </p>
              <p data-id="f899xl9i4" data-path="src/pages/PrivacyPolicyPage.tsx">
                You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
              </p>
            </section>

            <section data-id="1nn7t3brz" data-path="src/pages/PrivacyPolicyPage.tsx">
              <h2 className="text-2xl font-bold mb-4" data-id="ryq7ot6fg" data-path="src/pages/PrivacyPolicyPage.tsx">Contact Us</h2>
              <p data-id="qr6elen5p" data-path="src/pages/PrivacyPolicyPage.tsx">
                If you have any questions about this Privacy Policy, please contact us at <a href="mailto:info@fitcalchub.com" className="text-blue-600 hover:underline" data-id="fxc59rk6e" data-path="src/pages/PrivacyPolicyPage.tsx">info@fitcalchub.com</a>.
              </p>
            </section>
          </div>
        </div>
      </div>
    </Layout>);

};

export default PrivacyPolicyPage;