import Layout from "@/components/Layout/Layout";
import { Separator } from "@/components/ui/separator";

const AboutPage = () => {
  return (
    <Layout>
      <div className="container mx-auto py-12 px-4" data-id="r4517wuh8" data-path="src/pages/AboutPage.tsx">
        <div className="max-w-4xl mx-auto" data-id="i3j1i4nff" data-path="src/pages/AboutPage.tsx">
          <div className="text-center mb-12" data-id="s9kkx5bwp" data-path="src/pages/AboutPage.tsx">
            <h1 className="text-4xl font-bold mb-4" data-id="iko0dbp4u" data-path="src/pages/AboutPage.tsx">About Fitness Calculator Hub</h1>
            <p className="text-xl text-gray-600" data-id="5inag89su" data-path="src/pages/AboutPage.tsx">
              Your trusted source for accurate health and fitness calculations
            </p>
          </div>
          
          <Separator className="my-8" />
          
          <section className="mb-12" data-id="wo87s9lie" data-path="src/pages/AboutPage.tsx">
            <h2 className="text-2xl font-bold mb-4" data-id="jpzw9x4p3" data-path="src/pages/AboutPage.tsx">Our Mission</h2>
            <p className="text-gray-700 mb-4" data-id="105fx5blo" data-path="src/pages/AboutPage.tsx">
              At Fitness Calculator Hub, our mission is to empower individuals to take control of their health 
              and fitness journey by providing accurate, science-based calculators and educational resources.
            </p>
            <p className="text-gray-700" data-id="b61zukpv8" data-path="src/pages/AboutPage.tsx">
              We believe that understanding your body's unique needs is the first step towards achieving your 
              fitness goals, whether you're looking to lose weight, gain muscle, or simply maintain a healthy lifestyle.
            </p>
          </section>
          
          <section className="mb-12" data-id="eulyoiteq" data-path="src/pages/AboutPage.tsx">
            <h2 className="text-2xl font-bold mb-4" data-id="8hv1pibsd" data-path="src/pages/AboutPage.tsx">Why Choose Our Calculators?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8" data-id="uq3yy0oy6" data-path="src/pages/AboutPage.tsx">
              <div className="bg-blue-50 p-6 rounded-lg" data-id="cwqanoscl" data-path="src/pages/AboutPage.tsx">
                <div className="flex items-center mb-4" data-id="wo3itgksl" data-path="src/pages/AboutPage.tsx">
                  <div className="bg-blue-100 p-2 rounded-full mr-4" data-id="cdos9cdat" data-path="src/pages/AboutPage.tsx">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="ej9v93e5o" data-path="src/pages/AboutPage.tsx">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" data-id="wk3onxgfg" data-path="src/pages/AboutPage.tsx" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold" data-id="nmfexbl6g" data-path="src/pages/AboutPage.tsx">Scientific Accuracy</h3>
                </div>
                <p className="text-gray-700" data-id="10890grlw" data-path="src/pages/AboutPage.tsx">
                  Our calculators are based on peer-reviewed scientific formulas used by healthcare professionals and fitness experts.
                </p>
              </div>
              
              <div className="bg-green-50 p-6 rounded-lg" data-id="nvjf0q7e4" data-path="src/pages/AboutPage.tsx">
                <div className="flex items-center mb-4" data-id="sllz38q9c" data-path="src/pages/AboutPage.tsx">
                  <div className="bg-green-100 p-2 rounded-full mr-4" data-id="c82kazulp" data-path="src/pages/AboutPage.tsx">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="epp3v5g5g" data-path="src/pages/AboutPage.tsx">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" data-id="f07yq159p" data-path="src/pages/AboutPage.tsx" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold" data-id="4jmi02pfb" data-path="src/pages/AboutPage.tsx">Regular Updates</h3>
                </div>
                <p className="text-gray-700" data-id="l39xfgd83" data-path="src/pages/AboutPage.tsx">
                  We continuously update our calculators to reflect the latest research and best practices in nutrition and fitness science.
                </p>
              </div>
              
              <div className="bg-purple-50 p-6 rounded-lg" data-id="wbh75g444" data-path="src/pages/AboutPage.tsx">
                <div className="flex items-center mb-4" data-id="bq6aj62ff" data-path="src/pages/AboutPage.tsx">
                  <div className="bg-purple-100 p-2 rounded-full mr-4" data-id="ucz03roam" data-path="src/pages/AboutPage.tsx">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="teswqz7d2" data-path="src/pages/AboutPage.tsx">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" data-id="m1vzyxgm4" data-path="src/pages/AboutPage.tsx" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold" data-id="8hvrellce" data-path="src/pages/AboutPage.tsx">Privacy Focused</h3>
                </div>
                <p className="text-gray-700" data-id="7c3ejtk21" data-path="src/pages/AboutPage.tsx">
                  We respect your privacy. All calculations are performed in your browser, and we don't store any of your personal health data.
                </p>
              </div>
              
              <div className="bg-orange-50 p-6 rounded-lg" data-id="ut0hn3quk" data-path="src/pages/AboutPage.tsx">
                <div className="flex items-center mb-4" data-id="bne66rnod" data-path="src/pages/AboutPage.tsx">
                  <div className="bg-orange-100 p-2 rounded-full mr-4" data-id="dzt0lzbuj" data-path="src/pages/AboutPage.tsx">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-id="qt8kff0h3" data-path="src/pages/AboutPage.tsx">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" data-id="2itgb7ptk" data-path="src/pages/AboutPage.tsx" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold" data-id="2dmq4ar2w" data-path="src/pages/AboutPage.tsx">Mobile Friendly</h3>
                </div>
                <p className="text-gray-700" data-id="0mhf2i38l" data-path="src/pages/AboutPage.tsx">
                  Access our calculators anytime, anywhere. Our tools are fully optimized for all devices including smartphones and tablets.
                </p>
              </div>
            </div>
          </section>
          
          <section className="mb-12" data-id="smc41o3bs" data-path="src/pages/AboutPage.tsx">
            <h2 className="text-2xl font-bold mb-4" data-id="68byhnr2g" data-path="src/pages/AboutPage.tsx">Our Team</h2>
            <p className="text-gray-700 mb-6" data-id="qpvhgwx1t" data-path="src/pages/AboutPage.tsx">
              Fitness Calculator Hub was created by a team of fitness enthusiasts, nutritionists, and web developers 
              who share a passion for health and technology. We combine our expertise to bring you tools that are both 
              scientifically accurate and user-friendly.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6" data-id="rirravu6p" data-path="src/pages/AboutPage.tsx">
              <div className="text-center" data-id="5w6lmf9up" data-path="src/pages/AboutPage.tsx">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden" data-id="h6ak38a6k" data-path="src/pages/AboutPage.tsx">
                  <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80" alt="Team Member" className="w-full h-full object-cover" data-id="o5ixejyvv" data-path="src/pages/AboutPage.tsx" />
                </div>
                <h3 className="text-lg font-semibold" data-id="37g6ieqpe" data-path="src/pages/AboutPage.tsx">Sarah Johnson</h3>
                <p className="text-gray-600" data-id="vm277jibp" data-path="src/pages/AboutPage.tsx">Registered Dietitian</p>
              </div>
              <div className="text-center" data-id="c297hpkc9" data-path="src/pages/AboutPage.tsx">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden" data-id="h0g5ztmpr" data-path="src/pages/AboutPage.tsx">
                  <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80" alt="Team Member" className="w-full h-full object-cover" data-id="hlkodjl2q" data-path="src/pages/AboutPage.tsx" />
                </div>
                <h3 className="text-lg font-semibold" data-id="tca55wb8m" data-path="src/pages/AboutPage.tsx">Michael Chen</h3>
                <p className="text-gray-600" data-id="sbbpge5yi" data-path="src/pages/AboutPage.tsx">Fitness Coach</p>
              </div>
              <div className="text-center" data-id="nedih1w00" data-path="src/pages/AboutPage.tsx">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden" data-id="sombje6p1" data-path="src/pages/AboutPage.tsx">
                  <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1688&q=80" alt="Team Member" className="w-full h-full object-cover" data-id="dfab2mrev" data-path="src/pages/AboutPage.tsx" />
                </div>
                <h3 className="text-lg font-semibold" data-id="4civkz548" data-path="src/pages/AboutPage.tsx">David Rodriguez</h3>
                <p className="text-gray-600" data-id="wad80qksy" data-path="src/pages/AboutPage.tsx">Web Developer</p>
              </div>
            </div>
          </section>
          
          <section data-id="mkyhzuwhc" data-path="src/pages/AboutPage.tsx">
            <h2 className="text-2xl font-bold mb-4" data-id="jstiwnk7p" data-path="src/pages/AboutPage.tsx">Our Commitment</h2>
            <p className="text-gray-700 mb-4" data-id="hadcekf7h" data-path="src/pages/AboutPage.tsx">
              We are committed to providing accurate information and useful tools to help you make informed decisions 
              about your health and fitness. However, it's important to note that our calculators provide estimates 
              and should not replace professional medical advice.
            </p>
            <p className="text-gray-700" data-id="o2knyvasp" data-path="src/pages/AboutPage.tsx">
              We encourage you to consult with healthcare providers or fitness professionals for personalized guidance 
              tailored to your specific health conditions and goals.
            </p>
          </section>
        </div>
      </div>
    </Layout>);

};

export default AboutPage;