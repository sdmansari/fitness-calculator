import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { generatePDF, downloadPDF } from '@/utils/pdfGenerator';
import { shareToWhatsApp } from '@/utils/sharing';
import AuthModal from './Auth/AuthModal';
import { Download, Share2 } from 'lucide-react';

interface ResultActionsProps {
  title: string;
  value: string | number;
  unit?: string;
  category?: string;
  details?: {[key: string]: string | number;};
}

const ResultActions = ({ title, value, unit, category, details }: ResultActionsProps) => {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const handleDownload = () => {
    if (!isAuthenticated) {
      toast({
        title: 'Authentication Required',
        description: 'Please sign in to download your results.',
        variant: 'destructive'
      });
      setIsAuthModalOpen(true);
      return;
    }

    try {
      const pdfDataUrl = generatePDF({
        title,
        value,
        unit,
        category,
        date: new Date(),
        details
      });

      downloadPDF(pdfDataUrl, `${title.toLowerCase().replace(/\s+/g, '-')}-result.pdf`);

      toast({
        title: 'Success',
        description: 'Your results have been downloaded successfully!'
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: 'Error',
        description: 'Failed to download your results. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleShare = () => {
    if (!isAuthenticated) {
      toast({
        title: 'Authentication Required',
        description: 'Please sign in to share your results.',
        variant: 'destructive'
      });
      setIsAuthModalOpen(true);
      return;
    }

    try {
      shareToWhatsApp({
        title,
        value,
        unit,
        category
      });

      toast({
        title: 'Share initiated',
        description: 'WhatsApp sharing window has been opened.'
      });
    } catch (error) {
      console.error('Error sharing to WhatsApp:', error);
      toast({
        title: 'Error',
        description: 'Failed to share your results. Please try again.',
        variant: 'destructive'
      });
    }
  };

  return (
    <>
      <div className="flex gap-3 mt-4" data-id="nph5n8e0i" data-path="src/components/ResultActions.tsx">
        <Button
          variant="outline"
          onClick={handleDownload}
          className="flex gap-2 items-center">

          <Download size={16} />
          Download PDF
        </Button>
        <Button
          variant="outline"
          onClick={handleShare}
          className="flex gap-2 items-center">

          <Share2 size={16} />
          Share on WhatsApp
        </Button>
      </div>
      
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        defaultTab="login" />

    </>);

};

export default ResultActions;