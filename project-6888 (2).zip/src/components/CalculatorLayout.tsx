import { ReactNode } from "react";
import Layout from "./Layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface CalculatorLayoutProps {
  title: string;
  description: string;
  icon: ReactNode;
  children: ReactNode;
}

const CalculatorLayout = ({ title, description, icon, children }: CalculatorLayoutProps) => {
  return (
    <Layout>
      <div className="container mx-auto py-8 px-4" data-id="6cabkyfte" data-path="src/components/CalculatorLayout.tsx">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" data-id="mhjuau9w1" data-path="src/components/CalculatorLayout.tsx">
          {/* Main calculator column */}
          <div className="lg:col-span-2" data-id="mnpg5o39n" data-path="src/components/CalculatorLayout.tsx">
            <Card className="w-full">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-teal-500 text-white">
                <div className="flex items-center gap-3" data-id="d8huds8kt" data-path="src/components/CalculatorLayout.tsx">
                  <div className="p-2 bg-white/20 rounded-full" data-id="pii6v2vnl" data-path="src/components/CalculatorLayout.tsx">
                    {icon}
                  </div>
                  <div data-id="u6ui4glmv" data-path="src/components/CalculatorLayout.tsx">
                    <CardTitle className="text-2xl">{title}</CardTitle>
                    <CardDescription className="text-white/90">{description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6">{children}</CardContent>
            </Card>

            {/* Bottom ad section */}
            <div className="mt-8 mb-4" data-id="zcuhobvwa" data-path="src/components/CalculatorLayout.tsx">
              <div className="bg-white p-2 rounded shadow-sm" data-id="ml5apl3li" data-path="src/components/CalculatorLayout.tsx">
                <p className="text-gray-500 text-sm" data-id="xi70vdlbb" data-path="src/components/CalculatorLayout.tsx">Advertisement</p>
                <div className="h-24 flex items-center justify-center border border-gray-200 rounded" data-id="bbaedb3b3" data-path="src/components/CalculatorLayout.tsx">
                  <span className="text-gray-400" data-id="vvbuk0fvc" data-path="src/components/CalculatorLayout.tsx">Ad Space</span>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1" data-id="afr4fzbew" data-path="src/components/CalculatorLayout.tsx">
            {/* Ad section */}
            <div className="mb-6" data-id="9svw0b116" data-path="src/components/CalculatorLayout.tsx">
              <div className="bg-white p-2 rounded shadow-sm" data-id="4hp0keoga" data-path="src/components/CalculatorLayout.tsx">
                <p className="text-gray-500 text-sm" data-id="gebaij9r0" data-path="src/components/CalculatorLayout.tsx">Advertisement</p>
                <div className="h-64 flex items-center justify-center border border-gray-200 rounded" data-id="9i7m1vndr" data-path="src/components/CalculatorLayout.tsx">
                  <span className="text-gray-400" data-id="ew7tvmj0j" data-path="src/components/CalculatorLayout.tsx">Ad Space</span>
                </div>
              </div>
            </div>

            {/* Related calculators */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Related Calculators</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3" data-id="52ushuxcn" data-path="src/components/CalculatorLayout.tsx">
                  <li className="text-blue-600 hover:underline" data-id="i4bb2dz0k" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/bmi" data-id="nwodhk0a8" data-path="src/components/CalculatorLayout.tsx">BMI Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="901mckoj0" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/bmr" data-id="iiulfp1ov" data-path="src/components/CalculatorLayout.tsx">BMR Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="wqb0spmw5" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/tdee" data-id="d7pz7v0ru" data-path="src/components/CalculatorLayout.tsx">TDEE Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="h89smql8b" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/ideal-weight" data-id="todyhetha" data-path="src/components/CalculatorLayout.tsx">Ideal Weight Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="soua7nluz" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/body-fat" data-id="kyr6crifc" data-path="src/components/CalculatorLayout.tsx">Body Fat Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="l0fculjhf" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/lean-body-mass" data-id="hty1ukxoi" data-path="src/components/CalculatorLayout.tsx">Lean Body Mass Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="dlfhblty7" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/calcium-needs" data-id="rtdgpi4xf" data-path="src/components/CalculatorLayout.tsx">Calcium Needs Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="s6pminp16" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/protein-intake" data-id="9153bujwq" data-path="src/components/CalculatorLayout.tsx">Protein Intake Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="jxs7t4xfg" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/macro" data-id="rkni4hyyn" data-path="src/components/CalculatorLayout.tsx">Macro Calculator</a>
                  </li>
                  <li className="text-blue-600 hover:underline" data-id="z51bn3cqg" data-path="src/components/CalculatorLayout.tsx">
                    <a href="/calculators/food-calorie" data-id="8g06koexl" data-path="src/components/CalculatorLayout.tsx">Food Calorie Calculator</a>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>);

};

export default CalculatorLayout;