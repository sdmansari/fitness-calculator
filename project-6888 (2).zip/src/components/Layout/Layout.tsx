import { ReactNode } from "react";
import Header from "./Header";
import Footer from "./Footer";

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="flex flex-col min-h-screen" data-id="kxjsy62h4" data-path="src/components/Layout/Layout.tsx">
      <Header />
      <main className="flex-grow" data-id="026blv765" data-path="src/components/Layout/Layout.tsx">{children}</main>
      <Footer />
    </div>);

};

export default Layout;