import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import UserProfile from "@/components/Auth/UserProfile";
import { useIsMobile } from "@/hooks/use-mobile";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  // Close mobile menu when switching to desktop view
  useEffect(() => {
    if (!isMobile) {
      setMobileMenuOpen(false);
    }
  }, [isMobile]);

  return (
    <header className="bg-gradient-to-r from-blue-600 to-teal-500 py-4 px-4 shadow-md sticky top-0 z-50" data-id="58qfkd733" data-path="src/components/Layout/Header.tsx">
      <div className="container mx-auto" data-id="k3qdw3p75" data-path="src/components/Layout/Header.tsx">
        {/* Top bar with logo and hamburger menu on mobile */}
        <div className="flex justify-between items-center w-full" data-id="0uae7k9cz" data-path="src/components/Layout/Header.tsx">
          <Link
            to="/"
            className="text-white text-xl sm:text-2xl font-bold flex items-center whitespace-nowrap"
            aria-label="Fitness Calculator Hub - Home">

            <img
              src="/images/fitness-logo.svg"
              alt="Fitness Calculator Hub Logo"
              className="h-8 sm:h-10 w-auto mr-2 sm:mr-3"
              width="120"
              height="120"
              loading="eager"
              onError={(e) => {
                // Fallback to SVG icon if logo fails to load
                const fallbackIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                fallbackIcon.setAttribute('className', 'h-7 w-7 mr-2');
                fallbackIcon.setAttribute('fill', 'none');
                fallbackIcon.setAttribute('viewBox', '0 0 24 24');
                fallbackIcon.setAttribute('stroke', 'currentColor');

                const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                path.setAttribute('strokeLinecap', 'round');
                path.setAttribute('strokeLinejoin', 'round');
                path.setAttribute('strokeWidth', '2');
                path.setAttribute('d', 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2');

                fallbackIcon.appendChild(path);
                e.currentTarget.parentNode?.replaceChild(fallbackIcon, e.currentTarget);
              }} data-id="u66ssavo9" data-path="src/components/Layout/Header.tsx" />

            <span className="truncate sm:inline" data-id="96dd0z6ce" data-path="src/components/Layout/Header.tsx">Fitness Calculator Hub</span>
          </Link>
          
          {/* Mobile-only hamburger menu button */}
          {isMobile &&
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-white p-1 ml-2"
            aria-label="Toggle menu">

              <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-6 h-6" data-id="7olln1r1k" data-path="src/components/Layout/Header.tsx">

                {mobileMenuOpen ?
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" data-id="okddvq0k2" data-path="src/components/Layout/Header.tsx" /> :

              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" data-id="1dftkx1cw" data-path="src/components/Layout/Header.tsx" />
              }
              </svg>
            </Button>
          }

          {/* Desktop navigation and profile */}
          {!isMobile &&
          <div className="flex items-center gap-2 md:gap-4" data-id="61gsdxx4m" data-path="src/components/Layout/Header.tsx">
              <nav className="flex space-x-1 md:space-x-2 lg:space-x-4" data-id="a98ytql1k" data-path="src/components/Layout/Header.tsx">
                <Button variant="link" asChild className="text-white hover:text-blue-100 font-medium py-1 px-2 h-auto">
                  <Link to="/">Home</Link>
                </Button>
                <Button variant="link" asChild className="text-white hover:text-blue-100 font-medium py-1 px-2 h-auto">
                  <Link to="/blog">Blog</Link>
                </Button>
                <Button variant="link" asChild className="text-white hover:text-blue-100 font-medium py-1 px-2 h-auto">
                  <Link to="/about">About</Link>
                </Button>
                <Button variant="link" asChild className="text-white hover:text-blue-100 font-medium py-1 px-2 h-auto">
                  <Link to="/contact">Contact</Link>
                </Button>
              </nav>
              <UserProfile />
            </div>
          }
        </div>



        {/* Mobile navigation menu */}
        {isMobile && mobileMenuOpen &&
        <nav className="flex flex-col mt-4 border-t border-blue-400 pt-4 space-y-2" data-id="d3visx5lq" data-path="src/components/Layout/Header.tsx">
            <Button variant="ghost" asChild className="text-white hover:bg-blue-600 font-medium justify-start">
              <Link to="/">Home</Link>
            </Button>
            <Button variant="ghost" asChild className="text-white hover:bg-blue-600 font-medium justify-start">
              <Link to="/blog">Blog</Link>
            </Button>
            <Button variant="ghost" asChild className="text-white hover:bg-blue-600 font-medium justify-start">
              <Link to="/about">About</Link>
            </Button>
            <Button variant="ghost" asChild className="text-white hover:bg-blue-600 font-medium justify-start">
              <Link to="/contact">Contact</Link>
            </Button>
            <div className="py-2" data-id="gyl0e56b3" data-path="src/components/Layout/Header.tsx">
              <UserProfile />
            </div>
          </nav>
        }
      </div>
    </header>);

};

export default Header;