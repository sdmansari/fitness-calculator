import React, { useEffect } from 'react';

interface MetaTagsProps {
  title: string;
  description: string;
  keywords: string;
  ogImage?: string;
  canonicalUrl?: string;
  structuredData?: object;
  isMedicalContent?: boolean;
  publishedDate?: string;
  modifiedDate?: string;
  author?: string;
  twitterCard?: string;
  language?: string;
}

export const MetaTags: React.FC<MetaTagsProps> = ({
  title,
  description,
  keywords,
  ogImage = "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b",
  canonicalUrl,
  structuredData,
  isMedicalContent = true,
  publishedDate = new Date().toISOString().split('T')[0],
  modifiedDate = new Date().toISOString().split('T')[0],
  author = "Fitness Calculator Hub Team",
  twitterCard = "summary_large_image",
  language = "en"
}) => {
  useEffect(() => {
    // Update the document title
    document.title = title;

    // Update meta description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);

    // Update meta keywords
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', keywords);

    // Update OG meta tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    if (!ogTitle) {
      ogTitle = document.createElement('meta');
      ogTitle.setAttribute('property', 'og:title');
      document.head.appendChild(ogTitle);
    }
    ogTitle.setAttribute('content', title);

    let ogDescription = document.querySelector('meta[property="og:description"]');
    if (!ogDescription) {
      ogDescription = document.createElement('meta');
      ogDescription.setAttribute('property', 'og:description');
      document.head.appendChild(ogDescription);
    }
    ogDescription.setAttribute('content', description);

    let ogImageTag = document.querySelector('meta[property="og:image"]');
    if (!ogImageTag) {
      ogImageTag = document.createElement('meta');
      ogImageTag.setAttribute('property', 'og:image');
      document.head.appendChild(ogImageTag);
    }
    ogImageTag.setAttribute('content', ogImage);

    // Add og:type
    let ogType = document.querySelector('meta[property="og:type"]');
    if (!ogType) {
      ogType = document.createElement('meta');
      ogType.setAttribute('property', 'og:type');
      document.head.appendChild(ogType);
    }
    ogType.setAttribute('content', 'website');

    // Add og:url
    let ogUrl = document.querySelector('meta[property="og:url"]');
    if (!ogUrl) {
      ogUrl = document.createElement('meta');
      ogUrl.setAttribute('property', 'og:url');
      document.head.appendChild(ogUrl);
    }
    ogUrl.setAttribute('content', canonicalUrl || window.location.href);

    // Add article:published_time
    let articlePublished = document.querySelector('meta[property="article:published_time"]');
    if (!articlePublished) {
      articlePublished = document.createElement('meta');
      articlePublished.setAttribute('property', 'article:published_time');
      document.head.appendChild(articlePublished);
    }
    articlePublished.setAttribute('content', publishedDate);

    // Add article:modified_time
    let articleModified = document.querySelector('meta[property="article:modified_time"]');
    if (!articleModified) {
      articleModified = document.createElement('meta');
      articleModified.setAttribute('property', 'article:modified_time');
      document.head.appendChild(articleModified);
    }
    articleModified.setAttribute('content', modifiedDate);

    // Add Twitter card tags
    let twitterCardTag = document.querySelector('meta[name="twitter:card"]');
    if (!twitterCardTag) {
      twitterCardTag = document.createElement('meta');
      twitterCardTag.setAttribute('name', 'twitter:card');
      document.head.appendChild(twitterCardTag);
    }
    twitterCardTag.setAttribute('content', twitterCard);

    let twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (!twitterTitle) {
      twitterTitle = document.createElement('meta');
      twitterTitle.setAttribute('name', 'twitter:title');
      document.head.appendChild(twitterTitle);
    }
    twitterTitle.setAttribute('content', title);

    let twitterDescription = document.querySelector('meta[name="twitter:description"]');
    if (!twitterDescription) {
      twitterDescription = document.createElement('meta');
      twitterDescription.setAttribute('name', 'twitter:description');
      document.head.appendChild(twitterDescription);
    }
    twitterDescription.setAttribute('content', description);

    let twitterImage = document.querySelector('meta[name="twitter:image"]');
    if (!twitterImage) {
      twitterImage = document.createElement('meta');
      twitterImage.setAttribute('name', 'twitter:image');
      document.head.appendChild(twitterImage);
    }
    twitterImage.setAttribute('content', ogImage);

    // Add html lang attribute
    document.documentElement.setAttribute('lang', language);

    // Update canonical URL if provided
    let canonicalTag = document.querySelector('link[rel="canonical"]');
    if (canonicalUrl) {
      if (!canonicalTag) {
        canonicalTag = document.createElement('link');
        canonicalTag.setAttribute('rel', 'canonical');
        document.head.appendChild(canonicalTag);
      }
      canonicalTag.setAttribute('href', canonicalUrl);
    } else if (canonicalTag) {
      canonicalTag.remove();
    }

    // Add medical information schema if specified
    if (isMedicalContent) {
      let medicalSchema = document.querySelector('script[data-medical-schema]');
      if (!medicalSchema) {
        medicalSchema = document.createElement('script');
        medicalSchema.setAttribute('type', 'application/ld+json');
        medicalSchema.setAttribute('data-medical-schema', 'true');
        document.head.appendChild(medicalSchema);
      }

      const medicalSchemaData = {
        '@context': 'https://schema.org',
        '@type': 'MedicalWebPage',
        'headline': title,
        'description': description,
        'keywords': keywords,
        'lastReviewed': modifiedDate,
        'datePublished': publishedDate,
        'dateModified': modifiedDate,
        'author': {
          '@type': 'Organization',
          'name': author,
          'url': 'https://fitcalchub.com/about'
        },
        'mainContentOfPage': {
          '@type': 'WebPageElement',
          'cssSelector': '.main-content'
        },
        'reviewedBy': {
          '@type': 'Organization',
          'name': 'Fitness Calculator Hub Medical Team',
          'url': 'https://fitcalchub.com/about'
        },
        'publisher': {
          '@type': 'Organization',
          'name': 'Fitness Calculator Hub',
          'logo': {
            '@type': 'ImageObject',
            'url': 'https://fitcalchub.com/public/medical-favicon.svg'
          }
        }
      };

      medicalSchema.textContent = JSON.stringify(medicalSchemaData);
    }

    // Add custom structured data if provided
    if (structuredData) {
      let customSchema = document.querySelector('script[data-custom-schema]');
      if (!customSchema) {
        customSchema = document.createElement('script');
        customSchema.setAttribute('type', 'application/ld+json');
        customSchema.setAttribute('data-custom-schema', 'true');
        document.head.appendChild(customSchema);
      }

      customSchema.textContent = JSON.stringify(structuredData);
    }

    // Clean up when component unmounts
    return () => {
      document.title = 'Fitness Calculator Hub';
      // Remove schema scripts
      document.querySelector('script[data-medical-schema]')?.remove();
      document.querySelector('script[data-custom-schema]')?.remove();
    };
  }, [title, description, keywords, ogImage, canonicalUrl, structuredData, isMedicalContent, publishedDate, modifiedDate, author, twitterCard, language]);

  return null; // This component doesn't render anything visible
};

export default MetaTags;