import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface CalculatorCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  path: string;
}

const CalculatorCard = ({ title, description, icon, path }: CalculatorCardProps) => {
  return (
    <Card className="h-full hover:shadow-lg transition-shadow duration-300">
      <CardHeader>
        <div className="flex items-center space-x-2" data-id="5hnggbjt0" data-path="src/components/CalculatorCard.tsx">
          <div className="w-10 h-10 flex items-center justify-center text-white bg-gradient-to-r from-blue-500 to-teal-400 rounded-full" data-id="hehkfe8mn" data-path="src/components/CalculatorCard.tsx">
            {icon}
          </div>
          <CardTitle className="text-xl">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-gray-600 min-h-[80px]">
          {description}
        </CardDescription>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600">
          <Link to={path}>Use Calculator</Link>
        </Button>
      </CardFooter>
    </Card>);

};

export default CalculatorCard;