import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator } from
'@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import AuthModal from './AuthModal';

const UserProfile = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');

  const handleLogin = () => {
    setAuthModalTab('login');
    setIsAuthModalOpen(true);
  };

  const handleRegister = () => {
    setAuthModalTab('register');
    setIsAuthModalOpen(true);
  };

  const handleLogout = () => {
    logout();
  };

  const getInitials = (name: string) => {
    return name.
    split(' ').
    map((part) => part[0]).
    join('').
    toUpperCase().
    substring(0, 2);
  };

  return (
    <>
      {isAuthenticated && user ?
      <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative rounded-full h-8 w-8 p-0 overflow-hidden border">
              <Avatar>
                <AvatarFallback className="bg-blue-100 text-blue-600">
                  {getInitials(user.name)}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <div className="px-2 py-1.5 text-sm" data-id="ethnyjv9o" data-path="src/components/Auth/UserProfile.tsx">
              <div className="font-semibold" data-id="uhlpkmnw2" data-path="src/components/Auth/UserProfile.tsx">{user.name}</div>
              <div className="text-xs text-muted-foreground" data-id="r1uqzz3v7" data-path="src/components/Auth/UserProfile.tsx">{user.email}</div>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem
            className="cursor-pointer text-red-600"
            onClick={handleLogout}>

              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu> :

      <div className="flex gap-2" data-id="29d5qoaft" data-path="src/components/Auth/UserProfile.tsx">
          <Button variant="outline" onClick={handleLogin}>
            Login
          </Button>
          <Button className="bg-white text-blue-600 hover:bg-blue-50" onClick={handleRegister}>
            Sign Up
          </Button>
        </div>
      }

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        defaultTab={authModalTab} />

    </>);

};

export default UserProfile;