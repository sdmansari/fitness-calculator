import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';

type User = {
  id: string;
  email: string;
  name: string;
};

type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, name: string, password: string) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

type AuthProviderProps = {
  children: ReactNode;
};

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    // Check if user data exists in localStorage
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (email: string, password: string) => {
    // Simulate API call
    // In a real app, this would call a backend endpoint
    return new Promise<void>((resolve, reject) => {
      setTimeout(() => {
        // Check if user exists in our "fake database" (localStorage)
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        const foundUser = users.find((u: any) => u.email === email);

        if (foundUser && foundUser.password === password) {
          // Create user session without password
          const userSession = {
            id: foundUser.id,
            email: foundUser.email,
            name: foundUser.name
          };

          // Store in memory and localStorage
          setUser(userSession);
          setIsAuthenticated(true);
          localStorage.setItem('user', JSON.stringify(userSession));
          resolve();
        } else {
          reject(new Error('Invalid email or password'));
        }
      }, 500); // Simulate network delay
    });
  };

  const register = async (email: string, name: string, password: string) => {
    // Simulate API call
    return new Promise<void>((resolve, reject) => {
      setTimeout(() => {
        // Get existing users
        const users = JSON.parse(localStorage.getItem('users') || '[]');

        // Check if user already exists
        if (users.some((u: any) => u.email === email)) {
          reject(new Error('User with this email already exists'));
          return;
        }

        // Create new user
        const newUser = {
          id: `user_${Date.now()}`,
          email,
          name,
          password // Note: In a real app, passwords should be hashed
        };

        // Add to "database"
        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));

        // Create user session without password
        const userSession = {
          id: newUser.id,
          email: newUser.email,
          name: newUser.name
        };

        // Store in memory and localStorage
        setUser(userSession);
        setIsAuthenticated(true);
        localStorage.setItem('user', JSON.stringify(userSession));
        resolve();
      }, 500); // Simulate network delay
    });
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('user');
  };

  const value = {
    user,
    isAuthenticated,
    login,
    register,
    logout
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};