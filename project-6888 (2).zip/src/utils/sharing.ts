interface ShareData {
  title: string;
  value: string | number;
  unit?: string;
  category?: string;
}

export const shareToWhatsApp = (data: ShareData) => {
  // Format the text to share
  const text = `
📊 My ${data.title} result from Fitness Calculator Hub:
${data.value}${data.unit ? ` ${data.unit}` : ''}
${data.category ? `Category: ${data.category}` : ''}

Calculate yours at https://fitcalchub.com
`;

  // Encode the text for URL
  const encodedText = encodeURIComponent(text);

  // Create WhatsApp sharing URL
  const whatsappUrl = `https://wa.me/?text=${encodedText}`;

  // Open in a new window/tab
  window.open(whatsappUrl, '_blank');
};