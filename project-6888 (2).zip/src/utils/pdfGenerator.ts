import { jsPDF } from 'jspdf';

interface ResultData {
  title: string;
  value: string | number;
  unit?: string;
  category?: string;
  date: Date;
  details?: {[key: string]: string | number;};
}

export const generatePDF = (data: ResultData): string => {
  const doc = new jsPDF();

  // Add logo and title
  doc.setFontSize(22);
  doc.setTextColor(0, 0, 255);
  doc.text('Fitness Calculator Hub', 105, 20, { align: 'center' });

  // Add result details
  doc.setFontSize(18);
  doc.setTextColor(0, 0, 0);
  doc.text(data.title, 105, 40, { align: 'center' });

  // Add date
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated on: ${data.date.toLocaleDateString()}`, 105, 50, { align: 'center' });

  // Add main result
  doc.setFontSize(24);
  doc.setTextColor(0, 100, 0);
  const valueText = `${data.value}${data.unit ? ` ${data.unit}` : ''}`;
  doc.text(valueText, 105, 70, { align: 'center' });

  // Add category if available
  if (data.category) {
    doc.setFontSize(16);
    doc.setTextColor(50, 50, 200);
    doc.text(`Category: ${data.category}`, 105, 85, { align: 'center' });
  }

  // Add additional details if available
  if (data.details && Object.keys(data.details).length > 0) {
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('Additional Details:', 20, 110);

    let y = 120;
    Object.entries(data.details).forEach(([key, value]) => {
      doc.text(`${key}: ${value}`, 30, y);
      y += 10;
    });
  }

  // Add footer
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text('www.fitcalchub.com', 105, 280, { align: 'center' });

  // Convert to data URL for preview or direct download
  return doc.output('dataurlstring');
};

export const downloadPDF = (dataUrl: string, filename: string) => {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  link.click();
};