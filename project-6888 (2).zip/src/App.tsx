import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import { AuthProvider } from "./contexts/AuthContext";
import HomePage from "./pages/HomePage";
import NotFound from "./pages/NotFound";
import AboutPage from "./pages/AboutPage";
import ContactPage from "./pages/ContactPage";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import DisclaimerPage from "./pages/DisclaimerPage";
import BlogPage from "./pages/BlogPage";
// BMIGuide is lazy loaded below
import BMICalculator from "./pages/calculators/BMICalculator";
import BMRCalculator from "./pages/calculators/BMRCalculator";
import TDEECalculator from "./pages/calculators/TDEECalculator";
import IdealWeightCalculator from "./pages/calculators/IdealWeightCalculator";
import BodyFatCalculator from "./pages/calculators/BodyFatCalculator";
import LeanBodyMassCalculator from "./pages/calculators/LeanBodyMassCalculator";
import CalciumNeedsCalculator from "./pages/calculators/CalciumNeedsCalculator";
import ProteinIntakeCalculator from "./pages/calculators/ProteinIntakeCalculator";
import MacroCalculator from "./pages/calculators/MacroCalculator";
import FoodCalorieCalculator from "./pages/calculators/FoodCalorieCalculator";

// Lazy load blog articles
const BMIGuide = lazy(() => import("./pages/blog/BMIGuide"));
const BMRGuide = lazy(() => import("./pages/blog/BMRGuide"));
const TDEEGuide = lazy(() => import("./pages/blog/TDEEGuide"));
const BodyFatGuide = lazy(() => import("./pages/blog/BodyFatGuide"));
const IdealWeightGuide = lazy(() => import("./pages/blog/IdealWeightGuide"));
const LeanBodyMassGuide = lazy(() => import("./pages/blog/LeanBodyMassGuide"));
const ProteinGuide = lazy(() => import("./pages/blog/ProteinGuide"));
const MacroGuide = lazy(() => import("./pages/blog/MacroGuide"));
const CalciumGuide = lazy(() => import("./pages/blog/CalciumGuide"));
const FoodCalorieGuide = lazy(() => import("./pages/blog/FoodCalorieGuide"));

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/disclaimer" element={<DisclaimerPage />} />
            
            {/* Blog Routes */}
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/bmi-guide" element={<Suspense fallback={<div data-id="dzplpf7ep" data-path="src/App.tsx">Loading...</div>}><BMIGuide /></Suspense>} />
            <Route path="/blog/bmr-guide" element={<Suspense fallback={<div data-id="xlqmyxmrd" data-path="src/App.tsx">Loading...</div>}><BMRGuide /></Suspense>} />
            <Route path="/blog/tdee-guide" element={<Suspense fallback={<div data-id="ut6psp38f" data-path="src/App.tsx">Loading...</div>}><TDEEGuide /></Suspense>} />
            <Route path="/blog/body-fat-guide" element={<Suspense fallback={<div data-id="5xvmggbqs" data-path="src/App.tsx">Loading...</div>}><BodyFatGuide /></Suspense>} />
            <Route path="/blog/ideal-weight-guide" element={<Suspense fallback={<div data-id="mt8u3p4z1" data-path="src/App.tsx">Loading...</div>}><IdealWeightGuide /></Suspense>} />
            <Route path="/blog/lean-body-mass-guide" element={<Suspense fallback={<div data-id="7hyvd9wj4" data-path="src/App.tsx">Loading...</div>}><LeanBodyMassGuide /></Suspense>} />
            <Route path="/blog/protein-guide" element={<Suspense fallback={<div data-id="ff7wz5o58" data-path="src/App.tsx">Loading...</div>}><ProteinGuide /></Suspense>} />
            <Route path="/blog/macro-guide" element={<Suspense fallback={<div data-id="o1m4a5scl" data-path="src/App.tsx">Loading...</div>}><MacroGuide /></Suspense>} />
            <Route path="/blog/calcium-guide" element={<Suspense fallback={<div data-id="zwen6w7pu" data-path="src/App.tsx">Loading...</div>}><CalciumGuide /></Suspense>} />
            <Route path="/blog/food-calorie-guide" element={<Suspense fallback={<div data-id="9aenfi6dr" data-path="src/App.tsx">Loading...</div>}><FoodCalorieGuide /></Suspense>} />
            
            {/* Calculator Routes */}
            <Route path="/calculators/bmi" element={<BMICalculator />} />
            <Route path="/calculators/bmr" element={<BMRCalculator />} />
            <Route path="/calculators/tdee" element={<TDEECalculator />} />
            <Route path="/calculators/ideal-weight" element={<IdealWeightCalculator />} />
            <Route path="/calculators/body-fat" element={<BodyFatCalculator />} />
            <Route path="/calculators/lean-body-mass" element={<LeanBodyMassCalculator />} />
            <Route path="/calculators/calcium-needs" element={<CalciumNeedsCalculator />} />
            <Route path="/calculators/protein-intake" element={<ProteinIntakeCalculator />} />
            <Route path="/calculators/macro" element={<MacroCalculator />} />
            <Route path="/calculators/food-calorie" element={<FoodCalorieCalculator />} />
            
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>);



};

export default App;