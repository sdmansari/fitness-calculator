// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function () {
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');

  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', function () {
      mobileMenu.classList.toggle('active');
    });
  }

  // Close mobile menu when clicking outside
  document.addEventListener('click', function (event) {
    if (mobileMenu && mobileMenu.classList.contains('active') &&
    !mobileMenu.contains(event.target) &&
    event.target !== mobileMenuBtn) {
      mobileMenu.classList.remove('active');
    }
  });

  // Add active class to current page in navigation
  const currentLocation = window.location.pathname;
  const navLinks = document.querySelectorAll('nav ul li a');
  navLinks.forEach((link) => {
    if (link.getAttribute('href') === currentLocation.split('/').pop()) {
      link.classList.add('active');
    }
  });

  // Initialize calculators if they exist on the page
  initializeCalculators();
});

// Calculator functionality
function initializeCalculators() {
  // BMI Calculator
  const bmiForm = document.getElementById('bmi-form');
  if (bmiForm) {
    bmiForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const height = parseFloat(document.getElementById('height').value);
      const weight = parseFloat(document.getElementById('weight').value);
      const unit = document.querySelector('input[name="unit"]:checked').value;

      let bmi;
      if (unit === 'metric') {
        // Metric formula: weight (kg) / (height (m))²
        bmi = weight / (height / 100 * (height / 100));
      } else {
        // Imperial formula: (weight (lbs) / (height (in))²) * 703
        bmi = weight / (height * height) * 703;
      }

      displayBMIResult(bmi);
    });
  }

  // BMR Calculator
  const bmrForm = document.getElementById('bmr-form');
  if (bmrForm) {
    bmrForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const age = parseInt(document.getElementById('age').value);
      const gender = document.querySelector('input[name="gender"]:checked').value;
      const height = parseFloat(document.getElementById('height').value);
      const weight = parseFloat(document.getElementById('weight').value);
      const unit = document.querySelector('input[name="unit"]:checked').value;

      let bmr;
      let heightInCm = height;
      let weightInKg = weight;

      if (unit === 'imperial') {
        // Convert to metric for calculation
        heightInCm = height * 2.54; // inches to cm
        weightInKg = weight * 0.453592; // lbs to kg
      }

      if (gender === 'male') {
        // Mifflin-St Jeor Equation for men
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * age + 5;
      } else {
        // Mifflin-St Jeor Equation for women
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * age - 161;
      }

      displayBMRResult(bmr);
    });
  }

  // TDEE Calculator
  const tdeeForm = document.getElementById('tdee-form');
  if (tdeeForm) {
    tdeeForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const age = parseInt(document.getElementById('age').value);
      const gender = document.querySelector('input[name="gender"]:checked').value;
      const height = parseFloat(document.getElementById('height').value);
      const weight = parseFloat(document.getElementById('weight').value);
      const activityLevel = document.getElementById('activity-level').value;
      const unit = document.querySelector('input[name="unit"]:checked').value;

      let heightInCm = height;
      let weightInKg = weight;

      if (unit === 'imperial') {
        // Convert to metric for calculation
        heightInCm = height * 2.54; // inches to cm
        weightInKg = weight * 0.453592; // lbs to kg
      }

      let bmr;
      if (gender === 'male') {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * age + 5;
      } else {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * age - 161;
      }

      // Activity multipliers
      const activityMultipliers = {
        'sedentary': 1.2,
        'light': 1.375,
        'moderate': 1.55,
        'active': 1.725,
        'very-active': 1.9
      };

      const tdee = bmr * activityMultipliers[activityLevel];

      displayTDEEResult(tdee);
    });
  }

  // Body Fat Calculator
  const bodyFatForm = document.getElementById('body-fat-form');
  if (bodyFatForm) {
    bodyFatForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const gender = document.querySelector('input[name="gender"]:checked').value;
      const method = document.getElementById('method').value;

      let bodyFatPercentage;

      if (method === 'navy') {
        // Navy method
        const waist = parseFloat(document.getElementById('waist').value);
        const neck = parseFloat(document.getElementById('neck').value);
        const height = parseFloat(document.getElementById('height').value);
        const unit = document.querySelector('input[name="unit"]:checked').value;

        let heightInCm = height;
        let waistInCm = waist;
        let neckInCm = neck;

        if (unit === 'imperial') {
          // Convert to cm
          heightInCm = height * 2.54;
          waistInCm = waist * 2.54;
          neckInCm = neck * 2.54;
        }

        if (gender === 'male') {
          const logValue = Math.log10(waistInCm - neckInCm);
          bodyFatPercentage = 495 / (1.0324 - 0.19077 * logValue + 0.15456 * Math.log10(heightInCm)) - 450;
        } else {
          const hips = parseFloat(document.getElementById('hips').value);
          let hipsInCm = hips;

          if (unit === 'imperial') {
            hipsInCm = hips * 2.54;
          }

          const logValue = Math.log10(waistInCm + hipsInCm - neckInCm);
          bodyFatPercentage = 495 / (1.29579 - 0.35004 * logValue + 0.22100 * Math.log10(heightInCm)) - 450;
        }
      } else if (method === 'skinfold') {
        // Simple skinfold method
        const skinfold = parseFloat(document.getElementById('skinfold').value);

        if (gender === 'male') {
          bodyFatPercentage = 20 + skinfold * 0.15;
        } else {
          bodyFatPercentage = 15 + skinfold * 0.13;
        }
      }

      displayBodyFatResult(bodyFatPercentage);
    });
  }
}

// Result display functions
function displayBMIResult(bmi) {
  const resultElement = document.getElementById('bmi-result');
  const bmiValue = document.getElementById('bmi-value');
  const bmiCategory = document.getElementById('bmi-category');

  bmi = Math.round(bmi * 10) / 10; // Round to 1 decimal place

  let category;
  if (bmi < 18.5) {
    category = 'Underweight';
  } else if (bmi < 25) {
    category = 'Normal weight';
  } else if (bmi < 30) {
    category = 'Overweight';
  } else {
    category = 'Obese';
  }

  bmiValue.textContent = bmi;
  bmiCategory.textContent = category;
  resultElement.style.display = 'block';
}

function displayBMRResult(bmr) {
  const resultElement = document.getElementById('bmr-result');
  const bmrValue = document.getElementById('bmr-value');

  bmr = Math.round(bmr); // Round to nearest whole number

  bmrValue.textContent = bmr;
  resultElement.style.display = 'block';
}

function displayTDEEResult(tdee) {
  const resultElement = document.getElementById('tdee-result');
  const tdeeValue = document.getElementById('tdee-value');
  const cutValue = document.getElementById('cut-value');
  const bulkValue = document.getElementById('bulk-value');

  tdee = Math.round(tdee); // Round to nearest whole number

  tdeeValue.textContent = tdee;
  cutValue.textContent = Math.round(tdee * 0.8); // 20% deficit
  bulkValue.textContent = Math.round(tdee * 1.1); // 10% surplus

  resultElement.style.display = 'block';
}

function displayBodyFatResult(bodyFat) {
  const resultElement = document.getElementById('body-fat-result');
  const bodyFatValue = document.getElementById('body-fat-value');
  const bodyFatCategory = document.getElementById('body-fat-category');

  bodyFat = Math.round(bodyFat * 10) / 10; // Round to 1 decimal place

  const gender = document.querySelector('input[name="gender"]:checked').value;
  let category;

  if (gender === 'male') {
    if (bodyFat < 6) {
      category = 'Essential fat';
    } else if (bodyFat < 14) {
      category = 'Athletic';
    } else if (bodyFat < 18) {
      category = 'Fitness';
    } else if (bodyFat < 25) {
      category = 'Average';
    } else {
      category = 'Obese';
    }
  } else {
    if (bodyFat < 16) {
      category = 'Essential fat';
    } else if (bodyFat < 24) {
      category = 'Athletic';
    } else if (bodyFat < 31) {
      category = 'Fitness';
    } else if (bodyFat < 37) {
      category = 'Average';
    } else {
      category = 'Obese';
    }
  }

  bodyFatValue.textContent = bodyFat;
  bodyFatCategory.textContent = category;
  resultElement.style.display = 'block';
}