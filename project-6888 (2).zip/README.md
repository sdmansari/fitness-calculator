# Fitness Calculator Hub

A React-based web application that provides various health and fitness calculators for users.

## Project Setup

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

## Project Structure

- `/src` - Main source code
  - `/components` - React components
  - `/pages` - Page components
  - `/hooks` - Custom React hooks
  - `/lib` - Utility functions
- `/public` - Static assets
  - `/images` - Image files

## Key Features

- BMI, BMR, and other health calculators
- Responsive design
- Informative blog articles